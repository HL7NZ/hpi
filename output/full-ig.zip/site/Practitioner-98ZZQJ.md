# 98ZZQJ - New Zealand HPI Implementation Guide v1.4.11

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **98ZZQJ**

## Example Practitioner: 98ZZQJ

version: 10594; Last updated: 2022-08-30 14:34:08+1200

Profile: [HPI Practitioner](StructureDefinition-HPIPractitioner.md)

Security Label: [low (Details: Confidentiality code L = 'low')](http://terminology.hl7.org/7.5.0/CodeSystem-v3-Confidentiality.html)

TestTwo Tworegistrations Nurse-Midwife (official) (https://standards.digital.health.nz/ns/hpi-person-id#HPIProvider#98ZZQJ (use: official))

-------

| | |
| :--- | :--- |
| Other Ids: | * HPIProvider/90ZZGJ (use: old)
* NZNC/962054 (use: official)
* NZMidwife/95579 (use: official)
 |
| Qualification: | Nursing Council of New Zealand Register Number* Identifier: NZNC/962054 (use: official)
* Valid Period: 2019-02-01 --> 2026-02-01
* Issued By: [Reference Organization G00008-K (https://standards.digital.health.nz/ns/hpi-organisation-id#HPIOrganization#G00008-K (use: official))](Organization-G00008-K.md)
 |
| Qualification: | Midwifery Council Register Number* Identifier: NZMidwife/95579 (use: official)
* Valid Period: 2020-12-10 --> 2022-12-11
* Issued By: [Reference Organization G00009-A (https://standards.digital.health.nz/ns/hpi-organisation-id#HPIOrganization#G00009-A (use: official))](Organization-G00009-A.md)
 |
| Languages: | * English
* English
 |
| null: | * fullname: Bachelor of Midwifery
* year: 2019
* institution: Auckland University of Technology
* city: AUCKLAND
* country: NZ
 |
| null: | * fullname: Bachelor of Nursing (Maori)
* year: 2009
* institution: Whitireia Polytechnic
* city: PALMERSTON NORTH
* country: NZ
 |



## Resource Content

```json
{
  "resourceType" : "Practitioner",
  "id" : "98ZZQJ",
  "meta" : {
    "versionId" : "10594",
    "lastUpdated" : "2022-08-30T14:34:08.000+12:00",
    "profile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPIPractitioner"],
    "security" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-Confidentiality",
      "code" : "L"
    }]
  },
  "extension" : [{
    "extension" : [{
      "url" : "fullname",
      "valueString" : "Bachelor of Midwifery"
    },
    {
      "url" : "year",
      "valueDate" : "2019"
    },
    {
      "url" : "institution",
      "valueString" : "Auckland University of Technology"
    },
    {
      "url" : "city",
      "valueString" : "AUCKLAND"
    },
    {
      "url" : "country",
      "valueString" : "NZ"
    }],
    "url" : "http://hl7.org.nz/fhir/StructureDefinition/educational-qualification"
  },
  {
    "extension" : [{
      "url" : "fullname",
      "valueString" : "Bachelor of Nursing (Maori)"
    },
    {
      "url" : "year",
      "valueDate" : "2009"
    },
    {
      "url" : "institution",
      "valueString" : "Whitireia Polytechnic"
    },
    {
      "url" : "city",
      "valueString" : "PALMERSTON NORTH"
    },
    {
      "url" : "country",
      "valueString" : "NZ"
    }],
    "url" : "http://hl7.org.nz/fhir/StructureDefinition/educational-qualification"
  }],
  "identifier" : [{
    "use" : "official",
    "system" : "https://standards.digital.health.nz/ns/hpi-person-id",
    "value" : "98ZZQJ",
    "assigner" : {
      "reference" : "Organization/G00001-G"
    }
  },
  {
    "use" : "old",
    "system" : "https://standards.digital.health.nz/ns/hpi-person-id",
    "value" : "90ZZGJ",
    "assigner" : {
      "reference" : "Organization/G00001-G"
    }
  },
  {
    "use" : "official",
    "system" : "https://standards.digital.health.nz/ns/nursing-council-id",
    "value" : "962054",
    "assigner" : {
      "reference" : "Organization/G00008-K"
    }
  },
  {
    "use" : "official",
    "system" : "https://standards.digital.health.nz/ns/midwifery-council-id",
    "value" : "95579",
    "assigner" : {
      "reference" : "Organization/G00009-A"
    }
  }],
  "name" : [{
    "use" : "official",
    "family" : "Nurse-Midwife",
    "given" : ["TestTwo", "Tworegistrations"],
    "prefix" : ["mrs"]
  }],
  "qualification" : [{
    "extension" : [{
      "extension" : [{
        "url" : "status",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://standards.digital.health.nz/ns/practitioner-registration-status-code",
            "version" : "2.0",
            "code" : "current",
            "display" : "A provider who holds or is deemed to hold a current practising certificate."
          }],
          "text" : "A provider who holds or is deemed to hold a current practising certificate."
        }
      },
      {
        "url" : "period",
        "valuePeriod" : {
          "start" : "2019-02-01",
          "end" : "2026-02-01"
        }
      }],
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/registration-status-code"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://standards.digital.health.nz/ns/practitioner-scope-of-practice-code",
            "version" : "2.1.0",
            "code" : "NCRN",
            "display" : "Registered Nurse"
          }],
          "text" : "Registered Nurse"
        }
      },
      {
        "url" : "period",
        "valuePeriod" : {
          "start" : "2009-04-08",
          "end" : "2029-03-27"
        }
      }],
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/scope-of-practice"
    },
    {
      "extension" : [{
        "url" : "description",
        "valueString" : "NCRN Must have a competence assessment completed by a senior nurse within three months"
      },
      {
        "url" : "period",
        "valuePeriod" : {
          "start" : "2009-04-08"
        }
      }],
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/condition-on-practice"
    },
    {
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/registration-initial-date",
      "valueDate" : "2009-02-01"
    }],
    "identifier" : [{
      "use" : "official",
      "system" : "https://standards.digital.health.nz/ns/nursing-council-id",
      "value" : "962054",
      "assigner" : {
        "reference" : "Organization/G00008-K"
      }
    }],
    "code" : {
      "coding" : [{
        "system" : "https://standards.digital.health.nz/ns/practitioner-registration-authority-code",
        "version" : "2.1",
        "code" : "NC",
        "display" : "Nursing Council of New Zealand Register"
      }],
      "text" : "Nursing Council of New Zealand Register Number"
    },
    "period" : {
      "start" : "2019-02-01",
      "end" : "2026-02-01"
    },
    "issuer" : {
      "reference" : "Organization/G00008-K"
    }
  },
  {
    "extension" : [{
      "extension" : [{
        "url" : "status",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://standards.digital.health.nz/ns/practitioner-registration-status-code",
            "version" : "2.0",
            "code" : "current",
            "display" : "A provider who holds or is deemed to hold a current practising certificate."
          }],
          "text" : "A provider who holds or is deemed to hold a current practising certificate."
        }
      },
      {
        "url" : "period",
        "valuePeriod" : {
          "start" : "2020-12-10",
          "end" : "2023-12-11"
        }
      }],
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/registration-status-code"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://standards.digital.health.nz/ns/practitioner-scope-of-practice-code",
            "version" : "2.1.0",
            "code" : "NCRN",
            "display" : "Registered Nurse"
          }],
          "text" : "Registered Nurse"
        }
      },
      {
        "url" : "period",
        "valuePeriod" : {
          "start" : "2019-04-08",
          "end" : "2022-04-11"
        }
      }],
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/scope-of-practice"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://standards.digital.health.nz/ns/practitioner-scope-of-practice-code",
            "version" : "2.1.0",
            "code" : "MWIF",
            "display" : "Midwife"
          }],
          "text" : "Midwife"
        }
      },
      {
        "url" : "period",
        "valuePeriod" : {
          "start" : "2019-04-08",
          "end" : "2025-04-11"
        }
      }],
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/scope-of-practice"
    },
    {
      "extension" : [{
        "url" : "description",
        "valueString" : "NCRN Must have a competence assessment completed by a senior nurse within three months"
      },
      {
        "url" : "period",
        "valuePeriod" : {
          "start" : "2019-04-08"
        }
      }],
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/condition-on-practice"
    },
    {
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/registration-initial-date",
      "valueDate" : "2020-02-01"
    }],
    "identifier" : [{
      "use" : "official",
      "system" : "https://standards.digital.health.nz/ns/midwifery-council-id",
      "value" : "95579",
      "assigner" : {
        "reference" : "Organization/G00009-A"
      }
    }],
    "code" : {
      "coding" : [{
        "system" : "https://standards.digital.health.nz/ns/practitioner-registration-authority-code",
        "version" : "2.1",
        "code" : "MW",
        "display" : "Midwifery Council Register"
      }],
      "text" : "Midwifery Council Register Number"
    },
    "period" : {
      "start" : "2020-12-10",
      "end" : "2022-12-11"
    },
    "issuer" : {
      "reference" : "Organization/G00009-A"
    }
  }],
  "communication" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:639:-3",
      "version" : "2007",
      "code" : "eng",
      "display" : "English"
    }],
    "text" : "English"
  },
  {
    "coding" : [{
      "system" : "urn:iso:std:iso:639:-3",
      "version" : "2007",
      "code" : "eng",
      "display" : "English"
    }],
    "text" : "English"
  }]
}

```
