# Search Practitioner - New Zealand HPI Implementation Guide v1.4.10

* [**Table of Contents**](toc.md)
* **Search Practitioner**

## Search Practitioner

### Search Practitioner Overview

The search Practitioner operation allows a user to search the HPI for a Practitioner record with known demographics

* name,
* gender, and
* birthdate

[For more information of available search parameters click here](/capabilityStatement.md#practitioner)

### Search Practitioner using name

**Search Practitioner using name processing steps:**

1. The user of the integrating application searches for a Practitioner by entering the name
1. The integrating application sends an HTTP GET request for the Practitioner resource using the name attribute as search parameter E.g. GET<Endpoint>/Practitioner?name=walter o'reilly
1. The request is validated - ALT: Validation failure. OperationOutcome resource returned
1. The matching Practitioners are retrieved from the HPI
1. The response containing a bundle of matching Practitioners is returned to the integrating application
1. The integrating application displays the matching Practitioners to the user

### Search Practitioner using name and birth date

**Search Practitioner using name and birth date processing steps:**

1. The user of the integrating application searches for a Practitioner by entering the name and birth date
1. The integrating application sends an HTTP GET request for the Practitioner resource using the name and birthdate elements as search parameters E.g. GET<Endpoint>/Practitioner?name=walter o'reilly&birthdate=1943-05-24
1. The request is validated - ALT: Validation failure. OperationOutcome resource returned
1. The matching Practitioners are retrieved from the HPI
1. The response containing a bundle of matching Practitioners is returned to the integrating application
1. The integrating application displays the matching Practitioners to the user

### Search Practitioner Rules and errors

* Rule: A search Practitioner request must include a name at minimum
  * Error code: * EM07201

  * Error description: * Required value missing

  * Error text / expression: * Practitioner.SearchParam.name

  * Http code: * 422 Unknown

* Rule: A search Practitioner request may include birthdate and gender
  * Error code: * *No error*

  * Error description: * 

  * Error text / expression: * 

  * Http code: * 


