# HPI Organization - New Zealand HPI Implementation Guide v1.4.10

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **HPI Organization**

## Resource Profile: HPI Organization 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization | *Version*:1.4.10 |
| Active as of 2026-10-13 | *Computable Name*:HpiOrganization |

 
An entity that provides services of interest to, or is involved in, the business of health care service provision. 

 
Describe the Organization that will be returned by the HPI 

The Organisation resource represents any organisation that provides healthcare services.

HPI Organisations each have an identifier in the format GXXNNN-C where X is alphanumeric, N is numeric and C is a check character

Organisations are primarily legal entities e.g. Companies, Charitable trusts etc but can also be Sole traders or informal partnerships.

Organisations can also be parts of a legal entity that ‘trade’ as if they were a separate entity. These ‘sub-organisations’ will be related to their parent.

An example of an organisation with sub organisations would be a Company owning a number of discrete pharmacies . Each of the pharmacies would be set up as a separate organisation (sub-organisation) with each being related to the parent Organisation (organization.partOf)

Wherever possible Organisations are validated by the assignment of the NZBN.

**Usages:**

* Refer to this Profile: [HPI Practitioner](StructureDefinition-HPIPractitioner.md), [HPI Practitioner role](StructureDefinition-HPIPractitionerRole.md), [HPI Location](StructureDefinition-HpiLocation.md) and [HPI Organization](StructureDefinition-HpiOrganization.md)
* Examples for this Profile: [Reference Organization G00000-E](Organization-G00000-E.md), [HPI Root Organization](Organization-G00001-G.md), [Reference Organization G00008-K](Organization-G00008-K.md), [Reference Organization G00009-A](Organization-G00009-A.md)... Show 7 more, [Reference Organization GZZ836-C](Organization-GZZ836-C.md), [Reference Organization GZZ908-B](Organization-GZZ908-B.md), [Flat-Unit Address Org](Organization-GZZ956-B.md), [Second Name](Organization-GZZ991-D.md), [Referenced PractitionerRole Organization](Organization-GZZ998-G.md), [Reference Organization GZZ999-J](Organization-GZZ999-J.md) and [Ministry of Business, Innovation and Employment](Organization-MBIE.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/hl7.org.nz.fhir.ig.hpi|current/StructureDefinition/StructureDefinition-HpiOrganization.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-HpiOrganization.csv), [Excel](StructureDefinition-HpiOrganization.xlsx), [Schematron](StructureDefinition-HpiOrganization.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "HpiOrganization",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-category",
    "valueString" : "Base.Entities"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-security-category",
    "valueCode" : "business"
  }],
  "url" : "http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization",
  "version" : "1.4.10",
  "name" : "HpiOrganization",
  "title" : "HPI Organization",
  "status" : "active",
  "date" : "2026-10-13T19:42:36+00:00",
  "publisher" : "Te Whatu Ora",
  "contact" : [{
    "name" : "Te Whatu Ora",
    "telecom" : [{
      "system" : "email",
      "value" : "mailto:integration@health.govt.nz"
    }]
  }],
  "description" : "An entity that provides services of interest to, or is involved in, the business of health care service provision.",
  "purpose" : "Describe the Organization that will be returned by the HPI",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "servd",
    "uri" : "http://www.omg.org/spec/ServD/1.0/",
    "name" : "ServD"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Organization",
  "baseDefinition" : "http://hl7.org.nz/fhir/StructureDefinition/NzOrganization",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Organization",
      "path" : "Organization"
    },
    {
      "id" : "Organization.extension:established",
      "path" : "Organization.extension",
      "sliceName" : "established",
      "short" : "The period over which this Organization has been established"
    },
    {
      "id" : "Organization.extension:funded-programme",
      "path" : "Organization.extension",
      "sliceName" : "funded-programme",
      "max" : "0"
    },
    {
      "id" : "Organization.identifier",
      "path" : "Organization.identifier",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "use"
        },
        {
          "type" : "value",
          "path" : "system"
        }],
        "rules" : "open"
      },
      "min" : 1
    },
    {
      "id" : "Organization.identifier.use",
      "path" : "Organization.identifier.use",
      "short" : "official | old",
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://nzhts.digital.health.nz/fhir/ValueSet/hpi-identifier-use-code"
      }
    },
    {
      "id" : "Organization.identifier:orgId",
      "path" : "Organization.identifier",
      "sliceName" : "orgId",
      "short" : "The current HPI organization Id for this Organization",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Organization.identifier:orgId.use",
      "path" : "Organization.identifier.use",
      "short" : "fixed to official",
      "min" : 1,
      "fixedCode" : "official"
    },
    {
      "id" : "Organization.identifier:orgId.type",
      "path" : "Organization.identifier.type",
      "max" : "0"
    },
    {
      "id" : "Organization.identifier:orgId.system",
      "path" : "Organization.identifier.system",
      "min" : 1,
      "fixedUri" : "https://standards.digital.health.nz/ns/hpi-organisation-id"
    },
    {
      "id" : "Organization.identifier:orgId.period",
      "path" : "Organization.identifier.period",
      "max" : "0"
    },
    {
      "id" : "Organization.identifier:orgId.assigner",
      "path" : "Organization.identifier.assigner",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization"]
      }]
    },
    {
      "id" : "Organization.identifier:legacyOrgId",
      "path" : "Organization.identifier",
      "sliceName" : "legacyOrgId",
      "short" : "The MOH (NZHIS) Legacy agency code)",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Organization.identifier:legacyOrgId.use",
      "path" : "Organization.identifier.use",
      "short" : "fixed to official",
      "min" : 1,
      "fixedCode" : "official"
    },
    {
      "id" : "Organization.identifier:legacyOrgId.type",
      "path" : "Organization.identifier.type",
      "max" : "0"
    },
    {
      "id" : "Organization.identifier:legacyOrgId.system",
      "path" : "Organization.identifier.system",
      "min" : 1,
      "fixedUri" : "https://standards.digital.health.nz/ns/nzhis-agency-id"
    },
    {
      "id" : "Organization.identifier:legacyOrgId.period",
      "path" : "Organization.identifier.period",
      "max" : "0"
    },
    {
      "id" : "Organization.identifier:legacyOrgId.assigner",
      "path" : "Organization.identifier.assigner",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization"]
      }]
    },
    {
      "id" : "Organization.identifier:nzbn",
      "path" : "Organization.identifier",
      "sliceName" : "nzbn",
      "short" : "The New Zealand Business Number",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Organization.identifier:nzbn.use",
      "path" : "Organization.identifier.use",
      "short" : "fixed to official",
      "min" : 1,
      "fixedCode" : "official"
    },
    {
      "id" : "Organization.identifier:nzbn.type",
      "path" : "Organization.identifier.type",
      "max" : "0"
    },
    {
      "id" : "Organization.identifier:nzbn.system",
      "path" : "Organization.identifier.system",
      "min" : 1,
      "fixedUri" : "https://standards.digital.health.nz/ns/hpi-nzbn"
    },
    {
      "id" : "Organization.identifier:nzbn.period",
      "path" : "Organization.identifier.period",
      "max" : "0"
    },
    {
      "id" : "Organization.identifier:nzbn.assigner",
      "path" : "Organization.identifier.assigner",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization"]
      }]
    },
    {
      "id" : "Organization.identifier:dormant",
      "path" : "Organization.identifier",
      "sliceName" : "dormant",
      "short" : "Identifiers which have been deprecated",
      "min" : 0,
      "max" : "*",
      "mustSupport" : true
    },
    {
      "id" : "Organization.identifier:dormant.use",
      "path" : "Organization.identifier.use",
      "short" : "fixed to old",
      "min" : 1,
      "fixedCode" : "old"
    },
    {
      "id" : "Organization.identifier:dormant.type",
      "path" : "Organization.identifier.type",
      "max" : "0"
    },
    {
      "id" : "Organization.identifier:dormant.system",
      "path" : "Organization.identifier.system",
      "min" : 1,
      "fixedUri" : "https://standards.digital.health.nz/ns/hpi-organisation-id"
    },
    {
      "id" : "Organization.identifier:dormant.period",
      "path" : "Organization.identifier.period",
      "max" : "0"
    },
    {
      "id" : "Organization.identifier:dormant.assigner",
      "path" : "Organization.identifier.assigner",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization"]
      }]
    },
    {
      "id" : "Organization.type",
      "path" : "Organization.type",
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://nzhts.digital.health.nz/fhir/ValueSet/organisation-type-code"
      }
    },
    {
      "id" : "Organization.alias.extension:alias-type",
      "path" : "Organization.alias.extension",
      "sliceName" : "alias-type",
      "short" : "The type of alias for this Organization - eg its Maori name"
    },
    {
      "id" : "Organization.alias.extension:alias-type.valueCodeableConcept",
      "path" : "Organization.alias.extension.valueCodeableConcept",
      "binding" : {
        "strength" : "preferred",
        "valueSet" : "https://nzhts.digital.health.nz/fhir/ValueSet/organization-alias-type-code"
      }
    },
    {
      "id" : "Organization.telecom.use",
      "path" : "Organization.telecom.use",
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://nzhts.digital.health.nz/fhir/ValueSet/hpi-contact-point-use-code"
      }
    },
    {
      "id" : "Organization.address",
      "path" : "Organization.address",
      "max" : "0",
      "type" : [{
        "code" : "Address",
        "profile" : ["http://hl7.org.nz/fhir/StructureDefinition/NzAddress"]
      }]
    },
    {
      "id" : "Organization.partOf",
      "path" : "Organization.partOf",
      "type" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-hierarchy",
          "valueBoolean" : true
        }],
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization"]
      }]
    },
    {
      "id" : "Organization.contact",
      "path" : "Organization.contact",
      "max" : "0"
    },
    {
      "id" : "Organization.endpoint",
      "path" : "Organization.endpoint",
      "max" : "0"
    }]
  }
}

```
