# Artifacts Summary - New Zealand HPI Implementation Guide v1.4.11

* [**Table of Contents**](toc.md)
* **Artifacts Summary**

## Artifacts Summary

This page provides a list of the FHIR artifacts defined as part of this implementation guide.

### Behavior: Capability Statements 

The following artifacts define the specific capabilities that different types of systems are expected to have in order to comply with this implementation guide. Systems conforming to this implementation guide are expected to declare conformance to one or more of the following capability statements.

| | |
| :--- | :--- |
| [CapabilityStatement](CapabilityStatement-HpiCapabilityStatement.md) | Represents API exposed by HPI |

### Behavior: Operation Definitions 

These are custom operations that can be supported by and/or invoked by systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [Practitioner-update-core](OperationDefinition-Practitioner-update-core.md) | A custom operation which updates a health provider's name, birthdate and death-date. |

### Structures: Resource Profiles 

These define constraints on FHIR resources for systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [HPI Location](StructureDefinition-HpiLocation.md) | A physical location from which health goods and/or services are provided. They are also referred to as an HPI Facility. |
| [HPI Organization](StructureDefinition-HpiOrganization.md) | An entity that provides services of interest to, or is involved in, the business of health care service provision. |
| [HPI Practitioner](StructureDefinition-HPIPractitioner.md) | The practitioner exposed by the HPI. This is the person who delivers healthcare or healthcare related services. |
| [HPI Practitioner role](StructureDefinition-HPIPractitionerRole.md) | The practitioner role exposed by the HPI. Used to connect Practitioners with Organizations and Locations, indicating the role they have. A single Practitioner can have roles with multiple organizations. |

### Structures: Extension Definitions 

These define constraints on FHIR data types for systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [Esam_id](StructureDefinition-esam-id.md) | The id from eSam |

### Example: Example Instances 

These are example instances that show what data produced and consumed by systems conforming with this implementation guide might look like.

| | |
| :--- | :--- |
| [90ZZLP](Practitioner-90ZZLP.md) | Example HPI Practitioner with No Registration 'NR' with confidentiality R |
| [91ZABY](Practitioner-91ZABY.md) | Example HPI Practitioner with one registration |
| [92ZZRE](Practitioner-92ZZRE.md) | Example HPI Practitioner with No Registration 'NR' |
| [98ZZQJ](Practitioner-98ZZQJ.md) | Example HPI Practitioner with two registrations |
| [99ZZZS](Practitioner-99ZZZS.md) | Example HPI Practitioner used by PractitionerRole |
| [FZZ941-D](Location-FZZ941-D.md) | Example HPI Location Inactive (disestablished) |
| [FZZ958-K](Location-FZZ958-K.md) | Example HPI Location with Managing Org |
| [FZZ999-B](Location-FZZ999-B.md) | Example HPI Location with messaging address |
| [G00000-E](Organization-G00000-E.md) | Example HPI Organization |
| [G00001-G](Organization-G00001-G.md) | Example HPI root Organization |
| [G00008-K](Organization-G00008-K.md) | Example HPI Organization |
| [G00009-A](Organization-G00009-A.md) | Example HPI Organization |
| [GZZ836-C](Organization-GZZ836-C.md) | Example HPI Organization |
| [GZZ908-B](Organization-GZZ908-B.md) | Example HPI Organization |
| [GZZ956-B](Organization-GZZ956-B.md) | Example HPI Organization |
| [GZZ991-D](Organization-GZZ991-D.md) | Example HPI Organization 'partof' |
| [GZZ998-G](Organization-GZZ998-G.md) | Example HPI Organization for PractitionerRole references |
| [GZZ999-J](Organization-GZZ999-J.md) | Example HPI Organization |
| [MBIE](Organization-MBIE.md) | Example MBIE Organization |
| [R00000012-G](PractitionerRole-R00000012-G.md) | Example HPI PractitionerRole Medical Receptionist |
| [R00000015-C](PractitionerRole-R00000015-C.md) | Example HPI PractitionerRole with confidentiality R |
| [R00000029-P](PractitionerRole-R00000029-P.md) | Example HPI PractitionerRole with messagin address |
| [testall](Person-testall.md) | Example person used by PractitionerRole creator extension |

