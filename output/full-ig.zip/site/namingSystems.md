# Naming Systems - New Zealand HPI Implementation Guide v1.5.0

* [**Table of Contents**](toc.md)
* **Naming Systems**

## Naming Systems

### Identifiers

These are identifiers defined in this IG. They are defined using
[NamingSystem](http://hl7.org/fhir/namingsystem.html)resources.


