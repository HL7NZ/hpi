# HPI Practitioner role - New Zealand HPI Implementation Guide v1.5.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **HPI Practitioner role**

## Resource Profile: HPI Practitioner role 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.org.nz/fhir/StructureDefinition/HPIPractitionerRole | *Version*:1.5.0 |
| Active as of 2026-11-03 | *Computable Name*:HpiPractitionerRole |

 
The practitioner role exposed by the HPI. Used to connect Practitioners with Organizations and Locations, indicating the role they have. A single Practitioner can have roles with multiple organizations. 

 
Describe the PractitionerRole that will be returned by the HPI 

### HPI PractitionerRole

#### Practitioner Role Attributes

* PractitionerRole Attribute: PractitionerRole-creator
  * Description: The Person and Organisation that created the PractitionerRole record
* PractitionerRole Attribute: PractitionerRole-status-reason
  * Description: The reason that the PractitionerRole record was endedOnly present when a PractitionerRole has a period end date
* PractitionerRole Attribute: Messaging-address
  * Description: The electronic messaging address for the person's roleOnly to be used if the Facility messaging address is not appropriate for the specific roleUsed for the healthlink edi-address
* PractitionerRole Attribute: identifier:RI
  * Description: The unique PractitionerRole record identifier
* PractitionerRole Attribute: Active
  * Description: Whether this PractitionerRole record is in active useThis is a derived field from the period start and end dates
* PractitionerRole Attribute: Period
  * Description: The start and end dates for a PractitinerRole record
* PractitionerRole Attribute: Practitioner
  * Description: The Practitioner assigned to the rolehpi-person-id (CPN) and name
* PractitionerRole Attribute: Organization
  * Description: The Organisation the Practitioner works for in this rolehpi-organization-id and name
* PractitionerRole Attribute: Code
  * Description: The role the Practitioner is assinged to
* PractitionerRole Attribute: Location
  * Description: The Facility where the Practitioner works in this rolehpi-facility-id and name
* PractitionerRole Attribute: Telecom
  * Description: The Contact details for this Practitioner in this role

**Usages:**

* Examples for this Profile: [PractitionerRole/R00000012-G](PractitionerRole-R00000012-G.md), [PractitionerRole/R00000015-C](PractitionerRole-R00000015-C.md) and [PractitionerRole/R00000029-P](PractitionerRole-R00000029-P.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/hl7.org.nz.fhir.ig.hpi|current/StructureDefinition/StructureDefinition-HPIPractitionerRole.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-HPIPractitionerRole.csv), [Excel](StructureDefinition-HPIPractitionerRole.xlsx), [Schematron](StructureDefinition-HPIPractitionerRole.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "HPIPractitionerRole",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-category",
    "valueString" : "Base.Individuals"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-security-category",
    "valueCode" : "individual"
  }],
  "url" : "http://hl7.org.nz/fhir/StructureDefinition/HPIPractitionerRole",
  "version" : "1.5.0",
  "name" : "HpiPractitionerRole",
  "title" : "HPI Practitioner role",
  "status" : "active",
  "date" : "2026-11-03T02:43:01+00:00",
  "publisher" : "Te Whatu Ora",
  "contact" : [{
    "name" : "Te Whatu Ora",
    "telecom" : [{
      "system" : "email",
      "value" : "mailto:integration@health.govt.nz"
    }]
  }],
  "description" : "The practitioner role exposed by the HPI. Used to connect Practitioners with Organizations and Locations, indicating the role they have. A single Practitioner can have roles with multiple organizations.",
  "purpose" : "Describe the PractitionerRole that will be returned by the HPI",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "servd",
    "uri" : "http://www.omg.org/spec/ServD/1.0/",
    "name" : "ServD"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "PractitionerRole",
  "baseDefinition" : "http://hl7.org.nz/fhir/StructureDefinition/NzPractitionerRole",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "PractitionerRole",
      "path" : "PractitionerRole"
    },
    {
      "id" : "PractitionerRole.extension:practitionerRole-creator",
      "path" : "PractitionerRole.extension",
      "sliceName" : "practitionerRole-creator",
      "short" : "The person and/or organization that created the PR"
    },
    {
      "id" : "PractitionerRole.extension:practitionerRole-status-reason",
      "path" : "PractitionerRole.extension",
      "sliceName" : "practitionerRole-status-reason",
      "short" : "The reason for the status of this role. Generally when it is inactive."
    },
    {
      "id" : "PractitionerRole.extension:messaging-address",
      "path" : "PractitionerRole.extension",
      "sliceName" : "messaging-address",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.org.nz/fhir/StructureDefinition/messaging-address"]
      }]
    },
    {
      "id" : "PractitionerRole.identifier",
      "path" : "PractitionerRole.identifier",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "use"
        },
        {
          "type" : "value",
          "path" : "system"
        }],
        "description" : "The identifiers",
        "rules" : "openAtEnd"
      }
    },
    {
      "id" : "PractitionerRole.identifier:RI",
      "path" : "PractitionerRole.identifier",
      "sliceName" : "RI",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "PractitionerRole.identifier:RI.use",
      "path" : "PractitionerRole.identifier.use",
      "short" : "PractitionerRole Id",
      "min" : 1,
      "fixedCode" : "official"
    },
    {
      "id" : "PractitionerRole.identifier:RI.type",
      "path" : "PractitionerRole.identifier.type",
      "max" : "0"
    },
    {
      "id" : "PractitionerRole.identifier:RI.system",
      "path" : "PractitionerRole.identifier.system",
      "min" : 1,
      "fixedUri" : "https://standards.digital.health.nz/ns/hpi-practitionerrole-id"
    },
    {
      "id" : "PractitionerRole.identifier:RI.period",
      "path" : "PractitionerRole.identifier.period",
      "max" : "0"
    },
    {
      "id" : "PractitionerRole.practitioner",
      "path" : "PractitionerRole.practitioner",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPIPractitioner"]
      }]
    },
    {
      "id" : "PractitionerRole.organization",
      "path" : "PractitionerRole.organization",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization"]
      }]
    },
    {
      "id" : "PractitionerRole.code",
      "path" : "PractitionerRole.code",
      "max" : "1",
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://nzhts.digital.health.nz/fhir/ValueSet/practitioner-role-code"
      }
    },
    {
      "id" : "PractitionerRole.specialty",
      "path" : "PractitionerRole.specialty",
      "max" : "0"
    },
    {
      "id" : "PractitionerRole.location",
      "path" : "PractitionerRole.location",
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPILocation"]
      }]
    },
    {
      "id" : "PractitionerRole.healthcareService",
      "path" : "PractitionerRole.healthcareService",
      "max" : "0"
    },
    {
      "id" : "PractitionerRole.telecom.use",
      "path" : "PractitionerRole.telecom.use",
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://nzhts.digital.health.nz/fhir/ValueSet/hpi-contact-point-use-code"
      }
    },
    {
      "id" : "PractitionerRole.availableTime",
      "path" : "PractitionerRole.availableTime",
      "max" : "0"
    },
    {
      "id" : "PractitionerRole.availableTime.daysOfWeek",
      "path" : "PractitionerRole.availableTime.daysOfWeek",
      "max" : "0"
    },
    {
      "id" : "PractitionerRole.notAvailable",
      "path" : "PractitionerRole.notAvailable",
      "max" : "0"
    },
    {
      "id" : "PractitionerRole.availabilityExceptions",
      "path" : "PractitionerRole.availabilityExceptions",
      "max" : "0"
    },
    {
      "id" : "PractitionerRole.endpoint",
      "path" : "PractitionerRole.endpoint",
      "max" : "0"
    }]
  }
}

```
