# FZZ958-K - New Zealand HPI Implementation Guide v1.5.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FZZ958-K**

## Example Location: FZZ958-K

version: 10803; Last updated: 2022-11-09 12:00:14+1300

Profile: [HPI Location](StructureDefinition-HpiLocation.md)

Medical Centre Flat-Unit (Enrolling GP Practice) (https://standards.digital.health.nz/ns/hpi-facility-id#HPIFacility#FZZ958-K (use: official))

-------

| | |
| :--- | :--- |
| Status: | Active |
| Alias: | Medical Centre Flat-Unit |
| Type: | Enrolling GP Practice |
| Address: | 123 Molesworth Street, Thorndon 6011, Wellington(work) (NZ Suburb: Thorndon) |
| Contact Detail | * ph: 021 555558(Temp)
* ph: 021 464646(Work)
 |
| Managed By: | [Flat-Unit Address Org](Organization-GZZ956-B.md) |
| Other Id: | HPIFacility/9987 (use: official) |
|  | 1980-12-12 --> (ongoing) |
| [District Health Board linked to a NZ Healthcare Service, Location or Patient](https://fhir.org.nz/ig/base/StructureDefinition-dhb.html) | Capital and Coast District Health Board |



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "FZZ958-K",
  "meta" : {
    "versionId" : "10803",
    "lastUpdated" : "2022-11-09T12:00:14.000+13:00",
    "profile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPILocation"]
  },
  "extension" : [{
    "url" : "http://hl7.org.nz/fhir/StructureDefinition/established",
    "valuePeriod" : {
      "start" : "1980-12-12"
    }
  },
  {
    "url" : "http://hl7.org.nz/fhir/StructureDefinition/dhb",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "https://standards.digital.health.nz/ns/dhb-code",
        "version" : "1.0.0",
        "code" : "G00036-D",
        "display" : "Capital and Coast District Health Board"
      }],
      "text" : "Capital and Coast District Health Board"
    }
  }],
  "identifier" : [{
    "use" : "official",
    "system" : "https://standards.digital.health.nz/ns/hpi-facility-id",
    "value" : "FZZ958-K",
    "assigner" : {
      "reference" : "Organization/G00001-G"
    }
  },
  {
    "use" : "official",
    "system" : "https://standards.digital.health.nz/ns/nzhis-facility-id",
    "value" : "9987",
    "assigner" : {
      "reference" : "Organization/G00001-G"
    }
  }],
  "status" : "active",
  "name" : "Medical Centre Flat-Unit",
  "alias" : ["Medical Centre Flat-Unit"],
  "_alias" : [{
    "extension" : [{
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/alias-type",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://standards.digital.health.nz/ns/alias-type-code",
          "version" : "1.0.0",
          "code" : "current",
          "display" : "Current unverified or unofficial name"
        }],
        "text" : "Current unverified or unofficial name"
      }
    }]
  }],
  "type" : [{
    "coding" : [{
      "system" : "https://standards.digital.health.nz/ns/location-type-code",
      "version" : "1.0",
      "code" : "gpenrol",
      "display" : "Enrolling GP Practice"
    }]
  }],
  "telecom" : [{
    "system" : "phone",
    "value" : "021 555558",
    "use" : "temp",
    "rank" : 1,
    "period" : {
      "start" : "1980-12-12"
    }
  },
  {
    "system" : "phone",
    "value" : "021 464646",
    "use" : "work",
    "rank" : 1,
    "period" : {
      "start" : "1980-12-12"
    }
  }],
  "address" : {
    "id" : "1517156",
    "extension" : [{
      "extension" : [{
        "url" : "latitude",
        "valueDecimal" : -41.273494
      },
      {
        "url" : "longitude",
        "valueDecimal" : 174.777705
      }],
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/nz-geocode"
    },
    {
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/suburb",
      "valueString" : "Thorndon"
    },
    {
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/domicile-code",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://standards.digital.health.nz/ns/domicile-code",
          "version" : "3.0",
          "code" : "2077",
          "display" : "Thorndon - Tinakori Road"
        }],
        "text" : "Thorndon - Tinakori Road"
      }
    }],
    "use" : "work",
    "type" : "physical",
    "text" : "123 Molesworth Street, Thorndon 6011, Wellington",
    "line" : ["123 Molesworth Street"],
    "city" : "Wellington",
    "postalCode" : "6011"
  },
  "managingOrganization" : {
    "reference" : "Organization/GZZ956-B",
    "display" : "Flat-Unit Address Org"
  }
}

```
