# 91ZABY - New Zealand HPI Implementation Guide v1.4.10

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **91ZABY**

## Example Practitioner: 91ZABY

version: 10952; Last updated: 2022-12-20 09:27:27+1300

Profile: [HPI Practitioner](StructureDefinition-HPIPractitioner.md)

Security Label: [low (Details: Confidentiality code L = 'low')](http://terminology.hl7.org/7.4.0/CodeSystem-v3-Confidentiality.html)

Lyndi Jane Rhode (official) (https://standards.digital.health.nz/ns/hpi-person-id#HPIProvider#91ZABY (use: official))

-------

| | | | |
| :--- | :--- | :--- | :--- |
| Gender: | Female | Date of Birth: | 1975-01-19 |
| Other Id: | NZOCC/96-20154 (use: official) | | |
| Qualification: | Occupational Therapy Board Register* Identifier: NZOCC/96-20154 (use: official)
* Valid Period: 2021-04-01 --> 2022-03-31
* Issued By: [Reference Organization G00000-E (https://standards.digital.health.nz/ns/hpi-organisation-id#HPIOrganization#G00000-E (use: official))](Organization-G00000-E.md)
 | | |
| Language: | English | | |
| null: | * fullname: Bachelor of Occupational Therapy
* year: 2009
* institution: Wintec
* city: HAMILTON
* country: NZ
 | | |
| null: | * fullname: Master of Occupational Therapy
* year: 2019
* institution: Otago Polytechnic
* city: DUNEDIN
* country: NZ
 | | |
| [NZ Ethnicity](https://fhir.org.nz/ig/base/StructureDefinition-nz-ethnicity.html) | New Zealand European | | |



## Resource Content

```json
{
  "resourceType" : "Practitioner",
  "id" : "91ZABY",
  "meta" : {
    "versionId" : "10952",
    "lastUpdated" : "2022-12-20T09:27:27.000+13:00",
    "profile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPIPractitioner"],
    "security" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-Confidentiality",
      "code" : "L"
    }]
  },
  "extension" : [{
    "url" : "http://hl7.org.nz/fhir/StructureDefinition/nz-ethnicity",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "https://standards.digital.health.nz/ns/ethnic-group-level-4-code",
        "version" : "2.1.0",
        "code" : "11111",
        "display" : "New Zealand European"
      }],
      "text" : "New Zealand European"
    }
  },
  {
    "extension" : [{
      "url" : "fullname",
      "valueString" : "Bachelor of Occupational Therapy"
    },
    {
      "url" : "year",
      "valueDate" : "2009"
    },
    {
      "url" : "institution",
      "valueString" : "Wintec"
    },
    {
      "url" : "city",
      "valueString" : "HAMILTON"
    },
    {
      "url" : "country",
      "valueString" : "NZ"
    }],
    "url" : "http://hl7.org.nz/fhir/StructureDefinition/educational-qualification"
  },
  {
    "extension" : [{
      "url" : "fullname",
      "valueString" : "Master of Occupational Therapy"
    },
    {
      "url" : "year",
      "valueDate" : "2019"
    },
    {
      "url" : "institution",
      "valueString" : "Otago Polytechnic"
    },
    {
      "url" : "city",
      "valueString" : "DUNEDIN"
    },
    {
      "url" : "country",
      "valueString" : "NZ"
    }],
    "url" : "http://hl7.org.nz/fhir/StructureDefinition/educational-qualification"
  }],
  "identifier" : [{
    "use" : "official",
    "system" : "https://standards.digital.health.nz/ns/hpi-person-id",
    "value" : "91ZABY",
    "assigner" : {
      "reference" : "Organization/G00001-G"
    }
  },
  {
    "use" : "official",
    "system" : "https://standards.digital.health.nz/ns/occupational-therapy-board-id",
    "value" : "96-20154",
    "assigner" : {
      "reference" : "Organization/G00000-E"
    }
  }],
  "name" : [{
    "use" : "official",
    "family" : "Rhode",
    "given" : ["Lyndi", "Jane"],
    "prefix" : ["ms"]
  }],
  "gender" : "female",
  "birthDate" : "1975-01-19",
  "qualification" : [{
    "extension" : [{
      "extension" : [{
        "url" : "status",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://standards.digital.health.nz/ns/practitioner-registration-status-code",
            "version" : "2.0",
            "code" : "current",
            "display" : "A provider who holds or is deemed to hold a current practising certificate."
          }],
          "text" : "A provider who holds or is deemed to hold a current practising certificate."
        }
      },
      {
        "url" : "period",
        "valuePeriod" : {
          "start" : "2009-02-01"
        }
      }],
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/registration-status-code"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://standards.digital.health.nz/ns/practitioner-scope-of-practice-code",
            "version" : "2.1.0",
            "code" : "OCCT",
            "display" : "Occupational Therapist"
          }],
          "text" : "Occupational Therapist"
        }
      },
      {
        "url" : "period",
        "valuePeriod" : {
          "start" : "2009-02-01"
        }
      }],
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/scope-of-practice"
    },
    {
      "extension" : [{
        "url" : "description",
        "valueString" : "Must complete annual eye test"
      },
      {
        "url" : "period",
        "valuePeriod" : {
          "start" : "2019-09-19"
        }
      }],
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/condition-on-practice"
    },
    {
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/registration-initial-date",
      "valueDate" : "2009-02-01"
    }],
    "identifier" : [{
      "use" : "official",
      "system" : "https://standards.digital.health.nz/ns/occupational-therapy-board-id",
      "value" : "96-20154",
      "assigner" : {
        "reference" : "Organization/G00000-E"
      }
    }],
    "code" : {
      "coding" : [{
        "system" : "https://standards.digital.health.nz/ns/practitioner-registration-authority-code",
        "version" : "2.1",
        "code" : "OT",
        "display" : "Occupational Therapy Board Register"
      }],
      "text" : "Occupational Therapy Board Register"
    },
    "period" : {
      "start" : "2021-04-01",
      "end" : "2022-03-31"
    },
    "issuer" : {
      "reference" : "Organization/G00000-E"
    }
  }],
  "communication" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:639:-3",
      "version" : "2007",
      "code" : "eng",
      "display" : "English"
    }],
    "text" : "English"
  }]
}

```
