# GZZ999-J - New Zealand HPI Implementation Guide v1.5.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GZZ999-J**

## Example Organization: GZZ999-J

Profile: [HPI Organization](StructureDefinition-HpiOrganization.md)

Reference Organization GZZ999-J (https://standards.digital.health.nz/ns/hpi-organisation-id#HPIOrganization#GZZ999-J (use: official))

-------

| | |
| :--- | :--- |
| Active: | true |



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "GZZ999-J",
  "meta" : {
    "profile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization"]
  },
  "identifier" : [{
    "use" : "official",
    "system" : "https://standards.digital.health.nz/ns/hpi-organisation-id",
    "value" : "GZZ999-J"
  }],
  "active" : true,
  "name" : "Reference Organization GZZ999-J"
}

```
