# Search Facility - New Zealand HPI Implementation Guide v1.5.0

* [**Table of Contents**](toc.md)
* **Search Facility**

## Search Facility

### Search Facility Overview

The Search facility use case describes how a user can search for:

* a specific facility using known facility demographics (e.g. name, address),
* all facilities in a specific DHB catchment area
* all facilities of a specific type in the HPI e.g. all pharmacy records in the HPI
* all facilities with a given Managing Organisation

[For all the facility search parameters click here](/capabilityStatement.md#location)

### Search Facility by name

This operation is used to search for a specific facility using known facilities demographics.

**Search Facility by name processing steps:**

1. The user of the integrating application searches for a Facility by entering the Facility name
1. The integrating application sends an HTTP GET request for the Location resource using the name as a search parameter E.g. GET<Endpoint>/Location?name=Pukekohe Diamond Doctors
1. The request is validated - ALT: Validation failure. Operation Outcome resource returned
1. The matching facilities are retrieved from the HPI
1. The response containing a bundle of matching facilities is returned to the integrating application
1. The integrating application displays the matching locations to the user

[For all the facility search parameters click here](/capabilityStatement.md#location)

### Search Facility by type

This search operation allows a user to search for all facilities of a specific type e.g. return all pharmacies in the HPI. The API defaults to return only 10 records. [To learn more about searching and get more than the default 10 records see additional search information](/general.md#additional-search-parameters).

**Search Facility by type processing steps:**

1. The user of the integrating application searches for a list of facilities by entering the facility type
1. The integrating application sends an HTTP GET request for the Location resource using type as a search parameter E.g. GET<Endpoint>/Location?type=pharm
1. The request is validated - ALT: Validation failure. Operation Outcome resource returned
1. The first 10 matching facilities are retrieved from the HPI
1. The response containing a bundle of matching facilities is returned to the integrating application
1. The integrating application displays the matching locations to the user
1. [To get more than the default 10 records see additional search information](/general.md#additional-search-parameters)to learn about the _count and _offset parameters

[For all the facility search parameters click here](/capabilityStatement.md#location)

