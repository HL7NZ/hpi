# MBIE - New Zealand HPI Implementation Guide v1.4.10

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MBIE**

## Example Organization: MBIE

Profile: [HPI Organization](StructureDefinition-HpiOrganization.md)

Ministry of Business, Innovation and Employment (https://standards.digital.health.nz/ns/hpi-organisation-id#HPIOrganization#MBIE (use: official))

-------

| | |
| :--- | :--- |
| Active: | true |



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "MBIE",
  "meta" : {
    "profile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization"]
  },
  "identifier" : [{
    "use" : "official",
    "system" : "https://standards.digital.health.nz/ns/hpi-organisation-id",
    "value" : "MBIE"
  }],
  "active" : true,
  "name" : "Ministry of Business, Innovation and Employment"
}

```
