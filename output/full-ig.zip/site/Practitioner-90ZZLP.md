# 90ZZLP - New Zealand HPI Implementation Guide v1.5.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **90ZZLP**

## Example Practitioner: 90ZZLP

version: 9971; Last updated: 2022-04-07 09:12:26+1200

Profile: [HPI Practitioner](StructureDefinition-HPIPractitioner.md)

Security Labels: [redacted (Details: ObservationValue code REDACTED = 'redacted')](http://terminology.hl7.org/7.5.0/CodeSystem-v3-ObservationValue.html), [restricted (Details: Confidentiality code R = 'restricted')](http://terminology.hl7.org/7.5.0/CodeSystem-v3-Confidentiality.html)

Anonymous Practitioner (https://standards.digital.health.nz/ns/hpi-person-id#HPIProvider#90ZZLP (use: official))

-------



## Resource Content

```json
{
  "resourceType" : "Practitioner",
  "id" : "90ZZLP",
  "meta" : {
    "versionId" : "9971",
    "lastUpdated" : "2022-04-07T09:12:26.000+12:00",
    "profile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPIPractitioner"],
    "security" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationValue",
      "code" : "REDACTED"
    },
    {
      "system" : "http://terminology.hl7.org/CodeSystem/v3-Confidentiality",
      "code" : "R"
    }]
  },
  "identifier" : [{
    "use" : "official",
    "system" : "https://standards.digital.health.nz/ns/hpi-person-id",
    "value" : "90ZZLP",
    "assigner" : {
      "reference" : "Organization/G00001-G"
    }
  }]
}

```
