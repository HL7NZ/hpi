# Practitioner-update-educational-qualification - New Zealand HPI Implementation Guide v1.4.10

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Practitioner-update-educational-qualification**

## OperationDefinition: Practitioner-update-educational-qualification 

| | |
| :--- | :--- |
| *Official URL*:https://hpi-ig.hip.digital.health.nz/OperationDefinition/practitioner-update-educational-qualification | *Version*:1.4.10 |
| Draft as of 2026-10-07 | *Computable Name*:Update Educational Qualification |

 
Adds, amends, or removes educational qualifications from a Practitioner record by applying one or more validated qualification change items. 



## Resource Content

```json
{
  "resourceType" : "OperationDefinition",
  "id" : "Practitioner-update-educational-qualification",
  "url" : "https://hpi-ig.hip.digital.health.nz/OperationDefinition/practitioner-update-educational-qualification",
  "version" : "1.4.10",
  "name" : "Update Educational Qualification",
  "title" : "Updates a practitioner's educational qualifications",
  "status" : "draft",
  "kind" : "operation",
  "experimental" : false,
  "date" : "2026-10-07T00:00:00+12:00",
  "publisher" : "Te Whatu Ora",
  "contact" : [{
    "name" : "Te Whatu Ora",
    "telecom" : [{
      "system" : "email",
      "value" : "mailto:integration@health.govt.nz"
    }]
  }],
  "description" : "Adds, amends, or removes educational qualifications from a Practitioner record by applying one or more validated qualification change items.",
  "affectsState" : true,
  "code" : "practitioner-update-educational-qualification",
  "comment" : "The cpn and version-id are validated, the caller context is checked, and each repeated educational-qualification item is validated and applied before the Practitioner record is updated.",
  "resource" : ["Practitioner"],
  "system" : false,
  "type" : false,
  "instance" : true,
  "parameter" : [{
    "name" : "cpn",
    "use" : "in",
    "min" : 1,
    "max" : "1",
    "documentation" : "The live hpi-person-id (CPN)",
    "type" : "string"
  },
  {
    "name" : "version-id",
    "use" : "in",
    "min" : 1,
    "max" : "1",
    "documentation" : "The current Practitioner record version number",
    "type" : "string"
  },
  {
    "name" : "ra-identifier",
    "use" : "in",
    "min" : 0,
    "max" : "1",
    "documentation" : "The Responsible Authority identifier for the caller when an RA context is in use",
    "type" : "string"
  },
  {
    "name" : "educational-qualification",
    "use" : "in",
    "min" : 1,
    "max" : "*",
    "documentation" : "One or more educational qualification change items to add, amend or remove",
    "type" : "string"
  },
  {
    "name" : "educational-qualification.action",
    "use" : "in",
    "min" : 1,
    "max" : "1",
    "documentation" : "The action to apply to the qualification item: add, amend or remove",
    "type" : "code"
  },
  {
    "name" : "educational-qualification.id",
    "use" : "in",
    "min" : 0,
    "max" : "1",
    "documentation" : "The existing HPI educational qualification identifier. Required for amend and remove operations.",
    "type" : "string"
  },
  {
    "name" : "educational-qualification.fullname",
    "use" : "in",
    "min" : 0,
    "max" : "1",
    "documentation" : "The full name of the educational qualification. Required for add and amend",
    "type" : "string"
  },
  {
    "name" : "educational-qualification.shortname",
    "use" : "in",
    "min" : 0,
    "max" : "1",
    "documentation" : "A short form of the qualification name",
    "type" : "string"
  },
  {
    "name" : "educational-qualification.year",
    "use" : "in",
    "min" : 0,
    "max" : "1",
    "documentation" : "The year the qualification was awarded. Required for add and amend.",
    "type" : "date"
  },
  {
    "name" : "educational-qualification.institution",
    "use" : "in",
    "min" : 0,
    "max" : "1",
    "documentation" : "The institution or training provider that issued the qualification. Required for add and amend.",
    "type" : "string"
  },
  {
    "name" : "educational-qualification.city",
    "use" : "in",
    "min" : 0,
    "max" : "1",
    "documentation" : "The city where the institution is located. Required for add and amend.",
    "type" : "string"
  },
  {
    "name" : "educational-qualification.country",
    "use" : "in",
    "min" : 0,
    "max" : "1",
    "documentation" : "The country where the institution is located, using a valid ISO alpha-2 country code. Required for add and amend.",
    "type" : "code"
  },
  {
    "name" : "Practitioner",
    "use" : "out",
    "min" : 0,
    "max" : "1",
    "documentation" : "The updated Practitioner resource",
    "type" : "Practitioner"
  },
  {
    "name" : "failure",
    "use" : "out",
    "min" : 0,
    "max" : "1",
    "documentation" : "Error response",
    "type" : "OperationOutcome"
  }]
}

```
