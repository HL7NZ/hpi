# Terminology - New Zealand HPI Implementation Guide v1.4.11

* [**Table of Contents**](toc.md)
* **Terminology**

## Terminology

This page provides a list of the FHIR terminology artifacts defined as part of this implementation guide.

### Code Systems


### ValueSets

|
|

### Concept Maps

|
|

