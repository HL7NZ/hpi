# 99ZZZS - New Zealand HPI Implementation Guide v1.4.10

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **99ZZZS**

## Example Practitioner: 99ZZZS

Profile: [HPI Practitioner](StructureDefinition-HPIPractitioner.md)

Practitioner Example (official) (https://standards.digital.health.nz/ns/hpi-person-id#HPIProvider#99ZZZS (use: official))

-------



## Resource Content

```json
{
  "resourceType" : "Practitioner",
  "id" : "99ZZZS",
  "meta" : {
    "profile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPIPractitioner"]
  },
  "identifier" : [{
    "use" : "official",
    "system" : "https://standards.digital.health.nz/ns/hpi-person-id",
    "value" : "99ZZZS",
    "assigner" : {
      "reference" : "Organization/G00001-G"
    }
  }],
  "name" : [{
    "use" : "official",
    "family" : "Example",
    "given" : ["Practitioner"]
  }]
}

```
