# Get Practitioner - New Zealand HPI Implementation Guide v1.4.10

* [**Table of Contents**](toc.md)
* **Get Practitioner**

## Get Practitioner

### Get Practitioner Overview

A Practitioner read request returns a Practitioner record with the following attributes (if populated):

* The ‘last updated single instance’ from all the HPI sources of Practitioner information: 
* deathdate,
* official and usual names,
* set of languages (Practitioner.communication, and
 
* All: 
* educational qualifications,
* ‘old’ names, and
* registraion details (Practitioner.qualification)
 

A user with administration permissions will also see the ‘last updated single instance’ from across all sources:

* set of ethnicities,
* gender, and
* birthdate.

### Get Practitioner using an hpi-person-id (HPI-CPN)

**Get Practitioner processing steps:**

1. The user supplies an hpi-person-id number for the Practitioner to be looked up.
1. The integrating application sends an HTTP GET request for the Practitioner resource using the hpi-person-id to identify the Practitioner whose information is being requested. E.g. GET<Endpoint>/Practitioner/99ZZRT
1. The request is validated - ALT: Validation failure. OperationOutcome resource returned
1. The Practitioner resource is retrieved from the HPI - ALT: Practitioner not found. OperationOutcome resource returned
1. The response containing the Practitioner resource is returned

#### Get Practitioner Rules and errors

* Rule: A Practitioner read request must include a valid hpi-person-id
  * Error code: * EM07240

  * Error description: * Resource not found

  * Error text / expression: * Practitioner.identifier:HPI

  * Http code: * 404 Not found


### Query Practitioner using the registration authority identifier

To query a Practitioner with a registration authority identifier (E.g. nursing-council-id) the integrating application sends an HTTP GET request for the Practitioner resource using the registration authority identifier and identifiying the required register.

[For more information on read vs query click here](/general.md#read-resource-by-id)

**Query Practitioner processing step E.g.nursing-council-id:**

1. The user supplies the system (https://standards.digital.health.nz/ns/nursing-council-id) and identifier (nursing-council-id) for the Practitioner.
1. The integrating application sends an HTTP GET request for the Practitioner resource using the nursing council identifier to identify the Practitioner whose information is being requested. E.g. GET<Endpoint>/Practitioner?identifier=https://standards.digital.health.nz/ns/nursing-council-id|961049
1. The request is validated - ALT: Validation failure. OperationOutcome resource returned
1. The Practitioner resource is retrieved from the HPI - ALT: Practitioner not found. OperationOutcome resource returned
1. The response containing a bundle with a single Practitioner record is returned
1. The integrating application displays the practitioner details to the user

[For a full list of identifiers click here](https://fhir.org.nz/ig/base/namingSystems.html)

#### Query Practitioner Rules and errors

* Rule: A Practitioner query request must include a valid registration authority identifier and 'system'
  * Error code: * EM07208
* EM07240

  * Error description: * Value is invalid
* Resource not found

  * Error text / expression: * Practitioner.identifier.system
* Practitioner.identifier:RA

  * Http code: * 422 Unknown
* 404 Not found


