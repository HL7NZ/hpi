# GZZ991-D - New Zealand HPI Implementation Guide v1.5.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GZZ991-D**

## Example Organization: GZZ991-D

version: 8961; Last updated: 2022-04-05 15:04:28+1200

Profile: [HPI Organization](StructureDefinition-HpiOrganization.md)

Second Name (Education Institutions) (https://standards.digital.health.nz/ns/hpi-organisation-id#HPIOrganization#GZZ991-D (use: official))

-------

| | |
| :--- | :--- |
| Active: | true |
| Type: | Education Institutions |
| Alias: | * Wha Name
* Third Name
* Second Name
* Multiple Names Org
 |
| Part Of: | [Multiple sub-organisation](Organization-GZZ836-C.md) |
| Other Ids: | * HPIOrganization/9006 (use: official)
* NBN/9999999999009 (use: official)
 |
| Contact Detail | * [ghi@email.com](mailto:ghi@email.com)
* ph: 027 123555(Work)
 |
|  | 2009-09-09 --> (ongoing) |



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "GZZ991-D",
  "meta" : {
    "versionId" : "8961",
    "lastUpdated" : "2022-04-05T15:04:28.000+12:00",
    "profile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization"]
  },
  "extension" : [{
    "url" : "http://hl7.org.nz/fhir/StructureDefinition/established",
    "valuePeriod" : {
      "start" : "2009-09-09"
    }
  }],
  "identifier" : [{
    "use" : "official",
    "system" : "https://standards.digital.health.nz/ns/hpi-organisation-id",
    "value" : "GZZ991-D",
    "assigner" : {
      "reference" : "Organization/G00001-G"
    }
  },
  {
    "use" : "official",
    "system" : "https://standards.digital.health.nz/ns/nzhis-agency-id",
    "value" : "9006",
    "assigner" : {
      "reference" : "Organization/G00001-G"
    }
  },
  {
    "use" : "official",
    "system" : "https://standards.digital.health.nz/ns/hpi-nzbn",
    "value" : "9999999999009",
    "assigner" : {
      "reference" : "Organization/MBIE"
    }
  }],
  "active" : true,
  "type" : [{
    "coding" : [{
      "system" : "https://standards.digital.health.nz/ns/organisation-type-code",
      "version" : "1.2",
      "code" : "008",
      "display" : "Education Institutions"
    }]
  }],
  "name" : "Second Name",
  "alias" : ["Wha Name", "Third Name", "Second Name", "Multiple Names Org"],
  "_alias" : [{
    "extension" : [{
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/alias-type",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://standards.digital.health.nz/ns/alias-type-code",
          "version" : "1.0.0",
          "code" : "maori",
          "display" : "Māori"
        }],
        "text" : "Māori"
      }
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/alias-type",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://standards.digital.health.nz/ns/alias-type-code",
          "version" : "1.0.0",
          "code" : "aka",
          "display" : "Aka"
        }],
        "text" : "Aka"
      }
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/alias-type",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://standards.digital.health.nz/ns/alias-type-code",
          "version" : "1.0.0",
          "code" : "trade-as",
          "display" : "Trading as"
        }],
        "text" : "Trading as"
      }
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/alias-type",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://standards.digital.health.nz/ns/alias-type-code",
          "version" : "1.0.0",
          "code" : "legal",
          "display" : "Legal"
        }],
        "text" : "Legal"
      }
    }]
  }],
  "telecom" : [{
    "system" : "email",
    "value" : "ghi@email.com",
    "use" : "work",
    "rank" : 1,
    "period" : {
      "start" : "2019-11-11"
    }
  },
  {
    "system" : "phone",
    "value" : "027 123555",
    "use" : "work",
    "rank" : 2,
    "period" : {
      "start" : "2019-11-11"
    }
  }],
  "partOf" : {
    "reference" : "Organization/GZZ836-C",
    "display" : "Multiple sub-organisation"
  }
}

```
