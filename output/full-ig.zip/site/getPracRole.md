# Get Prac Role - New Zealand HPI Implementation Guide v1.4.10

* [**Table of Contents**](toc.md)
* **Get Prac Role**

## Get Prac Role

### Read PractitionerRole with Identifier (hpi-practitionerrole-id)

Read PractitionerRole processing steps:

1. The user supplies an hpi-practitionerrole-id for the PractitionerRole to be looked up.
1. The integrating application sends an HTTP GET request for the PractitionerRole resource using the hpi-practitionerrole-id to identify the PractitionerRole whose information is being requested E.g. GET<Endpoint>/PractitionerRole/R00000009-H.
1. The request is validated - ALT: Validation failure. OperationOutcome resource returned
1. The PractitionerRole resource is retrieved from the HPI - ALT: PractitionerRole not found. OperationOutcome resource returned
1. The response containing the PractitionerRole resource is returned

### Query PractitionerRole with another identifier (hpi-person-id)

To query a PractitionerRole with ‘another identifier' the integrating application sends an HTTP GET request for the PractitionerRole resource using the ‘other identifier’ to identify the Practitioner whose information is being requested.

[To review searching by other identifiers click here](/searchPracRole.md#search-prac-role)

[For more information on read vs query click here](/general.md#read-resource-by-id)

### Get PractitionerRole Rules and errors

[For Request rules and errors click here](/general.md#request-rules-and-errors)

* **Get PractitionerRole rules** 
* A PractitionerRole read request must include a valid hpi-practitionerrole-id
 
* **Get PractitionerRole errors** 
* **“Invalid id: ” (HTTP 404 Not found, Error, Processing)**
 

