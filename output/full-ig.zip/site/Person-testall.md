# testall - New Zealand HPI Implementation Guide v1.4.10

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **testall**

## Example Person: testall

**name**: Test All



## Resource Content

```json
{
  "resourceType" : "Person",
  "id" : "testall",
  "name" : [{
    "use" : "usual",
    "text" : "Test All"
  }]
}

```
