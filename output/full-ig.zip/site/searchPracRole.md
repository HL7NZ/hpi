# Search Prac Role - New Zealand HPI Implementation Guide v1.4.10

* [**Table of Contents**](toc.md)
* **Search Prac Role**

## Search Prac Role

### Search PractitionerRole by Practitioner (hpi-person-id)

**Search PractitionerRole by Practitioner (hpi-person-id) Processing steps**

1. The user initiates searching a PractitionerRole in the integrating application.
1. The integrating application sends an HTTP GET request (a FHIR search) for the list of PractitionerRole resources that reference the Practitioner resource for the supplied hpi-person-id E.g. GET<Endpoint>/PractitionerRole?practitioner=99ZZZZ
1. The request is validated - ALT: Validation failure. OperationOutcome resource returned
1. The PractitionerRole resources related to the supplied hpi-person-id are retrieved from the HPI - ALT: No PractitionerRole resources found. OperationOutcome resource returned
1. The response containing a bundle of PractitionerRole resources is returned
1. The consuming application displays the matching Practitioner Role details to the user

### Using _ include parameter

When specified by _ include, the Practitioner, Organization and Location records are included in the response 
 **Note:** This requires read permission on the included resource 
 E.g. GET<Endpoint>/PractitionerRole?practitioner=99ZZZS&_include=PractitionerRole:practitioner

[For more information on search PractitionerRole click here](/capabilityStatement.md#practitionerrole)

### Search PractitionerRole Rules and errors

[For Request rules and errors click here](/general.md#request-rules-and-errors)

* **Search PractitionerRole rules** 
* A PractitionerRole search request must include a valid hpi-person-id
* A PractitionerRole search may include: 
* hpi-facility-id
* hpi-organisation-id
* role
* active status
 
 
* **Search PractitionerRole errors** 
* **"Practitioner required" (HTTP 422 Unknown, Error, Processing)**
 

