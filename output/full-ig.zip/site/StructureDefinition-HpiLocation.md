# HPI Location - New Zealand HPI Implementation Guide v1.4.11

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **HPI Location**

## Resource Profile: HPI Location 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.org.nz/fhir/StructureDefinition/HPILocation | *Version*:1.4.11 |
| Active as of 2026-11-03 | *Computable Name*:HpiLocation |

 
A physical location from which health goods and/or services are provided. They are also referred to as an HPI Facility. 

The Location resource represents named Facilities at which an organisation provides health services

HPI Facilities each have an identifier in the format FXXNNN-C where X is alphanumeric, N is numeric and C is a check character

A facility can only be related to a single organisation (location.managingOrganization).

There can be many facilities at the same address – each related to a different organisation.

An organisation may have multiple facilities at the same address – each with a different purpose.

**Usages:**

* Refer to this Profile: [HPI Practitioner role](StructureDefinition-HPIPractitionerRole.md) and [HPI Location](StructureDefinition-HpiLocation.md)
* Examples for this Profile: [Dental Clinic with Dist Date](Location-FZZ941-D.md), [Medical Centre Flat-Unit](Location-FZZ958-K.md) and [Live Facilty](Location-FZZ999-B.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/hl7.org.nz.fhir.ig.hpi|current/StructureDefinition/StructureDefinition-HpiLocation.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-HpiLocation.csv), [Excel](StructureDefinition-HpiLocation.xlsx), [Schematron](StructureDefinition-HpiLocation.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "HpiLocation",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-category",
    "valueString" : "Base.Entities"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-security-category",
    "valueCode" : "business"
  }],
  "url" : "http://hl7.org.nz/fhir/StructureDefinition/HPILocation",
  "version" : "1.4.11",
  "name" : "HpiLocation",
  "title" : "HPI Location",
  "status" : "active",
  "date" : "2026-11-03T01:19:24+00:00",
  "publisher" : "Te Whatu Ora",
  "contact" : [{
    "name" : "Te Whatu Ora",
    "telecom" : [{
      "system" : "email",
      "value" : "mailto:integration@health.govt.nz"
    }]
  }],
  "description" : "A physical location from which health goods and/or services are provided.  They are also referred to as an HPI Facility.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Location",
  "baseDefinition" : "http://hl7.org.nz/fhir/StructureDefinition/NzLocation",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Location",
      "path" : "Location"
    },
    {
      "id" : "Location.extension:dhb",
      "path" : "Location.extension",
      "sliceName" : "dhb",
      "short" : "The identifier for the DHB that is associated with this location"
    },
    {
      "id" : "Location.extension:established",
      "path" : "Location.extension",
      "sliceName" : "established",
      "short" : "The date when this location first became available for use"
    },
    {
      "id" : "Location.extension:funded-programme",
      "path" : "Location.extension",
      "sliceName" : "funded-programme",
      "max" : "0"
    },
    {
      "id" : "Location.extension:pho",
      "path" : "Location.extension",
      "sliceName" : "pho",
      "max" : "0"
    },
    {
      "id" : "Location.extension:messaging-address",
      "path" : "Location.extension",
      "sliceName" : "messaging-address",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.org.nz/fhir/StructureDefinition/messaging-address"]
      }]
    },
    {
      "id" : "Location.identifier",
      "path" : "Location.identifier",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "use"
        },
        {
          "type" : "value",
          "path" : "system"
        }],
        "rules" : "open"
      },
      "min" : 1
    },
    {
      "id" : "Location.identifier.use",
      "path" : "Location.identifier.use",
      "short" : "official | old",
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://nzhts.digital.health.nz/fhir/ValueSet/hpi-identifier-use-code"
      }
    },
    {
      "id" : "Location.identifier.type",
      "path" : "Location.identifier.type",
      "max" : "0"
    },
    {
      "id" : "Location.identifier.period",
      "path" : "Location.identifier.period",
      "max" : "0"
    },
    {
      "id" : "Location.identifier:facId",
      "path" : "Location.identifier",
      "sliceName" : "facId",
      "short" : "The current Facility id for this location",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Location.identifier:facId.use",
      "path" : "Location.identifier.use",
      "short" : "fixed to official",
      "min" : 1,
      "fixedCode" : "official"
    },
    {
      "id" : "Location.identifier:facId.system",
      "path" : "Location.identifier.system",
      "min" : 1,
      "fixedUri" : "https://standards.digital.health.nz/ns/hpi-facility-id"
    },
    {
      "id" : "Location.identifier:facId.assigner",
      "path" : "Location.identifier.assigner",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization"]
      }]
    },
    {
      "id" : "Location.identifier:dormant",
      "path" : "Location.identifier",
      "sliceName" : "dormant",
      "short" : "Old facility id's that have been deprecated",
      "min" : 0,
      "max" : "*",
      "mustSupport" : true
    },
    {
      "id" : "Location.identifier:dormant.use",
      "path" : "Location.identifier.use",
      "short" : "fixed to old",
      "min" : 1,
      "fixedCode" : "old"
    },
    {
      "id" : "Location.identifier:dormant.system",
      "path" : "Location.identifier.system",
      "min" : 1,
      "fixedUri" : "https://standards.digital.health.nz/ns/hpi-facility-id"
    },
    {
      "id" : "Location.identifier:dormant.assigner",
      "path" : "Location.identifier.assigner",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization"]
      }]
    },
    {
      "id" : "Location.identifier:legacyFacId",
      "path" : "Location.identifier",
      "sliceName" : "legacyFacId",
      "short" : "The MOH (NZHIS) Legacy facility code)",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Location.identifier:legacyFacId.use",
      "path" : "Location.identifier.use",
      "short" : "fixed to official",
      "min" : 1,
      "fixedCode" : "official"
    },
    {
      "id" : "Location.identifier:legacyFacId.system",
      "path" : "Location.identifier.system",
      "min" : 1,
      "fixedUri" : "https://standards.digital.health.nz/ns/nzhis-facility-id"
    },
    {
      "id" : "Location.identifier:legacyFacId.assigner",
      "path" : "Location.identifier.assigner",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization"]
      }]
    },
    {
      "id" : "Location.status",
      "path" : "Location.status",
      "short" : "active | inactive",
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://nzhts.digital.health.nz/fhir/ValueSet/hpi-location-status-code"
      }
    },
    {
      "id" : "Location.operationalStatus",
      "path" : "Location.operationalStatus",
      "max" : "0"
    },
    {
      "id" : "Location.alias.extension:alias-type",
      "path" : "Location.alias.extension",
      "sliceName" : "alias-type",
      "short" : "The type of alias this is - eg its Maori name"
    },
    {
      "id" : "Location.alias.extension:alias-type.valueCodeableConcept",
      "path" : "Location.alias.extension.valueCodeableConcept",
      "binding" : {
        "strength" : "preferred",
        "valueSet" : "https://nzhts.digital.health.nz/fhir/ValueSet/location-alias-type-code"
      }
    },
    {
      "id" : "Location.mode",
      "path" : "Location.mode",
      "max" : "0"
    },
    {
      "id" : "Location.type",
      "path" : "Location.type",
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://nzhts.digital.health.nz/fhir/ValueSet/location-type-code"
      }
    },
    {
      "id" : "Location.telecom.use",
      "path" : "Location.telecom.use",
      "short" : "work | temp - purpose of this contact point",
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://nzhts.digital.health.nz/fhir/ValueSet/hpi-contact-point-use-code"
      }
    },
    {
      "id" : "Location.address",
      "path" : "Location.address",
      "type" : [{
        "code" : "Address",
        "profile" : ["http://hl7.org.nz/fhir/StructureDefinition/NzAddress"]
      }]
    },
    {
      "id" : "Location.address.use",
      "path" : "Location.address.use",
      "short" : "work | old - purpose of this address",
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://nzhts.digital.health.nz/fhir/ValueSet/hpi-location-address-use-code"
      }
    },
    {
      "id" : "Location.address.country",
      "path" : "Location.address.country",
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://nzhts.digital.health.nz/fhir/ValueSet/country-code"
      }
    },
    {
      "id" : "Location.physicalType",
      "path" : "Location.physicalType",
      "max" : "0"
    },
    {
      "id" : "Location.position",
      "path" : "Location.position",
      "max" : "0"
    },
    {
      "id" : "Location.managingOrganization",
      "path" : "Location.managingOrganization",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization"]
      }]
    },
    {
      "id" : "Location.partOf",
      "path" : "Location.partOf",
      "type" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-hierarchy",
          "valueBoolean" : true
        }],
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPILocation"]
      }]
    },
    {
      "id" : "Location.hoursOfOperation",
      "path" : "Location.hoursOfOperation",
      "max" : "0"
    },
    {
      "id" : "Location.availabilityExceptions",
      "path" : "Location.availabilityExceptions",
      "max" : "0"
    },
    {
      "id" : "Location.endpoint",
      "path" : "Location.endpoint",
      "max" : "0"
    }]
  }
}

```
