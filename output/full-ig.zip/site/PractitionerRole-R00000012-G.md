# R00000012-G - New Zealand HPI Implementation Guide v1.4.11

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **R00000012-G**

## Example PractitionerRole: R00000012-G

version: 13; Last updated: 2022-11-21 17:02:33+1300

Profile: [HPI Practitioner role](StructureDefinition-HPIPractitionerRole.md)

Security Label: [moderate (Details: Confidentiality code M = 'moderate')](http://terminology.hl7.org/7.4.0/CodeSystem-v3-Confidentiality.html)

Anonymous Practitioner (https://standards.digital.health.nz/ns/hpi-person-id#HPIProvider#90ZZLP (use: official)): Medical Receptionist at Referenced PractitionerRole Organization (https://standards.digital.health.nz/ns/hpi-organisation-id#HPIOrganization#GZZ998-G (use: official)) (https://standards.digital.health.nz/ns/hpi-practitionerrole-id#HPIPractitionerRole#R00000012-G (use: official))

-------

| | | | |
| :--- | :--- | :--- | :--- |
| Active: | false | Valid Period: | 2000-02-10 --> 2000-02-11 |
| Practitioner: | [Anonymous Practitioner (https://standards.digital.health.nz/ns/hpi-person-id#HPIProvider#90ZZLP (use: official))](Practitioner-90ZZLP.md) | | |
| Organization: | [Referenced PractitionerRole Organization (https://standards.digital.health.nz/ns/hpi-organisation-id#HPIOrganization#GZZ998-G (use: official))](Organization-GZZ998-G.md) | | |
| Role: | Medical Receptionist | | |
| Location: | [Live Facilty (Enrolling GP Practice) (https://standards.digital.health.nz/ns/hpi-facility-id#HPIFacility#FZZ999-B (use: official))](Location-FZZ999-B.md) | | |
| Contact Detail | * ph: 1324654788(Work)
* [infoooor@infooooor.com](mailto:infoooor@infooooor.com)
 | | |
| Messaging Address: | * provider: healthlink
* value: changed-edi-address
 | | |
|  | other | | |
| null: | * person: [Person Test All](Person-testall.md)
* organization: [HPI Root Organization (https://standards.digital.health.nz/ns/hpi-organisation-id#HPIOrganization#G00001-G (use: official))](Organization-G00001-G.md)
 | | |



## Resource Content

```json
{
  "resourceType" : "PractitionerRole",
  "id" : "R00000012-G",
  "meta" : {
    "versionId" : "13",
    "lastUpdated" : "2022-11-21T17:02:33.184+13:00",
    "profile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPIPractitionerRole"],
    "security" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-Confidentiality",
      "code" : "M"
    }]
  },
  "extension" : [{
    "url" : "http://hl7.org.nz/fhir/StructureDefinition/practitionerRole-status-reason",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "https://standards.digital.health.nz/ns/hpi-practitioner-role-status-reason-code",
        "version" : "1.0.0",
        "code" : "other",
        "display" : "other"
      }],
      "text" : "other"
    }
  },
  {
    "extension" : [{
      "url" : "person",
      "valueReference" : {
        "reference" : "Person/testall"
      }
    },
    {
      "url" : "organization",
      "valueReference" : {
        "reference" : "Organization/G00001-G"
      }
    }],
    "url" : "http://hl7.org.nz/fhir/StructureDefinition/practitionerRole-creator"
  },
  {
    "extension" : [{
      "url" : "provider",
      "valueString" : "healthlink"
    },
    {
      "url" : "value",
      "valueString" : "changed-edi-address"
    }],
    "url" : "http://hl7.org.nz/fhir/StructureDefinition/messaging-address"
  }],
  "identifier" : [{
    "use" : "official",
    "system" : "https://standards.digital.health.nz/ns/hpi-practitionerrole-id",
    "value" : "R00000012-G",
    "assigner" : {
      "reference" : "Organization/G00001-G"
    }
  }],
  "active" : false,
  "period" : {
    "start" : "2000-02-10",
    "end" : "2000-02-11"
  },
  "practitioner" : {
    "reference" : "Practitioner/90ZZLP"
  },
  "organization" : {
    "reference" : "Organization/GZZ998-G"
  },
  "code" : [{
    "coding" : [{
      "system" : "https://nzhts.digital.health.nz/fhir/CodeSystem/anzsco",
      "version" : "2022",
      "code" : "542114",
      "display" : "Medical Receptionist"
    }],
    "text" : "Medical Receptionist"
  }],
  "location" : [{
    "reference" : "Location/FZZ999-B"
  }],
  "telecom" : [{
    "system" : "phone",
    "value" : "1324654788",
    "use" : "work",
    "rank" : 1,
    "period" : {
      "start" : "2000-02-10",
      "end" : "2010-05-05"
    }
  },
  {
    "system" : "email",
    "value" : "infoooor@infooooor.com",
    "use" : "work",
    "rank" : 2,
    "period" : {
      "start" : "2000-02-10",
      "end" : "2010-05-06"
    }
  }]
}

```
