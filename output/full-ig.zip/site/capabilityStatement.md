# Capability Statement - New Zealand HPI Implementation Guide v1.5.0

* [**Table of Contents**](toc.md)
* **Capability Statement**

## Capability Statement

API summary (generated from the capabilityStatement resource)

This is the computable resource that describes the RESTful endpoint

### Practitioner

Practitioner query

**Interactions**

* Code: read
  * Documentation: GET, [base]/Practitioner[cpn],retrieve a Practitioner resource by Id, system/Practitioner.r
* Code: search-type
  * Documentation: GET,[base]/Practitioner, Queries against the Practitioner using name and other search parameters. Will return a Bundle (even if there are no matching resources),system/Practitioner.s
* Code: create
  * Documentation: POST',[base]/Practitioner, Creates a new Practitioner record , system/Practitioner.c

**Operations**

* Name: update-core
  * Definition: [ https://hpi-ig.hip.digital.health.nz/OperationDefinition/practitioner-update-core ](update-core.xml)
  * Documentation: POST, [base]/Practitioner[cpn],An operation that updates a health providers demographic details, system/Practitioner.u

**Search Parameters**

* Name: identifier
  * Type: [token](http://hl7.org/fhir/search.html#token)
  * Documentation: For searching a Practitioner resource using their council/board registration number
* Name: name
  * Type: [string](http://hl7.org/fhir/search.html#string)
  * Documentation: Should contain the person’s full name, include all given names and family name.
* Name: gender
  * Type: [token](http://hl7.org/fhir/search.html#token)
  * Documentation: Use with name and birthdate. Search by gender alone is not allowed.
* Name: birthdate
  * Type: [date](http://hl7.org/fhir/search.html#date)
  * Documentation: Use with name and gender. Search by birthdate alone is not allowed.

### PractitionerRole

PractitionerRole query

**Interactions**

* Code: read
  * Documentation: GET, [base]/PractitionerRole[id], Used to retrieve a PractitionerRole resource by Id, system/PractitionerRole.r
* Code: search-type
  * Documentation: GET, [base]/PractitionerRole, Queries against PractitionerRole using hpi-person-id and other parameters. Will return a Bundle (even if there are no matching resources), system/PractitionerRole.s
* Code: create
  * Documentation: POST, [base]/PractitionerRole, Create a new PractitionerRole, system/PractitionerRole.c
* Code: update
  * Documentation: PUT, [base]/PractitionerRole[id], Update contact details and end date on an existing PractitionerRole record, system/PractitionerRole.u

**Search Parameters**

* Name: practitioner
  * Type: [reference](http://hl7.org/fhir/search.html#reference)
  * Documentation: Given an hpi-person-id, returns the PractitionerRole records associated with that id
* Name: organization
  * Type: [reference](http://hl7.org/fhir/search.html#reference)
  * Documentation: Not yet enabled. Given an hpi-organization-id, returns the PractitionerRole records associated with that id
* Name: location
  * Type: [token](http://hl7.org/fhir/search.html#token)
  * Documentation: Given an hpi-facility-id, returns the PractitionerRole records associated with that id
* Name: role
  * Type: [token](http://hl7.org/fhir/search.html#token)
  * Documentation: Returns PractitionerRole records based on role code
* Name: active
  * Type: [token](http://hl7.org/fhir/search.html#token)
  * Documentation: To enable exclusion of inactive PractitionerRole records

**Search includes**

* Name: practitioner
* Name: organization
* Name: location

**These are the _include parameters that are supported on searches**

### Organization

Organization query

**Interactions**

* Code: read
  * Documentation: GET, [base]/Organization/[hpi-org-id], Used to retrieve an Organization resource by Id, system/Organization.r
* Code: search-type
  * Documentation: GET, [base]/Organization, Queries against the Organization using name or other parameters. Will return a Bundle (even if there are no matching resources), system/Organization.s

**Search Parameters**

* Name: active
  * Type: [token](http://hl7.org/fhir/search.html#token)
  * Documentation: To enable exclusion of inactive organizations
* Name: name
  * Type: [string](http://hl7.org/fhir/search.html#string)
  * Documentation: For searching using the organisation’s name or an alias name
* Name: identifier
  * Type: [token](http://hl7.org/fhir/search.html#token)
  * Documentation: For searching using an organisation’s New Zealand Business Number (NZBN) or their legacy NZHIS agency code.
* Name: type
  * Type: [token](http://hl7.org/fhir/search.html#token)
  * Documentation: For searching using an organisation's type E.g. DHB, RA, Educational institution
* Name: partOf
  * Type: [reference](http://hl7.org/fhir/search.html#reference)
  * Documentation: For retrieving organizations that are 'part of' another.

### Location

Location query

**Interactions**

* Code: read
  * Documentation: GET, [base]/Location/[hpi-facid], Used to retrieve an Location resource by Id, system/Location.r
* Code: search-type
  * Documentation: GET, [base]/Location, Queries against the Location using name or other parameters. Will return a Bundle (even if there are no matching resources), system/Location.s

**Search Parameters**

* Name: identifier
  * Type: [token](http://hl7.org/fhir/search.html#token)
  * Documentation: For searching using an organization’s legacy NZHIS facility code.
* Name: name
  * Type: [string](http://hl7.org/fhir/search.html#string)
  * Documentation: For searching using the Locations name or alias name
* Name: type
  * Type: [token](http://hl7.org/fhir/search.html#token)
  * Documentation: Retrieve Locations of the given type
* Name: address
  * Type: [string](http://hl7.org/fhir/search.html#string)
  * Documentation: Retrieve the Locations by address
* Name: organization
  * Type: [reference](http://hl7.org/fhir/search.html#reference)
  * Documentation: Retrieve Locations with the given ManagingOrganization
* Name: dhb
  * Type: [token](http://hl7.org/fhir/search.html#token)
  * Documentation: Searching for Locations that are in a DHBs catchment area.
* Name: status
  * Type: [token](http://hl7.org/fhir/search.html#token)
  * Documentation: Not yet enabled. To enable exclusion of inactive locations
* Name: messaging-address
  * Type: [string](http://hl7.org/fhir/search.html#string)
  * Documentation: Search by EDI address

