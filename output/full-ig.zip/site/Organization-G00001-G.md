# G00001-G - New Zealand HPI Implementation Guide v1.4.11

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **G00001-G**

## Example Organization: G00001-G

Profile: [HPI Organization](StructureDefinition-HpiOrganization.md)

HPI Root Organization (https://standards.digital.health.nz/ns/hpi-organisation-id#HPIOrganization#G00001-G (use: official))

-------

| | |
| :--- | :--- |
| Active: | true |



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "G00001-G",
  "meta" : {
    "profile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization"]
  },
  "identifier" : [{
    "use" : "official",
    "system" : "https://standards.digital.health.nz/ns/hpi-organisation-id",
    "value" : "G00001-G"
  }],
  "active" : true,
  "name" : "HPI Root Organization"
}

```
