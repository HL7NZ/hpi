# Facility Compliance Testing - New Zealand HPI Implementation Guide v1.4.10

* [**Table of Contents**](toc.md)
* **Facility Compliance Testing**

## Facility Compliance Testing

#### HPI Location/Facility GET

* Reference: HPI-L-Get-1
  * Purpose – Demonstrate that the: System behaves appropriately when a dormant hpi-facility-id is requested
  * Input values: FZZ997-J
  * Expected outcome: System does not errorSystem returns appropriate messaging to user
  * Mandatory: *Mandatory if appropriate for use case
* Reference: HPI-L-Get-2
  * Purpose – Demonstrate that the: System behaves appropriately when the location requested is no longer active
  * Input values: FZZ754-EFZZ753-C
  * Expected outcome: System returns appropriate messaging to user
  * Mandatory: *Mandatory if appropriate for use case
* Reference: HPI-L-Get-3
  * Purpose – Demonstrate that the: System behaves appropriately when more than one contact point is present
  * Input values: FZZ968-B
  * Expected outcome: Where appropriate all contact points are displayed to user
  * Mandatory: *Mandatory if appropriate for use case
* Reference: HPI-L-Get-4
  * Purpose – Demonstrate that the: System behaves appropriately when using the contact point rank
  * Input values: FZZ065-D
  * Expected outcome: When rank is present it is presented to user in an meaningful way
  * Mandatory: *Optional
* Reference: HPI-L-Get-5
  * Purpose – Demonstrate that the: System presents the address parts appropriately
  * Input values: FZZ961-KFZZ960-HFZZ959-AFZZ958-KFZZ065-D
  * Expected outcome: All address formats are displayed appropriately
  * Mandatory: *Mandatory if appropriate for use case
* Reference: HPI-L-Query-1
  * Purpose – Demonstrate that the: System behaves appropriately when a dormant hpi-facility-id is requested
  * Input values: NZHIS (Legacy) identifier Z999
  * Expected outcome: System does not errorSystem returns appropriate messaging to user
  * Mandatory: *Mandatory if appropriate for use case
* Reference: HPI-L-Query-2
  * Purpose – Demonstrate that the: System presents the address parts appropriately
  * Input values: NZHIS (Legacy) identifier 9987
  * Expected outcome: Address is displayed appropriately
  * Mandatory: *Mandatory if appropriate for use case

#### HPI Location/Facility Search

* Reference: HPI-L-Search-1-name
  * Purpose – Demonstrate that the: Minimum search criteria are included
  * Input values: Name = “Red Diamond”
  * Expected outcome: * Facility name is supplied and returns results 
* Search results are presented to user in order provided by the HPI, if not please provide a reason

  * Mandatory: *Mandatory if appropriate for use case
* Reference: HPI-L-Search-2-name
  * Purpose – Demonstrate that the: System behaves appropriately when the name search criteria better matches an alias than the name
  * Input values: Name = “Red Diamond Pukekohe”
  * Expected outcome: * System allows user to view aliases before selecting a result
* Alias= Red Diamond Pukekohe
* "Red Diamond Generic Medical Centre- Pukekohe

  * Mandatory: *Mandatory if appropriate for use case
* Reference: HPI-L-Search-3-address
  * Purpose – Demonstrate that the: System cn search for facility using the address
  * Input values: Address = "133 molesworth”
  * Expected outcome: * System allows user to search for facility by address
* Results used appropriately

  * Mandatory: *Mandatory if appropriate for use case
* Reference: HPI-L-Search-4-name and address
  * Purpose – Demonstrate that the: System can search for facility using name and address
  * Input values: * Name = Acupuncture
* Address = 133 molesworth

  * Expected outcome: * System allows user to search for facility by name and address
* Results used appropriately

  * Mandatory: *Mandatory if appropriate for use case
* Reference: HPI-L-Search-5-organization
  * Purpose – Demonstrate that the: System can search for facility using managing organization
  * Input values: * organization = GZZ018-B

  * Expected outcome: * System allows user to search for facility by managing organization
* Results used appropriately

  * Mandatory: *Mandatory if appropriate for use case
* Reference: HPI-L-Search-6-type
  * Purpose – Demonstrate that the: System can retrieve all facilities of a spcific type[Click here for more information on additional search parameters](general.md#additional-search-parameters)
  * Input values: Search for all facilities that are of a type appropriate to the use case e.g. pharm (pharmacies)
  * Expected outcome: * System allows user to search for facility by type
* Results used appropriately

  * Mandatory: *Mandatory if appropriate for use case
* Reference: HPI-L-Search-6-dhb
  * Purpose – Demonstrate that the: System can retrieve all facilities in a DHB catchment area[Click here for more information on additional search parameters](general.md#additional-search-parameters)
  * Input values: Search for all facilities that are in a DHB of interest for the use case e.g. G00011-K (Auckland District Health Board)
  * Expected outcome: * System allows user to search for facilities by DHB
* Results used appropriately

  * Mandatory: *Mandatory if appropriate for use case
* Reference: HPI-L-Search-7-name and dhb
  * Purpose – Demonstrate that the: System can search for facilities with a specific name in a DHB catchment area[Click here for more information on additional search parameters](general.md#additional-search-parameters)
  * Input values: Search for name = Plunket Clinic in DHB G00011-K (Auckland District Health Board)
  * Expected outcome: * System allows user to search for facilities by name and DHB
* Results used appropriately

  * Mandatory: *Mandatory if appropriate for use case

