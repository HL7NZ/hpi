# Organisation Compliance Testing - New Zealand HPI Implementation Guide v1.4.11

* [**Table of Contents**](toc.md)
* **Organisation Compliance Testing**

## Organisation Compliance Testing

#### HPI Organization GET

* Reference: HPI-O-Get-1
  * Purpose – Demonstrate that the: System behaves appropriately when a dormant hpi-organisation-id is requested
  * Input values: GZZ995-A
  * Expected outcome: System does not errorSystem returns appropriate messaging to user
  * Mandatory: *mandatory if appropriate for use case
* Reference: HPI-O-Get-2
  * Purpose – Demonstrate that the: System behaves appropriately when the organisation requested is no longer active
  * Input values: GZZ903-C
  * Expected outcome: System returns appropriate messaging to user
  * Mandatory: *mandatory if appropriate for use case
* Reference: HPI-O-Query-1
  * Purpose – Demonstrate that the: System behaves appropriately when a dormant hpi-organisation-id is requested
  * Input values: * NZBN - 9999999999003 
* Legacy agency code (NZHIS) - 9002

  * Expected outcome: System returns appropriate messaging to user
  * Mandatory: *mandatory if appropriate for use case
* Reference: HPI-O-Query-2
  * Purpose – Demonstrate that the: System behaves appropriately when the organisation requested is no longer active
  * Input values: * NZBN - 9999999999072 
* Legacy agency code (NZHIS) - 9975

  * Expected outcome: System returns appropriate messaging to user
  * Mandatory: *mandatory if appropriate for use case

#### HPI Organization SEARCH

* Reference: HPI-O-Search-1-name
  * Purpose – Demonstrate that the: Minimum search criteria are included
  * Input values: Search for ‘New Zealand Army’Search for ‘Hosptial Pharmacy’
  * Expected outcome: Organisation name is supplied and returns results
  * Mandatory: *mandatory if appropriate for use case
* Reference: HPI-O-Search-2-name
  * Purpose – Demonstrate that the: Search results are presented to user in order provided by the HPIif not please provide a reason
  * Input values: Use search results from above
  * Expected outcome: Results presented in order provided
  * Mandatory: *mandatory if appropriate for use case
* Reference: HPI-O-Search-3-name
  * Purpose – Demonstrate that the: System behaves appropriately when the name search criteria better matches an alias than the name
  * Input values: Search for ‘Discount Pharmaceuticals Limited’
  * Expected outcome: System allows user to view aliases before selecting a resultName= TryNSave Discount PharmacyAlias= Discount Pharmaceuticals LimitedHPI-O= GZZ869-G
  * Mandatory: *mandatory if appropriate for use case
* Reference: HPI-O-Search-3-name
  * Purpose – Demonstrate that the: System behaves appropriately when the name search criteria better matches an alias than the name
  * Input values: Search for ‘Discount Pharmaceuticals Limited’
  * Expected outcome: System allows user to view aliases before selecting a resultName= TryNSave Discount PharmacyAlias= Discount Pharmaceuticals LimitedHPI-O= GZZ869-G
  * Mandatory: *mandatory if appropriate for use case
* Reference: HPI-O-Search-4-partof
  * Purpose – Demonstrate that the: System can retrieve organisatons that are 'part of' another organisation
  * Input values: Search for organisatons that are 'part of' GZZ836-C
  * Expected outcome: System can display the organisations that are 'part of'GZZ836-C
  * Mandatory: *mandatory if appropriate for use case
* Reference: HPI-O-Search-5-type
  * Purpose – Demonstrate that the: System can retrieve all organisatons of a specific type[Click here for more information on additional search parameters](general.md#additional-search-parameters)
  * Input values: Search for organisatons that are of a type appropriate to the use case e.g. 009 Primary Health Organisation (PHO)
  * Expected outcome: System can retireve all organisations of specific type
  * Mandatory: *mandatory if appropriate for use case

