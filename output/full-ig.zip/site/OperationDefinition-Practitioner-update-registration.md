# Practitioner-update-registration - New Zealand HPI Implementation Guide v1.4.11

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Practitioner-update-registration**

## OperationDefinition: Practitioner-update-registration 

| | |
| :--- | :--- |
| *Official URL*:https://hpi-ig.hip.digital.health.nz/OperationDefinition/practitioner-update-registration | *Version*:1.4.11 |
| Draft as of 2026-10-07 | *Computable Name*:Update Registration |

 
Updates a practitioner's registration status, annual practising certificate details, scope of practice, additional authorisations and conditions. 



## Resource Content

```json
{
  "resourceType" : "OperationDefinition",
  "id" : "Practitioner-update-registration",
  "url" : "https://hpi-ig.hip.digital.health.nz/OperationDefinition/practitioner-update-registration",
  "version" : "1.4.11",
  "name" : "Update Registration",
  "title" : "Updates a practitioner's registration details",
  "status" : "draft",
  "kind" : "operation",
  "experimental" : false,
  "date" : "2026-10-07T00:00:00+12:00",
  "publisher" : "Te Whatu Ora",
  "contact" : [{
    "name" : "Te Whatu Ora",
    "telecom" : [{
      "system" : "email",
      "value" : "mailto:integration@health.govt.nz"
    }]
  }],
  "description" : "Updates a practitioner's registration status, annual practising certificate details, scope of practice, additional authorisations and conditions.",
  "affectsState" : true,
  "code" : "practitioner-update-registration",
  "comment" : "The cpn and version-id are validated, the caller RA context is checked, and the registration payload is validated and merged before the Practitioner record is updated.",
  "resource" : ["Practitioner"],
  "system" : false,
  "type" : false,
  "instance" : true,
  "parameter" : [{
    "name" : "cpn",
    "use" : "in",
    "min" : 1,
    "max" : "1",
    "documentation" : "The live hpi-person-id (CPN)",
    "type" : "string"
  },
  {
    "name" : "version-id",
    "use" : "in",
    "min" : 1,
    "max" : "1",
    "documentation" : "The current Practitioner record version number",
    "type" : "string"
  },
  {
    "name" : "ra-identifier",
    "use" : "in",
    "min" : 1,
    "max" : "1",
    "documentation" : "The Responsible Authority identifier for the caller",
    "type" : "string"
  },
  {
    "name" : "registration-initial-date",
    "use" : "in",
    "min" : 0,
    "max" : "1",
    "documentation" : "The initial registration date for the practitioner, if supplied",
    "type" : "date"
  },
  {
    "name" : "registration-status-code",
    "use" : "in",
    "min" : 1,
    "max" : "1",
    "documentation" : "A registration status code and period supplied as a FHIR parameter part",
    "type" : "string"
  },
  {
    "name" : "period",
    "use" : "in",
    "min" : 1,
    "max" : "1",
    "documentation" : "The APC validity period",
    "type" : "Period"
  },
  {
    "name" : "scope-of-practice",
    "use" : "in",
    "min" : 1,
    "max" : "*",
    "documentation" : "One or more scope of practice entries containing a code and period",
    "type" : "string"
  },
  {
    "name" : "additional-authorisation",
    "use" : "in",
    "min" : 0,
    "max" : "*",
    "documentation" : "One or more additional authorisation entries containing a code and period",
    "type" : "string"
  },
  {
    "name" : "condition-on-practice",
    "use" : "in",
    "min" : 0,
    "max" : "*",
    "documentation" : "One or more practice condition entries containing a description and period",
    "type" : "string"
  },
  {
    "name" : "Practitioner",
    "use" : "out",
    "min" : 0,
    "max" : "1",
    "documentation" : "The updated Practitioner resource",
    "type" : "Practitioner"
  },
  {
    "name" : "failure",
    "use" : "out",
    "min" : 0,
    "max" : "1",
    "documentation" : "Error response",
    "type" : "OperationOutcome"
  }]
}

```
