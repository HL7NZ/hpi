# Practitioner Role Compliance Testing - New Zealand HPI Implementation Guide v1.4.11

* [**Table of Contents**](toc.md)
* **Practitioner Role Compliance Testing**

## Practitioner Role Compliance Testing

#### HPI PractitionerRole minimum data requirements Get and Search

* Reference: HPI-PR-MD-1
  * Purpose – Demonstrate that the: application can Get a record using the hpi-practitionerrole-id
  * Input values: *  Get: R00000055-Q 
*  Search: NA 

  * Expected outcome: *  Input: 
* Get: HPI-PractitionerRole-id
* Search: NA 
 
* Output: 
*  Record returned and appropriate parts displayed correctly (use case dependent).
 

  * Mandatory: Mandatory - use case dependent
* Reference: HPI-PR-MD-2
  * Purpose – Demonstrate that the: application allows the user to search using the minimum search criteria and displays the search results in order appropriate to use case
  * Input values: * Get:N/A
* Search: Search criteria (practitioner).

  * Expected outcome: *  Input: 
* 97ZABV
 
*  Output: 
*  - Search results displayed in appropriate order (use case dependent).
 

  * Mandatory: Mandatory - use case dependent
* Reference: HPI-PR-MD-3
  * Purpose – Demonstrate that the: application allows the user to search using other search criteria depending on the use case.Make sure the search criteria you are using is relevant for the use case (Reference to Health Information Privacy Code 2020, Rule 1).
  * Input values: * Get:N/A
* Search: 
* Practitioner - 97ZABV
* Organisation - GZZ998-G
* Facility - FZZ961-K
* Role code - 542114
* Active - True / False
 

  * Expected outcome: *  Input: 
* hpi-person-id (CPN) an,
* other search criteria can be included
 
*  Output: 
*  - Search results displayed in appropriate order (use case dependent).
 

  * Mandatory: Mandatory - depdending on use case
* Reference: HPI-PR-MD-4
  * Purpose – Demonstrate that the: application will show the correct error when attempting to search without a Practitioner
  * Input values: * Get:N/A
* Search: using one of the other criteria only 
* Organisation
* Location
* Role
* Active(status)
 

  * Expected outcome: *  Input: 
* other search criteria provided
 
*  Output: 
*  - Error EM07201: Display Required value missing
 

  * Mandatory: Mandatory - depdending on use case
* Reference: HPI-PR-MD-5
  * Purpose – Demonstrate that the: application does not error, and can provide relevant information for each of the following scenarios.A PractitionerRole record with:1. Practitioner, Facility, Role code
1. Practitioner, Organisation, Role code
1. Practitioner, Organisation, Facility, Role code
1. Practitioner, Organisation, Facility, Role code, period

  * Input values: ** Do all **1. 
* Get:R00000161-P
* Search: practitioner:97ZABV, location:FZZ961-K, role:542111

1. 
* Get:R00000160-M
* Search: practitioner:97ZABV, organization:GZZ998-G, role:542111

1. 
* Get:R00000162-R
* Search: practitioner:97ZABV, location:FZZ961-K, organization:GZZ998-G, role:512211

1. 
* Get:R00000167-B
* Search: practitioner:97ZABV, location:FZZ961-K, organization:GZZ998-G, role:521111


  * Expected outcome: *  Input: 
* Get: HPI-PractitionerRole-id
* Search: Criteria provided 
 
* Output: 
*  Record returned and appropriate parts displayed correctly (use case dependent).
 

  * Mandatory: Mandatory - use case dependent
* Reference: HPI-PR-MD-6
  * Purpose – Demonstrate that the: application can make appropriate use of the facility messaging address and / or PractitionerRole messaging address.
  * Input values: ** Do both **1. PracRole without messaging address
* Get:PracRole-ID (withoutEDI)
* Search: Search criteria (withoutEDI).

1. PracRole with messaging address
* Get:PracRole-ID (withEDI)
* Search: Search criteria (withEDI).


  * Expected outcome: *  Input: 
* Get: HPI-PractitionerRole-id
* Search: Criteria provided 
 
* Output: 
*  application makes appropriate use of messaging address.
 

  * Mandatory: Mandatory - if using messaging address.
* Reference: HPI-PR-MD-7
  * Purpose – Demonstrate that the: application can make appropriate use of contact detailsA PractitionerRole record with:* an email address
* a phone number
* contact rank

  * Input values: * Get:Pracrole-ID (with email and phone).
* Search: Search criteria (with email and phone).

  * Expected outcome: *  Input: 
* Get: HPI-PractitionerRole-id
* Search: Criteria provided 
 
* Output: 
*  application makes appropriate use of contact details.
 

  * Mandatory: Mandatory - if using contact details
* Reference: HPI-PR-MD-8
  * Purpose – Demonstrate that the: application can make appropriate use of contact details where record has multiple sets, including contact rank.A PractitionerRole record with:* 2 email addresses
* 3 phone number's
* mixture of temp and work 
* contact rank

  * Input values: * Get:Pracrole-ID (with 2email and 3phone).
* Search: Search criteria (with 2email and 3phone).

  * Expected outcome: *  Input: 
* Get: HPI-PractitionerRole-id
* Search: Criteria provided 
 
* Output: 
*  application makes appropriate use of contact details.
 

  * Mandatory: Mandatory - if using contact details
* Reference: HPI-PR-MD-9
  * Purpose – Demonstrate that the: application makes appropriate use of a PractitionerRole record that is not active (has period end date and end reason).
  * Input values: * Get:Pracrole-ID (not active).
* Search: Search criteria (not active).

  * Expected outcome: *  Input: 
* Get: HPI-PractitionerRole-id
* Search: Criteria provided 
 
* Output: 
*  application makes appropriate use of PractitionerRole record that as ended.
 

  * Mandatory: Mandatory
* Reference: HPI-PR-MD-10
  * Purpose – Demonstrate that the: application makes appropriate use of a PractitionerRole record without a period.
  * Input values: * Get:Pracrole-ID (no period).
* Search: Search criteria (no period).

  * Expected outcome: *  Input: 
* Get: HPI-PractitionerRole-id
* Search: Criteria provided 
 
* Output: 
*  application makes appropriate use of PractitionerRole record without a period.
 

  * Mandatory: Mandatory
* Reference: HPI-PR-MD-11
  * Purpose – Demonstrate that the: application behaves appropriately when confidentiality settings have been set for a practitioner
  * Input values: * Get:Pracrole-ID (practitioner with c).
* Search: Search criteria (practitioner with c).

  * Expected outcome: *  Input: 
* Get: HPI-PractitionerRole-id
* Search: Criteria provided 
 
* Output: 
*  application returns appropriate messaging to user.
 

  * Mandatory: Mandatory

#### HPI Create PractitionerRole

* Reference: HPI-PR-Create-1
  * Purpose – Demonstrate that the: application can create a PractitionerRole record with the minimum criteria provided* hpi-person-id 
* hpi-facility-id or hpi-org-id
* role code

  * Input values: Select required identifiers from the test dataset
  * Expected outcome: *  Input: 
*  User can input minimum data to create a PractitionerRole record 
 
*  Output 
* PractitionerRole record is created with minimum dataset.
 

  * Mandatory: mandatory
* Reference: HPI-PR-Create-2
  * Purpose – Demonstrate that the: application can create a PractitionerRole record with additional items provided* hpi-person-id 
* hpi-facility-id and/or hpi-org-id
* role code
* contact points (as many as required)
* period
* messaging address

  * Input values: Create record with identifiers from the test datasetUse all information required by use case
  * Expected outcome: *  Input: 
*  User can create a PractitionerRole record with the additional items 
 
*  Output 
* PractitionerRole record is created with additional items included.
 

  * Mandatory: mandatory - use case dependent
* Reference: HPI-PR-Create-3
  * Purpose – Demonstrate that the: describe the business process used if a health provider asks for their record to be labelled confidential
  * Input values: Create record with identifiers from the test datasetUse all information required by use case
  * Expected outcome: Description of business process to request Te Whatu Ora to set confidential security label
  * Mandatory: optional
* Reference: HPI-PR-Create-error-1
  * Purpose – Demonstrate that the: application will show the correct error when attempting to create a PractitionerRole without a Practitioner CPN (hpi-person-id)
  * Input values: Create record with only an hpi-organisation-id or hpi-facility-id
  * Expected outcome: Error: EM07201Display "Required value missing"Text: PractitionerRole.Practitioner
  * Mandatory: Mandatory
* Reference: HPI-PR-Create-error-2
  * Purpose – Demonstrate that the: application will show the correct error when attempting to create a PractitionerRole without an organisation or facility.
  * Input values: Create record with only an hpi-person-id (CPN)
  * Expected outcome: Error: EM07201Display "Required value missing"Text: PractitionerRole.Facility, PractitionerRole.Organisation
  * Mandatory: Mandatory
* Reference: HPI-PR-Create-error-3
  * Purpose – Demonstrate that the: application will show the correct error when attempting to create a PractitionerRole without a role code.
  * Input values: Create record without a role code
  * Expected outcome: Error: EM07201Display "Required value missing"Text: PractitionerRole.code
  * Mandatory: Mandatory
* Reference: HPI-PR-Create-error-4
  * Purpose – Demonstrate that the: aapplication will show the correct error when attempting to create a duplicate PractitionerRole record
  * Input values: Create a duplicte Practitionerrole[See duplicate definition](glossary.md#practitioner-role)
  * Expected outcome: Error: EM07201Display "Required value missing"Text: PractitionerRole
  * Mandatory: Mandatory

#### HPI PractitionerRole Update

* Reference: HPI-PR-Update-1
  * Purpose – Demonstrate that the: application can replace the contact details on a PractitionerRole record
  * Input values: Update PracRole xxx with multiple contact details e.g.*  system-phone 
* use - work
* rank -1
* value-ficticious
 
*  system-phone 
* use - work
* rank -2
* value-ficticious
 
*  system-phone 
* use - temp
* rank - 2
* value-ficticious
 

  * Expected outcome: *  Input 
* User can input new contact information
 
* Output: 
* Contact details are added to the HPI record correctly
* Contact information displayed to the user
 

  * Mandatory: mandatory - use case dependent
* Reference: HPI-PR-Update-2
  * Purpose – Demonstrate that the: application can replace just the phone number on a PractitionerRole record
  * Input values: Update PracRole used above with:* Replace this contact: 
*  system-phone 
* use - work
* rank -1
* value-ficticious
 
 
*  With this contact information 
*  system-phone 
* use - work
* rank - 5
* value-ficticious
 
 

  * Expected outcome: *  Input 
* User can input new contact information
 
* Output: 
* Contact details are added to the HPI record correctly, other contact details remain unchanged
* Contact information displayed to the user
 

  * Mandatory: mandatory- use case dependent
* Reference: HPI-PR-Update-3
  * Purpose – Demonstrate that the: application can remove a contactpoint on a PractitionerRole record
  * Input values: Update PracRole used above and remove:*  This contact information 
*  system-phone 
* use - temp
* rank - 2
* value-ficticious
 
 

  * Expected outcome: *  Input 
* User can update contact information
 
* Output: 
* Output: temp phone is removed from the HPI record, other contact details remain unchanged
* Contact information displayed to the user
 

  * Mandatory: mandatory- use case dependent
* Reference: HPI-PR-Update-4
  * Purpose – Demonstrate that the: application can update the contact rank on a PractitionerRole record
  * Input values: * Replace this contact rank: 
*  system-phone 
* use - work
* rank -2
 
 
*  With this contact information 
*  system-phone 
* use - work
* rank - 1
 
 

  * Expected outcome: *  Input 
* User can update contact rank only
 
* Output: 
* Output: Contact rak is updated, other contact details remain unchanged
* Contact information displayed to the user
 

  * Mandatory: mandatory- use case dependent
* Reference: HPI-PR-Update-5
  * Purpose – Demonstrate that the: application can add / replace the messaging address on a PractitionerRole record
  * Input values: update PractitionerRole used above with Messaging address* provider - heathlink 
* value “ficticious value”

  * Expected outcome: *  Input 
* User can input messaging address
 
* Output: 
* Output: Messaging address added to the HPI PractitionerRole record correctly
* Contact information displayed to the user
 

  * Mandatory: mandatory- use case dependent
* Reference: HPI-PR-Update-6
  * Purpose – Demonstrate that the: application can end a PractitionerRole record
  * Input values: Use role created aboveadd an end date an end reason
  * Expected outcome: *  Input 
*  user can add an end date and end reason
 
* Output: 
* Output: Details displayed to user
 

  * Mandatory: mandatory
* Reference: HPI-PR-Update-6
  * Purpose – Demonstrate that the: application can remove an end date on a PractitionerRole record
  * Input values: Use PractitionerRole aboveremove the end date an end reason
  * Expected outcome: *  Input 
*  user can remove an end date and end reason
 
* Output: 
* Output: Details displayed to user
 

  * Mandatory: mandatory
* Reference: HPI-PR-Update-error-1
  * Purpose – Demonstrate that the: application will show the correct error when attempting to update a PractitionerRole record with an end date and no reason
  * Input values: Use PractitionerRole aboveadd an end date only
  * Expected outcome: Error: EM07201Display "Required value missing"Text:PractitionerRole.statusReason
  * Mandatory: mandatory
* Reference: HPI-PR-Update-error-2
  * Purpose – Demonstrate that the: application will show the correct error when attempting to update a PractitionerRole record with an end reason and no end date
  * Input values: Use PractitionerRole aboveadd an end date only
  * Expected outcome: Error: EM07201Display "Required value missing"Text:PractitionerRole.period.end
  * Mandatory: mandatory

