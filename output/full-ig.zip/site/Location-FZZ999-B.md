# FZZ999-B - New Zealand HPI Implementation Guide v1.5.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FZZ999-B**

## Example Location: FZZ999-B

version: 11148; Last updated: 2023-02-24 17:14:14+1300

Profile: [HPI Location](StructureDefinition-HpiLocation.md)

Live Facilty (Enrolling GP Practice) (https://standards.digital.health.nz/ns/hpi-facility-id#HPIFacility#FZZ999-B (use: official))

-------

| | |
| :--- | :--- |
| Status: | Active |
| Alias: | * Do not change details of this Facility
* Live Facilty
 |
| Type: | Enrolling GP Practice |
| Address: | 133 Molesworth Street, Thorndon 6011, Wellington(work) (NZ Suburb: Thorndon) |
| Contact Detail | * [email007@email.co.nz](mailto:email007@email.co.nz)
* ph: 02865865865(Work)
 |
| Managed By: | [Verification Test Organisation](Organization-GZZ999-J.md) |
| Other Ids: | * HPIFacility/FZZ997-J (use: old)
* HPIFacility/Z999 (use: official)
 |
|  | 2013-01-02 --> (ongoing) |
| [District Health Board linked to a NZ Healthcare Service, Location or Patient](https://fhir.org.nz/ig/base/StructureDefinition-dhb.html) | Capital and Coast District Health Board |
| Messaging Address: | * provider: healthlink
* value: livefacedi
 |



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "FZZ999-B",
  "meta" : {
    "versionId" : "11148",
    "lastUpdated" : "2023-02-24T17:14:14.000+13:00",
    "profile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPILocation"]
  },
  "extension" : [{
    "url" : "http://hl7.org.nz/fhir/StructureDefinition/established",
    "valuePeriod" : {
      "start" : "2013-01-02"
    }
  },
  {
    "url" : "http://hl7.org.nz/fhir/StructureDefinition/dhb",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "https://standards.digital.health.nz/ns/dhb-code",
        "version" : "1.0.0",
        "code" : "G00036-D",
        "display" : "Capital and Coast District Health Board"
      }],
      "text" : "Capital and Coast District Health Board"
    }
  },
  {
    "extension" : [{
      "url" : "provider",
      "valueString" : "healthlink"
    },
    {
      "url" : "value",
      "valueString" : "livefacedi"
    }],
    "url" : "http://hl7.org.nz/fhir/StructureDefinition/messaging-address"
  }],
  "identifier" : [{
    "use" : "official",
    "system" : "https://standards.digital.health.nz/ns/hpi-facility-id",
    "value" : "FZZ999-B",
    "assigner" : {
      "reference" : "Organization/G00001-G"
    }
  },
  {
    "use" : "old",
    "system" : "https://standards.digital.health.nz/ns/hpi-facility-id",
    "value" : "FZZ997-J",
    "assigner" : {
      "reference" : "Organization/G00001-G"
    }
  },
  {
    "use" : "official",
    "system" : "https://standards.digital.health.nz/ns/nzhis-facility-id",
    "value" : "Z999",
    "assigner" : {
      "reference" : "Organization/G00001-G"
    }
  }],
  "status" : "active",
  "name" : "Live Facilty",
  "alias" : ["Do not change details of this Facility", "Live Facilty"],
  "_alias" : [{
    "extension" : [{
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/alias-type",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://standards.digital.health.nz/ns/alias-type-code",
          "version" : "1.0.0",
          "code" : "aka",
          "display" : "Aka"
        }],
        "text" : "Aka"
      }
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/alias-type",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://standards.digital.health.nz/ns/alias-type-code",
          "version" : "1.0.0",
          "code" : "current",
          "display" : "Current unverified or unofficial name"
        }],
        "text" : "Current unverified or unofficial name"
      }
    }]
  }],
  "type" : [{
    "coding" : [{
      "system" : "https://standards.digital.health.nz/ns/location-type-code",
      "version" : "1.0",
      "code" : "gpenrol",
      "display" : "Enrolling GP Practice"
    }]
  }],
  "telecom" : [{
    "system" : "email",
    "value" : "email007@email.co.nz",
    "use" : "work",
    "rank" : 1,
    "period" : {
      "start" : "2013-01-02"
    }
  },
  {
    "system" : "phone",
    "value" : "02865865865",
    "use" : "work",
    "rank" : 1,
    "period" : {
      "start" : "2013-01-02"
    }
  }],
  "address" : {
    "id" : "1112139",
    "extension" : [{
      "extension" : [{
        "url" : "latitude",
        "valueDecimal" : -41.272975
      },
      {
        "url" : "longitude",
        "valueDecimal" : 174.777729
      }],
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/nz-geocode"
    },
    {
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/suburb",
      "valueString" : "Thorndon"
    },
    {
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/domicile-code",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://standards.digital.health.nz/ns/domicile-code",
          "version" : "3.0",
          "code" : "2077",
          "display" : "Thorndon - Tinakori Road"
        }],
        "text" : "Thorndon - Tinakori Road"
      }
    }],
    "use" : "work",
    "type" : "physical",
    "text" : "133 Molesworth Street, Thorndon 6011, Wellington",
    "line" : ["133 Molesworth Street"],
    "city" : "Wellington",
    "postalCode" : "6011"
  },
  "managingOrganization" : {
    "reference" : "Organization/GZZ999-J",
    "display" : "Verification Test Organisation"
  }
}

```
