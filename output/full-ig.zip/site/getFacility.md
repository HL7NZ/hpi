# Get Facility - New Zealand HPI Implementation Guide v1.5.0

* [**Table of Contents**](toc.md)
* **Get Facility**

## Get Facility

### Get Facility Overview

The Get Facility use case describes how a user can find an HPI facility record. HPI Facilities are returned using the HL7 FHIR Location resource.

### Get facility using an hpi-facility-id

**Get facility (Location) processing steps:**

1. The user supplies a hpi-facility-id for the Facility to be looked up
1. The integrating application sends an HTTP GET request for the Location resource using the hpi-facility-id to identify the Location whose information is being requested. E.g. GET<Endpoint>/Location/FZZ999-B
1. The request is validated - ALT: Validation failure. Operation Outcome resource returned
1. The Location resource is retrieved from the HPI - ALT: Location not found. Operation Outcome resource returned
1. The response containing the Location resource is returned
1. The Facility details are provided to the user

#### Get Facility rules and errors

* Rule: A Facility read request must include a valid hpi-facility-id
  * Error code: * 

  * Error description: * Invalid ID: <>

  * Error text / expression: * 

  * Http code: * 404 Not found


### Query Facility using the Location the NZHIS (Legacy) identifier

To query a Facility with the NZHIS (Legacy) identifier, the integrating application sends an HTTP Get request for the Location resource using the NZHIS (Legacy) identifier and the identifier system.

[For more information on read vs query click here](/general.md#read-resource-by-id)

**Query facility (location) processing steps**

1. The user supplies the system (https://standards.digital.health.nz/ns/nzhis-facility-id) and identifier (NZHIS-id) for the facility.
1. The integrating application sends an HTTP Get request for the Location resource using the NZHIS identifier to identify the facility whose information is being requested. E.g. GET<Endpoint>/Location?identifier=https://standards.digital.health.nz/ns/nzhis-facility-id|Z997
1. The request is validated - ALT: Validation failure. OperationOutcome resource returned
1. The Location resource is retrieved from the HPI - ALT: Location reource not found. OperationOutcome resource returned
1. The response containing a bundle with a single facility record is returned
1. The integrating application displays the facility details to the user

#### Query Facility rules and errors

* Rule: A Facility query request must include a valid registration authority identifier and 'system'
  * Error code: * 
* EM07240

  * Error description: * Unknown identifier system: https://standards.digital.health.nz/ns/nzhis-facility-id
* Resource not found

  * Error text / expression: * 
* Location.identifier:legacyFacId

  * Http code: * 422 Unknown
* 404 Not found


