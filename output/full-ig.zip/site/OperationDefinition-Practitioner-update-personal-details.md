# Practitioner-update-personal-details - New Zealand HPI Implementation Guide v1.6.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Practitioner-update-personal-details**

## OperationDefinition: Practitioner-update-personal-details 

| | |
| :--- | :--- |
| *Official URL*:https://hpi-ig.hip.digital.health.nz/OperationDefinition/practitioner-update-personal-details | *Version*:1.6.0 |
| Draft as of 2026-11-18 | *Computable Name*:Update Personal Details |

 
Updates Practitioner gender, ethnicity and communication languages. Omitted values are preserved; supplied ethnicity and language values replace their complete respective collections. 



## Resource Content

```json
{
  "resourceType" : "OperationDefinition",
  "id" : "Practitioner-update-personal-details",
  "url" : "https://hpi-ig.hip.digital.health.nz/OperationDefinition/practitioner-update-personal-details",
  "version" : "1.6.0",
  "name" : "Update Personal Details",
  "title" : "Updates a health provider's personal details.",
  "status" : "draft",
  "kind" : "operation",
  "experimental" : false,
  "date" : "2026-11-18",
  "publisher" : "Te Whatu Ora",
  "contact" : [{
    "name" : "Te Whatu Ora",
    "telecom" : [{
      "system" : "email",
      "value" : "mailto:integration@health.govt.nz"
    }]
  }],
  "description" : "Updates Practitioner gender, ethnicity and communication languages. Omitted values are preserved; supplied ethnicity and language values replace their complete respective collections.",
  "affectsState" : true,
  "code" : "practitioner-update-personal-details",
  "resource" : ["Practitioner"],
  "system" : false,
  "type" : true,
  "instance" : false,
  "parameter" : [{
    "name" : "cpn",
    "use" : "in",
    "min" : 1,
    "max" : "1",
    "documentation" : "The HPI person identifier (CPN).",
    "type" : "string"
  },
  {
    "name" : "version-id",
    "use" : "in",
    "min" : 1,
    "max" : "1",
    "documentation" : "The current Practitioner version identifier.",
    "type" : "string"
  },
  {
    "name" : "ra-identifier",
    "use" : "in",
    "min" : 0,
    "max" : "1",
    "documentation" : "The RA identifier; required for an RA update.",
    "type" : "string"
  },
  {
    "name" : "gender",
    "use" : "in",
    "min" : 0,
    "max" : "1",
    "documentation" : "FHIR AdministrativeGender code. If supplied, replaces the current Practitioner.gender.",
    "type" : "code"
  },
  {
    "name" : "ethnicity",
    "use" : "in",
    "min" : 0,
    "max" : "6",
    "documentation" : "An HPI-bound ethnicity code. Supplied values replace the complete current ethnicity set.",
    "type" : "code"
  },
  {
    "name" : "language",
    "use" : "in",
    "min" : 0,
    "max" : "10",
    "documentation" : "An HPI-bound language code. Supplied values replace the complete current language set.",
    "type" : "code"
  },
  {
    "name" : "return",
    "use" : "out",
    "min" : 1,
    "max" : "1",
    "documentation" : "The updated Practitioner resource.",
    "type" : "Practitioner"
  }]
}

```
