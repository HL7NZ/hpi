# Onboarding - New Zealand HPI Implementation Guide v1.4.10

* [**Table of Contents**](toc.md)
* **Onboarding**

## Onboarding

### Who can apply for access?

#### To the test environment:

All organisations and software vendors will be given access to all the HPI api operations in the HIP Compliance environment for testing and training after completing the on-boarding process described below.

#### To the production environment:

Access to **HPI Organisation and HPI Facility Get and Search** operations is available to all health providers, responsible authorities and organisations who provide supporting services to health providers and responsible authorities.

(Definitions: A health provider means a person or an organisation that provides, or arranges the provision of, personal health services or public health services-reference section 2, Health Act 1956. A responsible authority is an organisation responsible for the registration of practitioners-reference section 5, Health Practitioners Competence Assurance Act 2003).

Health providers and responsible authorities with existing HPI Data Access and Provision Agreements will be given access to Get and Search Practitioner under those agreements. This includes District Health Boards, ACC and health agencies employing practitioners to deliver health services e.g. Laboratories.

Health providers without an agreement wanting access to **Get, Search, Update and Create Practitioner** and any organisations wanting access to **PractitionerRole Get, Search, Update and Create** operations will need to apply to Te Whatu Ora / Health New Zealand (HNZ). The application will be assessed by HNZ sector digital channels. If granted, an access agreement may be required prior to credentials being issued to production.

### On-boarding and Implementation

1. To get started, head to['Consumer onboarding', over at the digital services hub](https://www.tewhatuora.govt.nz/health-services-and-programmes/digital-health/digital-services-hub/consumer-onboarding/). You will need to provide information about your organisation, the product you are developing and the API's you want to integrate with.
* For more information [have a look at the other resources on the Digital Service Hub](https://www.tewhatuora.govt.nz/health-services-and-programmes/digital-health/digital-services-hub/).

1. Once your onboarding request has been approved, you will be provided with the information to start integration. The integration team will be in touch if further information is required.
* You will receive your credentials, access token url, provided scopes, and the compliance environment endpoint.

1. Complete your development and testing.
1. When you are ready for compliance testing, email the[integration team](mailto:integration@tewhatuora.govt.nz)to get a compliance testing template.
1. Submit the results of the compliance tests using this form [HIP Compliance Submission] (https://mohapis.atlassian.net/servicedesk/customer/portal/3/group/11/create/129).
1. The integration team will issue a compliance test report. Your application will receive certification to be used in production or additional requirements will need to be met.
* This can be an iterative process, so please get in touch as needed to discuss the compliance testing process.

1. **Each organisation**using your application with NHI integrated services must apply individually for access to the production environment (and recieve their own set of credentials) by completing the production form, please email[NHI Access](mailto:nhi_access@health.govt.nz).
* Please allow at least 5 working days for **compliance environment applications** to be processed.

* Please allow at least 2 weeks for **compliance testing** to be signed off and returned.
* If **Production credentials** are required by a large number of organisations accessing your product, please get in touch to discuss options around bulk credential requests and how we can streamline this process.

### Assistance

Please fill in the [Digital Services Hub Support and Feedback form](https://mohapis.atlassian.net/servicedesk/customer/portal/3/group/35/create/112).

### Business Functions

* Business Functions: Get Facility
  * Description: Get Facility using hpi-facility-id
  * Comments: Returns a location resource[See who can access the production environment](Onboarding.md#to-the-production-environment)[See Get Facility use case](getLocation.md)
* Business Functions: Search Facility
  * Description: Search Facilities by name, address, type and other parameters
  * Comments: Returns a bundle containing location resources[See who can access the production environment](Onboarding.md#to-the-production-environment)[See Search Facility use case](searchLocation.md)
* Business Functions: Get Organisation
  * Description: Get Organisation using hpi-organisation-id
  * Comments: Returns an Organization resource[See who can access the production environment](Onboarding.md#to-the-production-environment)[See Get Organisation use case](getOrganization.md)
* Business Functions: Search Organisation
  * Description: Search Organisation by name, type and other parameters
  * Comments: Returns a bundle containing Organisation resources[See who can access the production environment](Onboarding.md#to-the-production-environment)[See Search Organisation use case](searchOrganization.md)
* Business Functions: Get Practitioner
  * Description: Get Practitioner using CPN or RA-id
  * Comments: Returns a Practitioner resource[See who can access the production environment](Onboarding.md#to-the-production-environment)[See Get Practitioner use case](getPractitioner.md)
* Business Functions: Search Practitioner
  * Description: Search Practitioner by name, date of birth and other demographics
  * Comments: Returns a bundle containing Practitioner resources[See who can access the production environment](Onboarding.md#to-the-production-environment)[See Search Practitioner use case](searchPractitioner.md)
* Business Functions: Maintain Practitioner
  * Description: Update Practitioner records
  * Comments: [See who can access the production environment](Onboarding.md#to-the-production-environment)[See Update Practitioner use case](updatePractitioner.md)
* Business Functions: Create Practitioner
  * Description: Create Practitioner records
  * Comments: [See who can access the production environment](Onboarding.md#to-the-production-environment)[See Create Practitioner use case](createPractitioner.md)
* Business Functions: Get PractitionerRole
  * Description: Get PractitionerRole using hpi-practitionerrole-id
  * Comments: [See who can access the production environment](Onboarding.md#to-the-production-environment)[See Get PractitionerRole use case](getPracRole.md)
* Business Functions: Search PractitionerRole
  * Description: Search PractitionerRole using Practitioner and other parameters
  * Comments: [See who can access the production environment](Onboarding.md#to-the-production-environment)[See Search PractitionerRole use case](searchPracRole.md)
* Business Functions: Maintain PractitionerRole
  * Description: Update PractitionerRole records
  * Comments: [See who can access the production environment](Onboarding.md#to-the-production-environment)[See Update PractitionerRole use case](updatePracRole.md)
* Business Functions: Create PractitionerRole
  * Description: Create PractitionerRole records
  * Comments: [See who can access the production environment](Onboarding.md#to-the-production-environment)[See Create PractitionerRole use case](createPracRole.md)

