# Practitioner Compliance Testing - New Zealand HPI Implementation Guide v1.4.10

* [**Table of Contents**](toc.md)
* **Practitioner Compliance Testing**

## Practitioner Compliance Testing

#### HPI Practitioner GET

* Reference: HPI-P-Get-1
  * Purpose – Demonstrate that the: System can handle a response when a dormant hpi-person-id is requested
  * Input values: 99ZZRT90ZZJF
  * Expected outcome: System does not errorSystem returns appropriate messaging to user
  * Mandatory: mandatory
* Reference: HPI-P-Get-2
  * Purpose – Demonstrate that the: System can display the information required to confirm a health providers identityFull namehpi-person-id (CPN)Registration type (RA Provider only)
  * Input values: 91ZZWJ90ZZLC
  * Expected outcome: System displays information required to confirm identity
  * Mandatory: mandatory
* Reference: HPI-P-Get-3
  * Purpose – Demonstrate that the: System can handle a response when practitioner hasonly a surname;only a given name;Has both official and usual names
  * Input values: **Do all**91ZZWJ91ZZVR93ZZWU
  * Expected outcome: System does not errorSystem returns all name parts when presentOrder of name parts is clear to the userSystem should retain the name as a Family name when a practitioner has only a Given Name on the HPI
  * Mandatory: mandatory
* Reference: HPI-P-Get-4
  * Purpose – Demonstrate that the: System behaves appropriately when the requested practitioner has more than one registration
  * Input values: **Do all**95ZZEJ (dental/nursing)98ZZNY (nursing/medical)95ZZQE (medical sciences/nursing)98ZZQJ (nursing/midwifery)95ZZDR (nursing/psychology)95ZZDE (optometry/nursing)
  * Expected outcome: The appropriate registration is used or both registrations are presented
  * Mandatory: mandatory if
* Reference: HPI-P-Get-5
  * Purpose – Demonstrate that the: System behaves appropriately when the requested practitioner has more than one Scope of Practice
  * Input values: **Do all**98ZZNY90ZZJF98ZZNM
  * Expected outcome: System returns appropriate messaging to user
  * Mandatory: mandatory if
* Reference: HPI-P-Get-6
  * Purpose – Demonstrate that the: System behaves appropriately when the requested practitioner does not have a registration (qualification)
  * Input values: 90ZZLC90ZZLP
  * Expected outcome: System does not errorSystem returns appropriate messaging to user
  * Mandatory: mandatory if
* Reference: HPI-P-Get-7
  * Purpose – Demonstrate that the: System behaves appropriately for all registration (qualification) statuses
  * Input values: **Do all**98ZZYU (Current)98ZZYH (Inactive)98ZZXQ (Removed)98ZZXD (Suspended)
  * Expected outcome: System returns appropriate messaging to user
  * Mandatory: mandatory if
* Reference: HPI-P-Get-8
  * Purpose – Demonstrate that the: System clearly distinguishes between educational qualifications and registration details
  * Input values: 97ZZYP94ZZXF97ZZYC94ZZWZ97ZZXW
  * Expected outcome: System returns appropriate messaging to user
  * Mandatory: mandatory if
* Reference: HPI-P-Get-9
  * Purpose – Demonstrate that the: System clearly displays all condition’s of practice / additional authorisation’s to user
  * Input values: TBC
  * Expected outcome: System returns appropriate messaging to user
  * Mandatory: optional
* Reference: HPI-P-Get-10
  * Purpose – Demonstrate that the: When a system is assessing a practitioners authority to practice that both the APC period and the registration status is used
  * Input values: 90ZZSR90ZZMG
  * Expected outcome: The user is informed the practitioners APC has expired
  * Mandatory: mandatory if
* Reference: HPI-P-Get-11
  * Purpose – Demonstrate that the: System behaves appropriately when confidentiality settings have been set for a practitioner
  * Input values: 93ZZRW96ZZSG98ZZWL
  * Expected outcome: System does not errorSystem returns appropriate messaging to userFor more information see [Confidentiality](/businessView.html#confidentiality) and [Redacted Practitioner details](/StructureDefinition-HPIPractitioner.html#redacted-practitioner-details)
  * Mandatory: mandatory if
* Reference: HPI-P-Get-12
  * Purpose – Demonstrate that the: System behaves appropriately when practitioner record has a date of death
  * Input values: 90ZZLP90ZZMG92ZZSJ92ZZRR
  * Expected outcome: System returns appropriate messaging to user
  * Mandatory: mandatory
* Reference: HPI-P-Query-1
  * Purpose – Demonstrate that the: System can query a practitioner using the registration identifier eg Medical Council number, Nursing Council numberShow a selection of RA's that apply
  * Input values: Medical CouncilMedical Council #= 99478Nursing CouncilNursing Council #= 961049Medical Sciences CouncilMedical Sciences Council #= 30-91697
  * Expected outcome: System retrieves record successfully
  * Mandatory: optional

#### HPI Practitioner Search

* Reference: HPI-P-Search-1
  * Purpose – Demonstrate that the: Minimum search criteria are included
  * Input values: Name = Walter O’ReillyName = Brian Hunnicutt
  * Expected outcome: A name is provided in the request
  * Mandatory: optional
* Reference: HPI-P-Search-2
  * Purpose – Demonstrate that the: Other search criteria are included
  * Input values: Name = Walter O’ReillyBirthdate = 1943-05-24Gender = maleName = Brian HunnicuttBirthdate = 1939-02-06Gender = male
  * Expected outcome: Name, gender and birthdate can be provided in the request
  * Mandatory: optional
* Reference: HPI-P-Search-3
  * Purpose – Demonstrate that the: Search results are presented to user in order provided by the HPIif not please provide a reason
  * Input values: Use search results from above
  * Expected outcome: Results presented in order provided
  * Mandatory: mandatory

