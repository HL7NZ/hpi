# Update Practitioner - New Zealand HPI Implementation Guide v1.4.11

* [**Table of Contents**](toc.md)
* **Update Practitioner**

## Update Practitioner

### Update Practitioner Overview

The update Practitioner operations allow an authorised user to update a person's details on the HPI. The operations are broken down into four custom update operations:

* **Update-core** - To update name, birthdate and death-date
* **Update-personal-details** - To update gender, ethnicity and languages
* **Update-educational-qualifications** - To update educational qualifications
* **Update-registration** - To update registration details (APC, scope of practice etc.)

### Update-core

* Allows an authorised user to update a person's core details 
* name
* birthdate
* death-date
 

**Update-core processing steps:**

1. The user provides updated core details
1. The integrating application sends an HTTP Post request using the $update-core operation to the HPI E.g. Post/Practitioner/$update-core
1. The request is validated - ALT: Validation failure. Operation Outcome resource returned
1. The core details are updated
1. The updated record is returned with an HTTP 200 ok response
1. The integrating application displays the updated details to the user

### In Parameters

* Parameter name: cpn
  * Mandatory / Optional: Mandatory
  * Description: The hpi-person-id (cpn)
* Parameter name: version-id
  * Mandatory / Optional: Mandatory
  * Description: The current Practitioner record version number
* Parameter name: ra-identifier
  * Mandatory / Optional: * Mandatory for an RA update
  * Description: The RA identifier
* Parameter name: name
  * Mandatory / Optional: Optional
  * Description: An update replaces the full set of name attributes (use, prefix, given, family)
* Parameter name: death-date
  * Mandatory / Optional: Optional
  * Description: The date of death, can only be set by an admin user
* Parameter name: birth-date
  * Mandatory / Optional: Optional
  * Description: The birthdate, can only be set by an admin user

* Behaviour: 
* The hpi-person-id (cpn) is validated
* The Practitioner version-id is validated
* The parameters are validated
 
* update-core example request:

```
{
"resourceType":"Parameters",
  "parameter":[
    {
      "name":"cpn",
      "valueString":"99ZZRT"
    },    {
      "name":"version-id",
      "valueString":"29450"
    },
    {
      "name":"ra-identifier",
      "valueString":"998877"
    },
    {
      "name":"name",
        "valueHumanName":
           {
             "use":"official",
             "family":"FhirClientPractitionerUpdateIntegrationTest",
             "given":
                 ["updateNrPractitioner"]
           }
    },
    {
      "name":"death-date",
      "valueDate":"2021-11-11"
    },
    {
      "name":"birth-date",
      "valueDate":"1990-12-31"
    }
  ]
}


```

#### Update-core Rules and Errors

[For Request rules and errors click here](/general.md#request-rules-and-errors)

* **Practitioner update rules** 
* A Practitioner update must include a valid hpi-person-id
* A Practitioner update must include the official hpi-person-id
* A Practitioner update must include the latest version-id for the practitioner record
* An RA must include their RA identifier and can only update records for their own Practitioners
 
* **Practitioner update errors**
* **Practitioner update-core 'name' rules** 
* All name rules in [add request apply](/addPractitioner.md#add-practitioner-rules-and-errors) and,
* Cannot update a name to name use = old
* If a usual or official name is replaced the previous name/s will be returned as name use old
* Cannot add a name that has been deleted by Te Whatu Ora
 
* **Practitioner update-core 'name' errors**
* **Practitioner update-core 'birthdate' rules** 
* All birthdate rules in add request apply and,
* An update will replace the current birthdate.
 
* **Practitioner update-core 'birthdate' errors**
* **Practitioner update-core 'death-date' rules** 
* death-date must be a complete date and formatted YYYY-MM-DD
* death-date cannot be a future date
* death-date must be greater than birthdate
* An update will replace the current death-date.
 
* **Practitioner update-core 'death-date' errors**

### Update-personal-details

* Allows an authorised user to update personal details 
* gender
* ethnicity
* languages
 

### Update-educational-qualification

* Allows an authorised user to add, amend, or remove a practitioner’s educational qualifications.
* This operation is invoked as a FHIR `Parameters` resource using an HTTP POST request to the HPI endpoint, for example: `POST <Endpoint>/Practitioner/$update-educational-qualification`

#### Overview

A practitioner’s educational qualifications are changed by sending the live CPN, the current record version, and one or more repeating `educational-qualification` items with an action of `add`, `amend`, or `remove`. The request is validated before persistence, and the response returns the updated Practitioner resource with the latest version identifier.

#### Update-educational-qualification processing steps

1. The user selects one or more educational qualification changes in the integrating application
1. The application sends an HTTP POST request to the HPI using the`$update-educational-qualification`operation
1. The HPI validates the CPN,`version-id`, and caller authorisation context before applying any change
1. Each`educational-qualification`item is checked for the correct action, required fields, and valid country code rules
1. Matching items are added, updated, or removed without changing other educational qualifications that were not included in the request
1. The updated Practitioner record is persisted and returned to the caller with HTTP 200
1. The integrating application stores the new version identifier and refreshes the practitioner view

### In Parameters

* Parameter name: cpn
  * Mandatory / Optional: Mandatory
  * Description: The live HPI person identifier (CPN) of the practitioner being updated.
* Parameter name: version-id
  * Mandatory / Optional: Mandatory
  * Description: The current Practitioner record version number. This is used to ensure the update is based on the current record state.
* Parameter name: ra-identifier
  * Mandatory / Optional: Mandatory for RA updates
  * Description: The responsible authority identifier for the caller. This is required when the requesting user is operating under an RA context.
* Parameter name: educational-qualification
  * Mandatory / Optional: Mandatory
  * Description: A repeating parameter containing one or more qualification change items. Each item includes an `action`, and for `amend`/`remove` it includes an `id`.
* Parameter name: educational-qualification.action
  * Mandatory / Optional: Mandatory
  * Description: The action to apply: `add`, `amend`, or `remove`.
* Parameter name: educational-qualification.id
  * Mandatory / Optional: Mandatory for amend/remove
  * Description: The existing educational qualification identifier on the Practitioner. This is not an array position.
* Parameter name: educational-qualification.fullname
  * Mandatory / Optional: Mandatory for add/amend
  * Description: The full name of the educational qualification.
* Parameter name: educational-qualification.shortname
  * Mandatory / Optional: Optional for add/amend
  * Description: The abbreviated qualification name used where space is limited.
* Parameter name: educational-qualification.year
  * Mandatory / Optional: Mandatory for add/amend
  * Description: The year the qualification was awarded, supplied as a valid FHIR date value in `YYYY` format.
* Parameter name: educational-qualification.institution
  * Mandatory / Optional: Mandatory for add/amend
  * Description: The institution or education provider that awarded the qualification.
* Parameter name: educational-qualification.city
  * Mandatory / Optional: Mandatory for add/amend
  * Description: The city where the institution is located.
* Parameter name: educational-qualification.country
  * Mandatory / Optional: Mandatory for add/amend
  * Description: The country in which the institution is located, using a valid ISO 3166-1 alpha-2 country code.

* Behaviour: 
* The `cpn` must identify a live HPI practitioner record
* The `version-id` must match the current Practitioner record version
* The caller must be authorised and must satisfy the relevant RA/NR rules for the practitioner
* Each `educational-qualification` item is processed independently within the same request
* Duplicate submissions are treated as idempotent and therefore do not fail if the requested change has already been applied
* Only the qualifications included in the request are changed; all other educational qualifications remain as they are
 
* Update-educational-qualification example request:

```
{
  "resourceType": "Parameters",
  "parameter": [
    {
      "name": "cpn",
      "valueString": "28AQGN"
    },
    {
      "name": "version-id",
      "valueString": "32718"
    },
    {
      "name": "ra-identifier",
      "valueString": "353542"
    },
    {
      "name": "educational-qualification",
      "part": [
        { "name": "action", "valueCode": "add" },
        { "name": "fullname", "valueString": "Bachelor of Science" },
        { "name": "shortname", "valueString": "BSc" },
        { "name": "year", "valueDate": "2000" },
        { "name": "institution", "valueString": "University of Otago" },
        { "name": "city", "valueString": "Dunedin" },
        { "name": "country", "valueCode": "NZ" }
      ]
    },
    {
      "name": "educational-qualification",
      "part": [
        { "name": "action", "valueCode": "amend" },
        { "name": "id", "valueString": "edu-12345" },
        { "name": "fullname", "valueString": "Bachelor of Science (Honours)" },
        { "name": "shortname", "valueString": "BSc(Hons)" },
        { "name": "year", "valueDate": "2001" },
        { "name": "institution", "valueString": "University of Otago" },
        { "name": "city", "valueString": "Dunedin" },
        { "name": "country", "valueCode": "NZ" }
      ]
    },
    {
      "name": "educational-qualification",
      "part": [
        { "name": "action", "valueCode": "remove" },
        { "name": "id", "valueString": "edu-67890" }
      ]
    }
  ]
}

```

#### Update-educational-qualification Rules and errors

[For Request rules and errors click here](/general.md#request-rules-and-errors)

* **Update-educational-qualification rules** 
* A practitioner update request must include a valid `cpn` and the current `version-id`
* The caller must be an authorised RA or NR user with permission to update the practitioner record
* The supplied `ra-identifier` must be present when the caller is operating under an RA context and must match the relevant practitioner source authority
* Each `educational-qualification` item must include an `action` value of `add`, `amend`, or `remove`
* `add` and `amend` requests must include the required qualification content: `fullname`, `shortname`, `year`, `institution`, `city`, and `country`
* `amend` and `remove` requests must include the existing educational qualification `id`
* The `id` must match an existing educational qualification on the Practitioner record or an equivalent persisted identifier within the HPI context
* A country code must be a valid ISO 3166-1 alpha-2 value and must pass HPI validation before persistence
* The operation is idempotent for duplicate requests: an already-applied item does not cause a failure when the request is otherwise valid
* Only the qualifications mentioned in the request are changed; all other educational qualifications continue unchanged
 
* **Update-educational-qualification errors** 
* **`cpn` is required and must identify a live practitioner record**
* **`version-id` is required and must match the current record version**
* **The caller is not authorised to update this practitioner record**
* **The supplied RA identifier does not match the practitioner’s source authority**
* **`educational-qualification.action` is required and must be one of `add`, `amend`, or `remove`**
* **`educational-qualification.id` is required for `amend` and `remove`**
* **The educational qualification payload is incomplete or contains invalid values**
* **The supplied country code is not valid**
* **The practitioner record was not updated because validation failed before persistence**
 

-------

* **Update-educational-qualification response behaviour** 
* On successful update the HPI returns the updated Practitioner resource with the new educational qualification data and incremented version identifier
* The operation is subject to optimistic locking and will reject stale updates with a version conflict response
 
* **Update-educational-qualification response errors** 
* **Version conflict: the supplied version-id is stale**
* **Forbidden: the caller does not have the required practitioner update authority**
* **Bad request: required educational qualification parameters are missing or malformed**
 

This operation supports the requirement to maintain a practitioner’s educational qualification history while allowing approved users to add, replace, or remove entries without disturbing unrelated qualification data.

### Update-registration

* Allows an authorised Responsible Authority (RA) user to update a practitioner’s registration details, including the annual practising certificate (APC), registration status, scope of practice, additional authorisations, and practice conditions.
* This operation is invoked as a FHIR Parameters resource using an HTTP POST request to the HPI endpoint, for example: `POST <Endpoint>/Practitioner/$update-registration`

#### Overview

A practitioner’s registration is updated by sending the live CPN, the current record version, and the registration payload to be replaced or adjusted. The request is validated before the HPI updates the practitioner record, and the returned resource includes the updated registration state and the new version identifier.

#### Update-registration processing steps

1. The user selects a practitioner whose registration is to be updated in the integrating application
1. The integrating application sends an HTTP POST request to the HPI using the`$update-registration`operation
1. The request payload is validated for mandatory identifiers, valid dates and periods, and a valid RA context
1. The HPI checks that the CPN exists, the`version-id`matches the current practitioner version, and the caller’s RA matches the practitioner source
1. The registration details are merged and validated using the current HPI registration rules
1. The updated practitioner record is persisted and the new record version is returned to the caller
1. The integrating application displays the updated registration details and retains the new version identifier for subsequent updates

### In Parameters

* Parameter name: cpn
  * Mandatory / Optional: Mandatory
  * Description: The live HPI person identifier (CPN) of the practitioner being updated.
* Parameter name: version-id
  * Mandatory / Optional: Mandatory
  * Description: The current Practitioner record version number. This is used for optimistic concurrency checks.
* Parameter name: ra-identifier
  * Mandatory / Optional: Mandatory for RA updates
  * Description: The responsible authority identifier for the caller, used to ensure the caller can only update registrations for their own practitioners.
* Parameter name: registration-initial-date
  * Mandatory / Optional: Optional
  * Description: The date the practitioner was originally registered. If omitted during an update, the current value is retained where available.
* Parameter name: registration-status-code
  * Mandatory / Optional: Mandatory
  * Description: A FHIR `part` containing a status code and corresponding period. This represents the current registration status and when it applies.
* Parameter name: period
  * Mandatory / Optional: Mandatory
  * Description: The APC validity period for the practitioner. It must include both start and end dates.
* Parameter name: scope-of-practice
  * Mandatory / Optional: Mandatory
  * Description: One or more `part` values containing a code and period describing the scope of practice for the practitioner.
* Parameter name: additional-authorisation
  * Mandatory / Optional: Optional
  * Description: One or more `part` values containing an authorisation code and period.
* Parameter name: condition-on-practice
  * Mandatory / Optional: Optional
  * Description: One or more `part` values containing a description and period for any practice condition or restriction.

* Behaviour: 
* The `cpn` must resolve to an existing live practitioner record
* The `version-id` must match the current practitioner version
* The caller must be an authorised RA user and must match the practitioner’s RA context
* Registration collection data is treated as replace-with-history, not hard delete
* If a collection item is omitted from an update, it is end-dated or made inactive rather than permanently deleted
 
* Update-registration example request:

```
{
  "resourceType": "Parameters",
  "parameter": [
    {
      "name": "cpn",
      "valueString": "28AQGN"
    },
    {
      "name": "version-id",
      "valueString": "32718"
    },
    {
      "name": "ra-identifier",
      "valueString": "353542"
    },
    {
      "name": "registration-initial-date",
      "valueDate": "2022-11-22"
    },
    {
      "name": "registration-status-code",
      "part": [
        {
          "name": "code",
          "valueCode": "current"
        },
        {
          "name": "period",
          "valuePeriod": {
            "start": "2022-11-22"
          }
        }
      ]
    },
    {
      "name": "period",
      "valuePeriod": {
        "start": "2026-04-01",
        "end": "2027-03-31"
      }
    },
    {
      "name": "scope-of-practice",
      "part": [
        {
          "name": "code",
          "valueCode": "CHIR"
        },
        {
          "name": "period",
          "valuePeriod": {
            "start": "2022-11-22"
          }
        }
      ]
    },
    {
      "name": "additional-authorisation",
      "part": [
        {
          "name": "code",
          "valueCode": "IMMU"
        },
        {
          "name": "period",
          "valuePeriod": {
            "start": "2022-11-22"
          }
        }
      ]
    },
    {
      "name": "condition-on-practice",
      "part": [
        {
          "name": "description",
          "valueString": "Supervision required for first 6 months"
        },
        {
          "name": "period",
          "valuePeriod": {
            "start": "2022-11-22"
          }
        }
      ]
    }
  ]
}

```

#### Update-registration Rules and errors

[For Request rules and errors click here](/general.md#request-rules-and-errors)

* **Update-registration rules** 
* A practitioner update-registration request must include a valid `cpn` and the current `version-id`
* The caller must be an authorised RA user with permission to update practitioner details
* The supplied `ra-identifier` must match the current practitioner source context
* `registration-status-code` is mandatory and must include a valid code and period
* `period` is mandatory and must represent the APC validity window with `start` and `end`
* `scope-of-practice` is mandatory and must include at least one code/period pair
* All period values must be valid and must have `start <= end`
* If `registration-initial-date` is omitted on an update, the existing date must be retained if already present
* Collection-based registration values such as scope, authorisation, and conditions use replace-with-history semantics
* Omitted previous collection items are not deleted; they are marked inactive or end-dated rather than hard removed
* Status and code values must be valid values from the relevant HISO and NZHTS code sets
 
* **Update-registration errors** 
* **`cpn` is required and must identify a live practitioner record**
* **`version-id` is required and must match the current record version**
* **The caller is not permitted to update this practitioner record**
* **The supplied RA identifier does not match the practitioner’s source authority**
* **Registration status code and period are required**
* **APC period must include a valid start and end date**
* **Scope of practice entries are required and must contain valid code and period values**
* **One or more period values are invalid or end before start**
* **The practitioner registration payload failed validation and was not persisted**
 

-------

* **Update-registration date and period rules** 
* A registration period or status period must be formatted as a valid FHIR period and must not end before it starts
* `registration-initial-date` may be supplied as a past date, today, or a future date to support pre-registration scenarios
* The HPI preserves the existing initial registration date when a new update omits it
 
* **Update-registration date and period errors** 
* **Period start cannot be after period end**
* **Registration status period is required**
* **A supplied date is not valid for the registration update request**
 

-------

* **Update-registration collection semantics** 
* `scope-of-practice`, `additional-authorisation`, and `condition-on-practice` are updated as collections
* Items supplied in the request replace or add active values for the current registration state
* Items not supplied in the request are treated as inactive or end-dated to preserve history and support auditability
 
* **Update-registration collection errors** 
* **The registration payload contains invalid collection items or invalid coding values**
* **Validation of the merged registration state failed before persistence**
 

-------

* **Update-registration response behaviour** 
* On successful update the HPI returns the updated Practitioner resource with the new registration data and incremented version identifier
* The operation is subject to optimistic locking and will reject stale updates with a version conflict response
 
* **Update-registration response errors** 
* **Version conflict: the supplied version-id is stale**
* **Forbidden: the caller does not have the required practitioner update authority**
* **Bad request: required registration parameters are missing or malformed**
 

This operation supports the maintainers’ requirement to update core registration details without removing the historical record, while still providing the current active registration data and version-aware concurrency controls.

