# Update Practitioner - New Zealand HPI Implementation Guide v1.5.0

* [**Table of Contents**](toc.md)
* **Update Practitioner**

## Update Practitioner

### Update Practitioner Overview

The update Practitioner operations allow an authorised user to update a person's details on the HPI. The operations are broken down into four custom update operations:

* **Update-core** - To update name, birthdate and death-date
* **Update-personal-details** - To update gender, ethnicity and languages
* **Update-educational-qualifications** - To update educational qualifications
* **Update-registration** - To update registration details (APC, scope of practice etc.)

### Update-core

* Allows an authorised user to update a person's core details 
* name
* birthdate
* death-date
 

**Update-core processing steps:**

1. The user provides updated core details
1. The integrating application sends an HTTP Post request using the $update-core operation to the HPI E.g. Post/Practitioner/$update-core
1. The request is validated - ALT: Validation failure. Operation Outcome resource returned
1. The core details are updated
1. The updated record is returned with an HTTP 200 ok response
1. The integrating application displays the updated details to the user

### In Parameters

* Parameter name: cpn
  * Mandatory / Optional: Mandatory
  * Description: The hpi-person-id (cpn)
* Parameter name: version-id
  * Mandatory / Optional: Mandatory
  * Description: The current Practitioner record version number
* Parameter name: ra-identifier
  * Mandatory / Optional: * Mandatory for an RA update
  * Description: The RA identifier
* Parameter name: name
  * Mandatory / Optional: Optional
  * Description: An update replaces the full set of name attributes (use, prefix, given, family)
* Parameter name: death-date
  * Mandatory / Optional: Optional
  * Description: The date of death, can only be set by an admin user
* Parameter name: birth-date
  * Mandatory / Optional: Optional
  * Description: The birthdate, can only be set by an admin user

* Behaviour: 
* The hpi-person-id (cpn) is validated
* The Practitioner version-id is validated
* The parameters are validated
 
* update-core example request:

```
{
"resourceType":"Parameters",
  "parameter":[
    {
      "name":"cpn",
      "valueString":"99ZZRT"
    },    {
      "name":"version-id",
      "valueString":"29450"
    },
    {
      "name":"ra-identifier",
      "valueString":"998877"
    },
    {
      "name":"name",
        "valueHumanName":
           {
             "use":"official",
             "family":"FhirClientPractitionerUpdateIntegrationTest",
             "given":
                 ["updateNrPractitioner"]
           }
    },
    {
      "name":"death-date",
      "valueDate":"2021-11-11"
    },
    {
      "name":"birth-date",
      "valueDate":"1990-12-31"
    }
  ]
}


```

#### Update-core Rules and Errors

[For Request rules and errors click here](/general.md#request-rules-and-errors)

* **Practitioner update rules** 
* A Practitioner update must include a valid hpi-person-id
* A Practitioner update must include the official hpi-person-id
* A Practitioner update must include the latest version-id for the practitioner record
* An RA must include their RA identifier and can only update records for their own Practitioners
 
* **Practitioner update errors**
* **Practitioner update-core 'name' rules** 
* All name rules in [add request apply](/addPractitioner.md#add-practitioner-rules-and-errors) and,
* Cannot update a name to name use = old
* If a usual or official name is replaced the previous name/s will be returned as name use old
* Cannot add a name that has been deleted by Te Whatu Ora
 
* **Practitioner update-core 'name' errors**
* **Practitioner update-core 'birthdate' rules** 
* All birthdate rules in add request apply and,
* An update will replace the current birthdate.
 
* **Practitioner update-core 'birthdate' errors**
* **Practitioner update-core 'death-date' rules** 
* death-date must be a complete date and formatted YYYY-MM-DD
* death-date cannot be a future date
* death-date must be greater than birthdate
* An update will replace the current death-date.
 
* **Practitioner update-core 'death-date' errors**

### Update-personal-details

* Allows an authorised user to update personal details 
* gender
* ethnicity
* languages
 

### Update-educational-qualifications

* Allows an authorised user to update educational qualifications

### Update-registration

* Allows an authorised user to update registration details (APC, scope of practice etc.)

