# GZZ998-G - New Zealand HPI Implementation Guide v1.5.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GZZ998-G**

## Example Organization: GZZ998-G

Profile: [HPI Organization](StructureDefinition-HpiOrganization.md)

Referenced PractitionerRole Organization (https://standards.digital.health.nz/ns/hpi-organisation-id#HPIOrganization#GZZ998-G (use: official))

-------

| | |
| :--- | :--- |
| Active: | true |



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "GZZ998-G",
  "meta" : {
    "profile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization"]
  },
  "identifier" : [{
    "use" : "official",
    "system" : "https://standards.digital.health.nz/ns/hpi-organisation-id",
    "value" : "GZZ998-G",
    "assigner" : {
      "reference" : "Organization/G00001-G"
    }
  }],
  "active" : true,
  "name" : "Referenced PractitionerRole Organization"
}

```
