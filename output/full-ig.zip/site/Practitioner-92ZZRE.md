# 92ZZRE - New Zealand HPI Implementation Guide v1.5.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **92ZZRE**

## Example Practitioner: 92ZZRE

version: 10673; Last updated: 2022-10-14 08:04:23+1300

Profile: [HPI Practitioner](StructureDefinition-HPIPractitioner.md)

Security Label: [moderate (Details: Confidentiality code M = 'moderate')](http://terminology.hl7.org/7.5.0/CodeSystem-v3-Confidentiality.html)

Walter Eugene O'Reilly (official) (https://standards.digital.health.nz/ns/hpi-person-id#HPIProvider#92ZZRE (use: official))

-------

| | |
| :--- | :--- |
| Alt. Name: | Radar (Old) |
| Language: | English |



## Resource Content

```json
{
  "resourceType" : "Practitioner",
  "id" : "92ZZRE",
  "meta" : {
    "versionId" : "10673",
    "lastUpdated" : "2022-10-14T08:04:23.000+13:00",
    "profile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPIPractitioner"],
    "security" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-Confidentiality",
      "code" : "M"
    }]
  },
  "identifier" : [{
    "use" : "official",
    "system" : "https://standards.digital.health.nz/ns/hpi-person-id",
    "value" : "92ZZRE",
    "assigner" : {
      "reference" : "Organization/G00001-G"
    }
  }],
  "name" : [{
    "use" : "official",
    "family" : "O'Reilly",
    "given" : ["Walter", "Eugene"],
    "prefix" : ["cpl"]
  },
  {
    "use" : "old",
    "given" : ["Radar"]
  }],
  "communication" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:639:-3",
      "version" : "2007",
      "code" : "eng",
      "display" : "English"
    }],
    "text" : "English"
  }]
}

```
