# HPI Practitioner - New Zealand HPI Implementation Guide v1.5.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **HPI Practitioner**

## Resource Profile: HPI Practitioner 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.org.nz/fhir/StructureDefinition/HPIPractitioner | *Version*:1.5.0 |
| Active as of 2026-11-08 | *Computable Name*:HpiPractitioner |

 
The practitioner exposed by the HPI. This is the person who delivers healthcare or healthcare related services. 

 
Describe the Practitioner that will be returned by the HPI 

The Practitioner resource represents any provider of healthcare - not restricted to those with formal qualifications.

The current HPI contains practitioners covered by the Health Practitioners Competence Assurance Amendment Act 2019. This includes all:

* Chinese Medicine Practitioners,
* Chiropractors,
* Dentists,
* Dental hygienist and Dental and Oral health therapists,
* Dietitians,
* Medical Laboratory Scientist and Technicians including phlebotomists and mortuary technicians,
* Anaesthetic Technologists,
* Medical Radiation Technologists,
* Medical Practitioners (all doctors and specialists),
* Midwifes,
* Nurses,
* Occupational Therapists,
* Optometrists and optical dispensers,
* Osteopaths,
* Paramedics,
* Pharmacists,
* Physiotherapists,
* Podiatrists, and
* Psychologists.

It is intended with the upgraded capabilities that other professional groups may supply their members eg Social Workers, Acupuncturists, Audiologists, Counsellors, Cardiac Physiologists, Nutritionist.

Other groups of health workers will need a CPN to be identified in digital records eg Allied Health assistants, Aged care, Personal Care and support workers, administrative staff, practice managers, students working in healthcare setting.

Consideration is being given to ‘self-asserted’ data.

### Key differences from spec

* DeathDate extension
* Ethnicity extension
* Qualification has a status (see more differences below)
* Initial date of registration extension
* APC history extension
* Additional Authorizations extension (complex)
* Scope of Practice extension (complex)
* Conditions on Practice extension (complex)

### Registration Authority (RA)

A registration authority is an organization that asserts the information about a practitioner’s competence to perform a particular health role. This includes the Responsible Authorities named under the Act and Professional bodies who require a level of education and professional development to be registered as a member and be issued a certificate to practice. - Information supplied by the Registration Authority can only be changed by the Registration Authority. Health provider organisations may add their workers to the HPI with personal identity details ie name, date of birth, gender, ethnicity and the languages they speak in order to get a CPN. At a later stage a Responsible Authority or a Professional body may add information about their registration with that body ie Annual Practicing Certificate dates, scopes of practice etc.

### Resource identifiers

There are 2 levels of identifier in the practitioner resource.

**Practitioner.identifier** is the top level identifier assigned by the HPI (and the source of the resource id as described in the background section). There can be multiple identifiers for any given resource as part of managing the Practitioner (for example removal of duplicate identifiers). The current identifier will have a **use** value of ‘official’, others will have a **use** value of ‘old’. The HPI identifier will always have a system value of '\https://standards.digital.health.nz/ns/hpi-person-id' It is the client's responsibility to check the value of the use element.

**Practitioner.qualification.identifier** is the identifier assigned by the Registration authority - for example the Medical Council Number, or Nursing Council number. This will also be found under the **Practitioner.identifier** but with a system value related to the Registration authority who issued it, for nursing council this will be 'https://standards.digital.health.nz/ns/nursing-council-id'.

### Qualifications

To practice in NZ, practitioners must gain registration with a Responsible Authority (RA). The RA ensures practitioners are competent and fit to practice. Practitioners may provide evidence of educational qualifications attained that are considered by the RA when granting registrations, however the educational qualifications alone do not give a practitioner the right to practice in NZ.

In order to clearly distinguish a person’s licence to practice and their educational qualifications the HpiPractitioner profile uses the Practitioner.qualification element to represent the practitioner’s registration and the extension Practitioner.educational.qualification element to represent a person’s educational qualifications.

Other health providers (not considered Practitioners in NZ) are recorded in the HPI. They may not have a registration but will supply educational qualifications as part of their profile. In the HPI educational qualifications are an element of practitioner not a sub element of practitioner.qualification (ie registration).

### A registration is made up of

* Element: Type
  * Description: the type of registration – nurse, physiotherapist, doctor etc.
  * Profile element: Practitioner.qualification.code
* Element: Identifier
  * Description: an identifier issued by the responsible authority eg medical council number
  * Profile element: Practitioner.qualification.identifier
* Element: Status
  * Description: indicates whether the registration is current
  * Profile element: Practitioner.qualification.extension:registration-status-code
* Element: Initial registration date
  * Description: date the practitioner was first registered with the responsible authority
  * Profile element: Practitioner.qualification.extension:registration-initial-date
* Element: Annual practicing certificate
  * Description: The period of the most recently issued APC. APC periods are also available as repeated APC history extensions, including historical periods.
  * Profile element: Practitioner.qualification.period
* Element: APC history
  * Description: Each occurrence represents one APC period. The period is carried in the extension's required`period`sub-extension. Periods are ordered by start date, newest first; periods without a start date follow dated periods.
  * Profile element: Practitioner.qualification.extension:apc-history.extension:period
* Element: Issuer
  * Description: HPI Identifier of the responsible authority
  * Profile element: Practitioner.qualification.issuer
* Element: Scope of practice
  * Description: range of health services a practitioner is authorised to perform
  * Profile element: Practitioner.qualification.extension:scope-of-practice
* Element: Condition on practice
  * Description: conditions the health practitioner is subject to in relation to their scope of practice
  * Profile element: Practitioner.qualification.extension:condition-on-practice
* Element: Additional Authorisation
  * Description: additional services that a practitioner is authorised to perform
  * Profile element: Practitioner.qualification.extension:additional-authorisation

### An education qualification is made up of

* Element: Fullname
  * Profile element: Practitioner.extension:educational-qualification.extension:fullname
* Element: Shortname
  * Profile element: Practitioner.extension:educational-qualification.extension:shortname
* Element: Year
  * Profile element: Practitioner.extension:educational-qualification.extension:year
* Element: Institution
  * Profile element: Practitioner.extension:educational-qualification.extension:institution
* Element: City
  * Profile element: Practitioner.extension:educational-qualification.extension:city
* Element: Country
  * Profile element: Practitioner.extension:educational-qualification.extension:country

### Redacted Practitioner details

A person can make a request to their council to make their record confidential. When this is the case the person’s name and other personal details will not be returned in any search or get response. Identifiers and registration details are returned. [See Confidentiality](/businessView.md#confidentiality).

A practitioner’s Date of birth, Gender and Ethnicity are supplied when a practitioner is added and maintained by their Responsible Authority, but they are withheld on a Get Practitioner response. Admin permissions are required to get all the practitioner details in a response.

The Practitioner resources will contain a security element of "REDACTED" in the meta data when data items within the practitioner resource have been withheld.

#### HPI Practitioner security labels

* Confidentiality level: Low
  * Code: L
  * HPI Use: All Registered Practitioner records with no confidentiality flag set
  * Information that is redacted with a read scope: Gender, birthDate and ethnicity
* Confidentiality level: Moderate
  * Code: M
  * HPI Use: All Non-registered Practitioner records with no confidentiality flag set
  * Information that is redacted with a read scope: Gender, birthDate and ethnicity
* Confidentiality level: Restricted and,Redacted
  * Code: R, andREDACTED
  * HPI Use: All Practitioner records with confidentiality set (Registered and Non-registered Practitioners)
  * Information that is redacted with a read scope: Name OfficialName UsualName(s) OldGenderDate of BirthDate of deathLanguage(s)EthnicityConditionOnPractice (Applies to Registered Practitioner only)

#### Example of Practitioner with confidentiality flag set

```
{
    "resourceType": "Practitioner",
    "id": "90ZZLP",
    "meta": {
        "versionId": "9971",
        "lastUpdated": "2022-04-07T09:12:26.000+12:00",
        "profile": [
            "http://hl7.org.nz/fhir/StructureDefinition/HPIPractitioner"
        ],
        "security": [
            {
                "system": "http://terminology.hl7.org/CodeSystem/v3-ObservationValue",
                "code": "REDACTED"
            },
            {
                "system": "http://terminology.hl7.org/CodeSystem/v3-Confidentiality",
                "code": "R"
            }
        ]
…
}

```

**Usages:**

* Refer to this Profile: [HPI Practitioner role](StructureDefinition-HPIPractitionerRole.md)
* Examples for this Profile: [Practitioner/90ZZLP](Practitioner-90ZZLP.md), [Practitioner/91ZABY](Practitioner-91ZABY.md), [Practitioner/92ZZRE](Practitioner-92ZZRE.md), [Practitioner/98ZZQJ](Practitioner-98ZZQJ.md) and [Practitioner/99ZZZS](Practitioner-99ZZZS.md)
* CapabilityStatements using this Profile: [Capability Statement describing HPI FHIR APIs](CapabilityStatement-HpiCapabilityStatement.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/hl7.org.nz.fhir.ig.hpi|current/StructureDefinition/StructureDefinition-HPIPractitioner.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-HPIPractitioner.csv), [Excel](StructureDefinition-HPIPractitioner.xlsx), [Schematron](StructureDefinition-HPIPractitioner.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "HPIPractitioner",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-category",
    "valueString" : "Base.Individuals"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-security-category",
    "valueCode" : "individual"
  }],
  "url" : "http://hl7.org.nz/fhir/StructureDefinition/HPIPractitioner",
  "version" : "1.5.0",
  "name" : "HpiPractitioner",
  "title" : "HPI Practitioner",
  "status" : "active",
  "date" : "2026-11-08T20:17:19+00:00",
  "publisher" : "Te Whatu Ora",
  "contact" : [{
    "name" : "Te Whatu Ora",
    "telecom" : [{
      "system" : "email",
      "value" : "mailto:integration@health.govt.nz"
    }]
  }],
  "description" : "The practitioner exposed by the HPI. This is the person who delivers healthcare or healthcare related services.",
  "purpose" : "Describe the Practitioner that will be returned by the HPI",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "servd",
    "uri" : "http://www.omg.org/spec/ServD/1.0/",
    "name" : "ServD"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Practitioner",
  "baseDefinition" : "http://hl7.org.nz/fhir/StructureDefinition/NzPractitioner",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Practitioner",
      "path" : "Practitioner"
    },
    {
      "id" : "Practitioner.extension:death-date",
      "path" : "Practitioner.extension",
      "sliceName" : "death-date",
      "short" : "The date this person died"
    },
    {
      "id" : "Practitioner.extension:death-date.extension:source",
      "path" : "Practitioner.extension.extension",
      "sliceName" : "source",
      "max" : "0"
    },
    {
      "id" : "Practitioner.extension:educational-qualification",
      "path" : "Practitioner.extension",
      "sliceName" : "educational-qualification"
    },
    {
      "id" : "Practitioner.extension:educational-qualification.extension:country",
      "path" : "Practitioner.extension.extension",
      "sliceName" : "country"
    },
    {
      "id" : "Practitioner.extension:educational-qualification.extension:country.value[x]",
      "path" : "Practitioner.extension.extension.value[x]",
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://nzhts.digital.health.nz/fhir/ValueSet/country-code"
      }
    },
    {
      "id" : "Practitioner.extension:ethnicity",
      "path" : "Practitioner.extension",
      "sliceName" : "ethnicity",
      "max" : "6"
    },
    {
      "id" : "Practitioner.extension:iwi",
      "path" : "Practitioner.extension",
      "sliceName" : "iwi",
      "max" : "0"
    },
    {
      "id" : "Practitioner.identifier",
      "path" : "Practitioner.identifier",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "use"
        },
        {
          "type" : "value",
          "path" : "system"
        }],
        "description" : "The identifiers",
        "rules" : "openAtEnd"
      }
    },
    {
      "id" : "Practitioner.identifier.use",
      "path" : "Practitioner.identifier.use",
      "short" : "official | old",
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://nzhts.digital.health.nz/fhir/ValueSet/hpi-identifier-use-code"
      }
    },
    {
      "id" : "Practitioner.identifier:HPI",
      "path" : "Practitioner.identifier",
      "sliceName" : "HPI",
      "short" : "The currently active CPN (Common Person Name)",
      "definition" : "The HPI Person Identifier or CPN of the person that is currently in use.   It can be referred to as the ‘Live’ CPN or “live” HPI Person ID”. A person can only have one live CPN",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.identifier:HPI.use",
      "path" : "Practitioner.identifier.use",
      "short" : "fixed to official",
      "min" : 1,
      "fixedCode" : "official"
    },
    {
      "id" : "Practitioner.identifier:HPI.type",
      "path" : "Practitioner.identifier.type",
      "max" : "0"
    },
    {
      "id" : "Practitioner.identifier:HPI.system",
      "path" : "Practitioner.identifier.system",
      "min" : 1,
      "fixedUri" : "https://standards.digital.health.nz/ns/hpi-person-id"
    },
    {
      "id" : "Practitioner.identifier:HPI.period",
      "path" : "Practitioner.identifier.period",
      "max" : "0"
    },
    {
      "id" : "Practitioner.identifier:HPI.assigner",
      "path" : "Practitioner.identifier.assigner",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization"]
      }]
    },
    {
      "id" : "Practitioner.identifier:dormant",
      "path" : "Practitioner.identifier",
      "sliceName" : "dormant",
      "short" : "CPN (Common Person Name) identifiers that have been deprecated for this Person",
      "definition" : "An HPI Person Identifier or CPN of the person that is no longer in use.   An HPI Person ID becomes dormant when it is discovered that 2 CPNs exist for the same person. The CPNs are linked, one becomes ‘live’ the other ‘dormant’.",
      "min" : 0,
      "max" : "*",
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.identifier:dormant.use",
      "path" : "Practitioner.identifier.use",
      "short" : "fixed to old",
      "min" : 1,
      "fixedCode" : "old"
    },
    {
      "id" : "Practitioner.identifier:dormant.type",
      "path" : "Practitioner.identifier.type",
      "max" : "0"
    },
    {
      "id" : "Practitioner.identifier:dormant.system",
      "path" : "Practitioner.identifier.system",
      "min" : 1,
      "fixedUri" : "https://standards.digital.health.nz/ns/hpi-person-id"
    },
    {
      "id" : "Practitioner.identifier:dormant.period",
      "path" : "Practitioner.identifier.period",
      "max" : "0"
    },
    {
      "id" : "Practitioner.identifier:dormant.assigner",
      "path" : "Practitioner.identifier.assigner",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization"]
      }]
    },
    {
      "id" : "Practitioner.identifier:RA",
      "path" : "Practitioner.identifier",
      "sliceName" : "RA",
      "short" : "The RA Identifier",
      "min" : 0,
      "max" : "*",
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.identifier:RA.use",
      "path" : "Practitioner.identifier.use",
      "short" : "fixed to official",
      "min" : 1,
      "fixedCode" : "official"
    },
    {
      "id" : "Practitioner.identifier:RA.type",
      "path" : "Practitioner.identifier.type",
      "max" : "0"
    },
    {
      "id" : "Practitioner.identifier:RA.system",
      "path" : "Practitioner.identifier.system",
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://nzhts.digital.health.nz/fhir/ValueSet/hpi-ra-identifier-code"
      }
    },
    {
      "id" : "Practitioner.identifier:RA.period",
      "path" : "Practitioner.identifier.period",
      "max" : "0"
    },
    {
      "id" : "Practitioner.identifier:RA.assigner",
      "path" : "Practitioner.identifier.assigner",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization"]
      }]
    },
    {
      "id" : "Practitioner.active",
      "path" : "Practitioner.active",
      "max" : "0"
    },
    {
      "id" : "Practitioner.name.use",
      "path" : "Practitioner.name.use",
      "short" : "usual | official | old",
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://nzhts.digital.health.nz/fhir/ValueSet/hpi-human-name-use-code"
      }
    },
    {
      "id" : "Practitioner.name.text",
      "path" : "Practitioner.name.text",
      "max" : "0"
    },
    {
      "id" : "Practitioner.name.prefix",
      "path" : "Practitioner.name.prefix",
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://nzhts.digital.health.nz/fhir/ValueSet/name-prefix-code"
      }
    },
    {
      "id" : "Practitioner.name.suffix",
      "path" : "Practitioner.name.suffix",
      "max" : "0",
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://nzhts.digital.health.nz/fhir/ValueSet/name-suffix-code"
      }
    },
    {
      "id" : "Practitioner.name.period",
      "path" : "Practitioner.name.period",
      "max" : "0"
    },
    {
      "id" : "Practitioner.telecom",
      "path" : "Practitioner.telecom",
      "max" : "0"
    },
    {
      "id" : "Practitioner.address",
      "path" : "Practitioner.address",
      "max" : "0",
      "type" : [{
        "code" : "Address",
        "profile" : ["http://hl7.org.nz/fhir/StructureDefinition/NzAddress"]
      }]
    },
    {
      "id" : "Practitioner.photo",
      "path" : "Practitioner.photo",
      "max" : "0"
    },
    {
      "id" : "Practitioner.qualification.id",
      "path" : "Practitioner.qualification.id",
      "max" : "0"
    },
    {
      "id" : "Practitioner.qualification.extension:additional-authorisation",
      "path" : "Practitioner.qualification.extension",
      "sliceName" : "additional-authorisation",
      "short" : "Additional things the person is authorized to do"
    },
    {
      "id" : "Practitioner.qualification.extension:additional-authorisation.extension:code",
      "path" : "Practitioner.qualification.extension.extension",
      "sliceName" : "code"
    },
    {
      "id" : "Practitioner.qualification.extension:additional-authorisation.extension:code.valueCodeableConcept",
      "path" : "Practitioner.qualification.extension.extension.valueCodeableConcept",
      "binding" : {
        "strength" : "preferred",
        "valueSet" : "https://nzhts.digital.health.nz/fhir/ValueSet/practitioner-additional-authorisation-code|1.0.1"
      }
    },
    {
      "id" : "Practitioner.qualification.extension:condition-on-practice",
      "path" : "Practitioner.qualification.extension",
      "sliceName" : "condition-on-practice",
      "short" : "Conditions that have been applied to the ability of the person to practice"
    },
    {
      "id" : "Practitioner.qualification.extension:registration-initial-date",
      "path" : "Practitioner.qualification.extension",
      "sliceName" : "registration-initial-date",
      "short" : "The date that the person was originally registered"
    },
    {
      "id" : "Practitioner.qualification.extension:registration-status-code",
      "path" : "Practitioner.qualification.extension",
      "sliceName" : "registration-status-code",
      "short" : "Status of the registration, and the date it was set"
    },
    {
      "id" : "Practitioner.qualification.extension:registration-status-code.extension:status",
      "path" : "Practitioner.qualification.extension.extension",
      "sliceName" : "status"
    },
    {
      "id" : "Practitioner.qualification.extension:registration-status-code.extension:status.valueCodeableConcept",
      "path" : "Practitioner.qualification.extension.extension.valueCodeableConcept",
      "binding" : {
        "strength" : "extensible",
        "valueSet" : "https://nzhts.digital.health.nz/fhir/ValueSet/practitioner-registration-status-code|2.0"
      }
    },
    {
      "id" : "Practitioner.qualification.extension:scope-of-practice",
      "path" : "Practitioner.qualification.extension",
      "sliceName" : "scope-of-practice",
      "short" : "the health services a practitioner is authorised to perform eg Nurse Practitioner"
    },
    {
      "id" : "Practitioner.qualification.extension:scope-of-practice.extension:code",
      "path" : "Practitioner.qualification.extension.extension",
      "sliceName" : "code"
    },
    {
      "id" : "Practitioner.qualification.extension:scope-of-practice.extension:code.valueCodeableConcept",
      "path" : "Practitioner.qualification.extension.extension.valueCodeableConcept",
      "binding" : {
        "strength" : "preferred",
        "valueSet" : "https://nzhts.digital.health.nz/fhir/ValueSet/practitioner-scope-of-practice-code|2.1.0"
      }
    },
    {
      "id" : "Practitioner.qualification.extension:apc-history",
      "path" : "Practitioner.qualification.extension",
      "sliceName" : "apc-history",
      "short" : "A period covered by an annual practicing certificate (APC), including previous APC periods",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.org.nz/fhir/StructureDefinition/apc-history"]
      }]
    },
    {
      "id" : "Practitioner.qualification.identifier",
      "path" : "Practitioner.qualification.identifier",
      "short" : "The practitioner's identifier issued by the Responsible Authority eg medical council number, nursing council number"
    },
    {
      "id" : "Practitioner.qualification.code",
      "path" : "Practitioner.qualification.code",
      "short" : "Coded representation of the Responsible Authority that issues the registration",
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://nzhts.digital.health.nz/fhir/ValueSet/practitioner-registration-authority-code"
      }
    },
    {
      "id" : "Practitioner.qualification.period",
      "path" : "Practitioner.qualification.period",
      "short" : "The period of the annual practicing certificate issued by the  Responsible Authority"
    },
    {
      "id" : "Practitioner.qualification.issuer",
      "path" : "Practitioner.qualification.issuer",
      "short" : "The HPI Organisation ID of the Responsible Authority that issues the registration",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization"]
      }]
    },
    {
      "id" : "Practitioner.communication.coding",
      "path" : "Practitioner.communication.coding",
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://nzhts.digital.health.nz/fhir/ValueSet/language-code"
      }
    }]
  }
}

```
