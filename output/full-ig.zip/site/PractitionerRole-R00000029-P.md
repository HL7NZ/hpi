# R00000029-P - New Zealand HPI Implementation Guide v1.5.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **R00000029-P**

## Example PractitionerRole: R00000029-P

version: 4; Last updated: 2022-11-23 11:10:39+1300

Profile: [HPI Practitioner role](StructureDefinition-HPIPractitionerRole.md)

Security Label: [moderate (Details: Confidentiality code M = 'moderate')](http://terminology.hl7.org/7.5.0/CodeSystem-v3-Confidentiality.html)

Anonymous Practitioner (https://standards.digital.health.nz/ns/hpi-person-id#HPIProvider#90ZZLP (use: official)): Receptionist (General) at Referenced PractitionerRole Organization (https://standards.digital.health.nz/ns/hpi-organisation-id#HPIOrganization#GZZ998-G (use: official)) (https://standards.digital.health.nz/ns/hpi-practitionerrole-id#HPIPractitionerRole#R00000029-P (use: official))

-------

| | | | |
| :--- | :--- | :--- | :--- |
| Active: | true | Valid Period: | 2011-05-06 --> (ongoing) |
| Practitioner: | [Anonymous Practitioner (https://standards.digital.health.nz/ns/hpi-person-id#HPIProvider#90ZZLP (use: official))](Practitioner-90ZZLP.md) | | |
| Organization: | [Referenced PractitionerRole Organization (https://standards.digital.health.nz/ns/hpi-organisation-id#HPIOrganization#GZZ998-G (use: official))](Organization-GZZ998-G.md) | | |
| Role: | Receptionist (General) | | |
| Location: | [Live Facilty (Enrolling GP Practice) (https://standards.digital.health.nz/ns/hpi-facility-id#HPIFacility#FZZ999-B (use: official))](Location-FZZ999-B.md) | | |
| Contact Detail | * ph: 1324654769(Work)
* [saranya@test.com](mailto:saranya@test.com)
* 90ZZLP@contactme.com
* 1324654765(Work)
* ph: 1324654767(Work)
* ph: 1324654766(Temp)
* ph: 1324654768(Work)
 | | |
| Messaging Address: | * provider: healthlink
* value: changed-edi-address
 | | |
| null: | * person: [Person Test All](Person-testall.md)
* organization: [HPI Root Organization (https://standards.digital.health.nz/ns/hpi-organisation-id#HPIOrganization#G00001-G (use: official))](Organization-G00001-G.md)
 | | |



## Resource Content

```json
{
  "resourceType" : "PractitionerRole",
  "id" : "R00000029-P",
  "meta" : {
    "versionId" : "4",
    "lastUpdated" : "2022-11-23T11:10:39.516+13:00",
    "profile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPIPractitionerRole"],
    "security" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-Confidentiality",
      "code" : "M"
    }]
  },
  "extension" : [{
    "extension" : [{
      "url" : "person",
      "valueReference" : {
        "reference" : "Person/testall"
      }
    },
    {
      "url" : "organization",
      "valueReference" : {
        "reference" : "Organization/G00001-G"
      }
    }],
    "url" : "http://hl7.org.nz/fhir/StructureDefinition/practitionerRole-creator"
  },
  {
    "extension" : [{
      "url" : "provider",
      "valueString" : "healthlink"
    },
    {
      "url" : "value",
      "valueString" : "changed-edi-address"
    }],
    "url" : "http://hl7.org.nz/fhir/StructureDefinition/messaging-address"
  }],
  "identifier" : [{
    "use" : "official",
    "system" : "https://standards.digital.health.nz/ns/hpi-practitionerrole-id",
    "value" : "R00000029-P",
    "assigner" : {
      "reference" : "Organization/G00001-G"
    }
  }],
  "active" : true,
  "period" : {
    "start" : "2011-05-06"
  },
  "practitioner" : {
    "reference" : "Practitioner/90ZZLP"
  },
  "organization" : {
    "reference" : "Organization/GZZ998-G"
  },
  "code" : [{
    "coding" : [{
      "system" : "https://nzhts.digital.health.nz/fhir/CodeSystem/anzsco",
      "version" : "2022",
      "code" : "542111",
      "display" : "Receptionist (General)"
    }],
    "text" : "Receptionist (General)"
  }],
  "location" : [{
    "reference" : "Location/FZZ999-B"
  }],
  "telecom" : [{
    "system" : "phone",
    "value" : "1324654769",
    "use" : "work",
    "rank" : 1,
    "period" : {
      "start" : "2011-05-06"
    }
  },
  {
    "system" : "email",
    "value" : "saranya@test.com",
    "use" : "work",
    "rank" : 2,
    "period" : {
      "start" : "2011-05-06"
    }
  },
  {
    "system" : "url",
    "value" : "90ZZLP@contactme.com",
    "use" : "work",
    "rank" : 1,
    "period" : {
      "start" : "2011-05-06"
    }
  },
  {
    "system" : "sms",
    "value" : "1324654765",
    "use" : "work",
    "rank" : 1,
    "period" : {
      "start" : "2011-05-06"
    }
  },
  {
    "system" : "phone",
    "value" : "1324654767",
    "use" : "work",
    "rank" : 3,
    "period" : {
      "start" : "2011-05-06"
    }
  },
  {
    "system" : "phone",
    "value" : "1324654766",
    "use" : "temp",
    "rank" : 1,
    "period" : {
      "start" : "2011-05-06"
    }
  },
  {
    "system" : "phone",
    "value" : "1324654768",
    "use" : "work",
    "rank" : 2,
    "period" : {
      "start" : "2011-05-06"
    }
  }]
}

```
