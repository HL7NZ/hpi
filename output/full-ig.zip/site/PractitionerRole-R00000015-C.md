# R00000015-C - New Zealand HPI Implementation Guide v1.5.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **R00000015-C**

## Example PractitionerRole: R00000015-C

version: 1; Last updated: 2022-09-01 15:21:57+1200

Profile: [HPI Practitioner role](StructureDefinition-HPIPractitionerRole.md)

Security Labels: [restricted (Details: Confidentiality code R = 'restricted')](http://terminology.hl7.org/7.5.0/CodeSystem-v3-Confidentiality.html), [redacted (Details: ObservationValue code REDACTED = 'redacted')](http://terminology.hl7.org/7.5.0/CodeSystem-v3-ObservationValue.html)

Practitioner Example (official) (https://standards.digital.health.nz/ns/hpi-person-id#HPIProvider#99ZZZS (use: official)): Aircraft Maintenance Engineer (Mechanical) (https://standards.digital.health.nz/ns/hpi-practitionerrole-id#HPIPractitionerRole#R00000015-C (use: official))

-------

| | |
| :--- | :--- |
| Active: | false |
| Practitioner: | [Practitioner Example (official) (https://standards.digital.health.nz/ns/hpi-person-id#HPIProvider#99ZZZS (use: official))](Practitioner-99ZZZS.md) |
| Role: | Aircraft Maintenance Engineer (Mechanical) |



## Resource Content

```json
{
  "resourceType" : "PractitionerRole",
  "id" : "R00000015-C",
  "meta" : {
    "versionId" : "1",
    "lastUpdated" : "2022-09-01T15:21:57.885+12:00",
    "profile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPIPractitionerRole"],
    "security" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-Confidentiality",
      "code" : "R"
    },
    {
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationValue",
      "code" : "REDACTED"
    }]
  },
  "identifier" : [{
    "use" : "official",
    "system" : "https://standards.digital.health.nz/ns/hpi-practitionerrole-id",
    "value" : "R00000015-C",
    "assigner" : {
      "reference" : "Organization/G00001-G"
    }
  }],
  "active" : false,
  "practitioner" : {
    "reference" : "Practitioner/99ZZZS"
  },
  "code" : [{
    "coding" : [{
      "system" : "https://nzhts.digital.health.nz/fhir/CodeSystem/anzsco",
      "version" : "2022",
      "code" : "323112",
      "display" : "Aircraft Maintenance Engineer (Mechanical)"
    }],
    "text" : "Aircraft Maintenance Engineer (Mechanical)"
  }]
}

```
