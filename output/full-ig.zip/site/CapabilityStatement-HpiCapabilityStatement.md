# CapabilityStatement - New Zealand HPI Implementation Guide v1.5.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CapabilityStatement**

## CapabilityStatement: CapabilityStatement 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.org.nz/fhir/ig/hpi/CapabilityStatement/HpiCapabilityStatement | *Version*:1.5.0 |
| Draft as of 2020-04-01 | *Computable Name*:HPI_CapabilityStatement |

 
This is the computable resource that describes the RESTful endpoint 

 [Raw OpenAPI-Swagger Definition file](HpiCapabilityStatement.openapi.json) | [Download](HpiCapabilityStatement.openapi.json) 



## Resource Content

```json
{
  "resourceType" : "CapabilityStatement",
  "id" : "HpiCapabilityStatement",
  "url" : "http://hl7.org.nz/fhir/ig/hpi/CapabilityStatement/HpiCapabilityStatement",
  "version" : "1.5.0",
  "name" : "HPI_CapabilityStatement",
  "title" : "Capability Statement describing HPI FHIR APIs",
  "status" : "draft",
  "date" : "2020-04-01",
  "publisher" : "Te Whatu Ora",
  "contact" : [{
    "name" : "Te Whatu Ora",
    "telecom" : [{
      "system" : "email",
      "value" : "mailto:integration@health.govt.nz"
    }]
  }],
  "description" : "This is the computable resource that describes the RESTful endpoint",
  "kind" : "instance",
  "implementation" : {
    "description" : "The HPI endpoint",
    "url" : "https://api.hip.digital.health.nz/fhir/hpi/v1/"
  },
  "fhirVersion" : "4.0.1",
  "format" : ["json"],
  "rest" : [{
    "mode" : "server",
    "resource" : [{
      "type" : "Practitioner",
      "profile" : "http://hl7.org.nz/fhir/StructureDefinition/HPIPractitioner",
      "supportedProfile" : ["http://hl7.org.nz/fhir/StructureDefinition/hpi-practitioner"],
      "documentation" : "Practitioner query\n\n",
      "interaction" : [{
        "code" : "read",
        "documentation" : "GET,  [base]/Practitioner[cpn],  Retrieves a Practitioner resource by Id, system/Practitioner.r"
      },
      {
        "code" : "search-type",
        "documentation" : "GET,[base]/Practitioner, Queries against the Practitioner using name and other search parameters. Will return a Bundle (even if there are no matching resources),system/Practitioner.s "
      },
      {
        "code" : "create",
        "documentation" : "POST',[base]/Practitioner, Creates a new Practitioner record , system/Practitioner.c"
      }],
      "searchParam" : [{
        "name" : "identifier",
        "type" : "token",
        "documentation" : "For searching a Practitioner resource using their council/board registration number"
      },
      {
        "name" : "name",
        "type" : "string",
        "documentation" : "Should contain the person’s full name, include all given names and family name."
      },
      {
        "name" : "gender",
        "type" : "token",
        "documentation" : "Use with name and birthdate. Search by gender alone is not allowed."
      },
      {
        "name" : "birthdate",
        "type" : "date",
        "documentation" : "Use with name and gender. Search by birthdate alone is not allowed."
      }],
      "operation" : [{
        "name" : "update-core",
        "definition" : "https://hpi-ig.hip.digital.health.nz/OperationDefinition/practitioner-update-core",
        "documentation" : "POST, [base]/Practitioner[cpn],An operation that updates a health providers demographic details,  system/Practitioner.u"
      }]
    },
    {
      "type" : "PractitionerRole",
      "supportedProfile" : ["http://hl7.org.nz/fhir/StructureDefinition/hpi-practitioner-role"],
      "documentation" : "PractitionerRole query\n",
      "interaction" : [{
        "code" : "read",
        "documentation" : "GET, [base]/PractitionerRole[id], Used to retrieve a PractitionerRole resource by Id, system/PractitionerRole.r"
      },
      {
        "code" : "search-type",
        "documentation" : "GET, [base]/PractitionerRole, Queries against PractitionerRole using hpi-person-id and other parameters. Will return a Bundle (even if there are no matching resources), system/PractitionerRole.s"
      },
      {
        "code" : "create",
        "documentation" : "POST, [base]/PractitionerRole, Create a new PractitionerRole, system/PractitionerRole.c"
      },
      {
        "code" : "update",
        "documentation" : "PUT, [base]/PractitionerRole[id], Update contact details and end date on an existing PractitionerRole record, system/PractitionerRole.u"
      }],
      "searchInclude" : ["practitioner", "organization", "location"],
      "searchParam" : [{
        "name" : "practitioner",
        "type" : "reference",
        "documentation" : "Given an hpi-person-id, returns the PractitionerRole records associated with that id"
      },
      {
        "name" : "organization",
        "type" : "reference",
        "documentation" : "Not yet enabled. Given an hpi-organization-id, returns the PractitionerRole records associated with that id"
      },
      {
        "name" : "location",
        "type" : "token",
        "documentation" : "Given an hpi-facility-id, returns the PractitionerRole records associated with that id"
      },
      {
        "name" : "role",
        "type" : "token",
        "documentation" : "Returns PractitionerRole records based on role code"
      },
      {
        "name" : "active",
        "type" : "token",
        "documentation" : "To enable exclusion of inactive PractitionerRole records"
      }]
    },
    {
      "type" : "Organization",
      "supportedProfile" : ["http://hl7.org.nz/fhir/StructureDefinition/hpi-organization"],
      "documentation" : "Organization query\n",
      "interaction" : [{
        "code" : "read",
        "documentation" : "GET, [base]/Organization/[hpi-org-id], Used to retrieve an Organization resource by Id, system/Organization.r"
      },
      {
        "code" : "search-type",
        "documentation" : "GET, [base]/Organization, Queries against the Organization using name or other parameters. Will return a Bundle (even if there are no matching resources), system/Organization.s"
      }],
      "searchParam" : [{
        "name" : "active",
        "type" : "token",
        "documentation" : "To enable exclusion of inactive organizations"
      },
      {
        "name" : "name",
        "type" : "string",
        "documentation" : "For searching using the organisation’s name or an alias name"
      },
      {
        "name" : "identifier",
        "type" : "token",
        "documentation" : "For searching using an organisation’s New Zealand Business Number (NZBN) or their legacy NZHIS agency code."
      },
      {
        "name" : "type",
        "type" : "token",
        "documentation" : "For searching using an organisation's type E.g. DHB, RA, Educational institution"
      },
      {
        "name" : "partOf",
        "type" : "reference",
        "documentation" : "For retrieving organizations that are 'part of' another. "
      }]
    },
    {
      "type" : "Location",
      "supportedProfile" : ["http://hl7.org.nz/fhir/StructureDefinition/hpi-location"],
      "documentation" : "Location query",
      "interaction" : [{
        "code" : "read",
        "documentation" : "GET, [base]/Location/[hpi-facid], Used to retrieve an Location resource by Id, system/Location.r"
      },
      {
        "code" : "search-type",
        "documentation" : "GET, [base]/Location, Queries against the Location using name or other parameters. Will return a Bundle (even if there are no matching resources), system/Location.s"
      }],
      "searchParam" : [{
        "name" : "identifier",
        "type" : "token",
        "documentation" : "For searching using an organization’s legacy NZHIS facility code."
      },
      {
        "name" : "name",
        "type" : "string",
        "documentation" : "For searching using the Locations name or alias name"
      },
      {
        "name" : "type",
        "type" : "token",
        "documentation" : "Retrieve Locations of the given type"
      },
      {
        "name" : "address",
        "type" : "string",
        "documentation" : "Retrieve the Locations by address"
      },
      {
        "name" : "organization",
        "type" : "reference",
        "documentation" : "Retrieve Locations with the given ManagingOrganization"
      },
      {
        "name" : "dhb",
        "type" : "token",
        "documentation" : "Searching for Locations that are in a DHBs catchment area."
      },
      {
        "name" : "status",
        "type" : "token",
        "documentation" : "Not yet enabled. To enable exclusion of inactive locations"
      },
      {
        "name" : "messaging-address",
        "type" : "string",
        "documentation" : "Search by EDI address"
      }]
    }]
  }]
}

```
