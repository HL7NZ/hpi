# GZZ908-B - New Zealand HPI Implementation Guide v1.4.10

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GZZ908-B**

## Example Organization: GZZ908-B

Profile: [HPI Organization](StructureDefinition-HpiOrganization.md)

Reference Organization GZZ908-B (https://standards.digital.health.nz/ns/hpi-organisation-id#HPIOrganization#GZZ908-B (use: official))

-------

| | |
| :--- | :--- |
| Active: | true |



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "GZZ908-B",
  "meta" : {
    "profile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization"]
  },
  "identifier" : [{
    "use" : "official",
    "system" : "https://standards.digital.health.nz/ns/hpi-organisation-id",
    "value" : "GZZ908-B"
  }],
  "active" : true,
  "name" : "Reference Organization GZZ908-B"
}

```
