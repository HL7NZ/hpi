# GZZ836-C - New Zealand HPI Implementation Guide v1.4.10

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GZZ836-C**

## Example Organization: GZZ836-C

Profile: [HPI Organization](StructureDefinition-HpiOrganization.md)

Reference Organization GZZ836-C (https://standards.digital.health.nz/ns/hpi-organisation-id#HPIOrganization#GZZ836-C (use: official))

-------

| | |
| :--- | :--- |
| Active: | true |



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "GZZ836-C",
  "meta" : {
    "profile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization"]
  },
  "identifier" : [{
    "use" : "official",
    "system" : "https://standards.digital.health.nz/ns/hpi-organisation-id",
    "value" : "GZZ836-C"
  }],
  "active" : true,
  "name" : "Reference Organization GZZ836-C"
}

```
