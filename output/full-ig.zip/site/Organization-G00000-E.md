# G00000-E - New Zealand HPI Implementation Guide v1.4.11

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **G00000-E**

## Example Organization: G00000-E

Profile: [HPI Organization](StructureDefinition-HpiOrganization.md)

Reference Organization G00000-E (https://standards.digital.health.nz/ns/hpi-organisation-id#HPIOrganization#G00000-E (use: official))

-------

| | |
| :--- | :--- |
| Active: | true |



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "G00000-E",
  "meta" : {
    "profile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization"]
  },
  "identifier" : [{
    "use" : "official",
    "system" : "https://standards.digital.health.nz/ns/hpi-organisation-id",
    "value" : "G00000-E"
  }],
  "active" : true,
  "name" : "Reference Organization G00000-E"
}

```
