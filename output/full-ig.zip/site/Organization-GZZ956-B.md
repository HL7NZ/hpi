# GZZ956-B - New Zealand HPI Implementation Guide v1.4.10

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GZZ956-B**

## Example Organization: GZZ956-B

version: 8910; Last updated: 2022-04-05 15:04:16+1200

Profile: [HPI Organization](StructureDefinition-HpiOrganization.md)

Flat-Unit Address Org (https://standards.digital.health.nz/ns/hpi-organisation-id#HPIOrganization#GZZ956-B (use: official))

-------

| | |
| :--- | :--- |
| Active: | true |
| Alias: | Flat-Unit Address Org |
| Other Id: | NBN/9999999999041 (use: official) |
| Contact Detail | ph: 021 101010(Work) |
|  | 2018-05-20 --> (ongoing) |



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "GZZ956-B",
  "meta" : {
    "versionId" : "8910",
    "lastUpdated" : "2022-04-05T15:04:16.000+12:00",
    "profile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization"]
  },
  "extension" : [{
    "url" : "http://hl7.org.nz/fhir/StructureDefinition/established",
    "valuePeriod" : {
      "start" : "2018-05-20"
    }
  }],
  "identifier" : [{
    "use" : "official",
    "system" : "https://standards.digital.health.nz/ns/hpi-organisation-id",
    "value" : "GZZ956-B",
    "assigner" : {
      "reference" : "Organization/G00001-G"
    }
  },
  {
    "use" : "official",
    "system" : "https://standards.digital.health.nz/ns/hpi-nzbn",
    "value" : "9999999999041",
    "assigner" : {
      "reference" : "Organization/MBIE"
    }
  }],
  "active" : true,
  "name" : "Flat-Unit Address Org",
  "alias" : ["Flat-Unit Address Org"],
  "_alias" : [{
    "extension" : [{
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/alias-type",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://standards.digital.health.nz/ns/alias-type-code",
          "version" : "1.0.0",
          "code" : "legal",
          "display" : "Legal"
        }],
        "text" : "Legal"
      }
    }]
  }],
  "telecom" : [{
    "system" : "phone",
    "value" : "021 101010",
    "use" : "work",
    "rank" : 1,
    "period" : {
      "start" : "1970-01-01"
    }
  }]
}

```
