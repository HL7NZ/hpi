# Extensions - New Zealand HPI Implementation Guide v1.4.10

* [**Table of Contents**](toc.md)
* **Extensions**

## Extensions

**Extensions defined in this guide**

* Id: [esam-id](StructureDefinition-esam-id.md)
  * Url: http://hl7.org.nz/fhir/StructureDefinition/esam-id
  * Context of Use: Location
  * Description: The id from eSam
  * Purpose: 

### Extensions used but defined elsewhere

* Path: Location.extension
  * Url: http://hl7.org.nz/fhir/StructureDefinition/messaging-address
  * Description: Defined outside of known IG's
* Path: PractitionerRole.extension
  * Url: http://hl7.org.nz/fhir/StructureDefinition/messaging-address
  * Description: Defined outside of known IG's

