# Extensions - New Zealand HPI Implementation Guide v1.5.0

* [**Table of Contents**](toc.md)
* **Extensions**

## Extensions

**Extensions defined in this guide**

* Id: [apc-history](StructureDefinition-apc-history.md)
  * Url: http://hl7.org.nz/fhir/StructureDefinition/apc-history
  * Context of Use: Practitioner.qualification
  * Description: A period covered by an annual practicing certificate (APC) for a practitioner's registration.
  * Purpose: Represent APC periods, including history, for a practitioner's registration.
* Id: [esam-id](StructureDefinition-esam-id.md)
  * Url: http://hl7.org.nz/fhir/StructureDefinition/esam-id
  * Context of Use: Location
  * Description: The id from eSam
  * Purpose: 

### Extensions used but defined elsewhere

* Path: Location.extension
  * Url: http://hl7.org.nz/fhir/StructureDefinition/messaging-address
  * Description: Defined outside of known IG's
* Path: PractitionerRole.extension
  * Url: http://hl7.org.nz/fhir/StructureDefinition/messaging-address
  * Description: Defined outside of known IG's

