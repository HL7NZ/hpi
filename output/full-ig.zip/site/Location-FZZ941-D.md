# FZZ941-D - New Zealand HPI Implementation Guide v1.4.11

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FZZ941-D**

## Example Location: FZZ941-D

version: 8954; Last updated: 2022-04-05 15:04:26+1200

Profile: [HPI Location](StructureDefinition-HpiLocation.md)

Dental Clinic with Dist Date (Community Dental) (https://standards.digital.health.nz/ns/hpi-facility-id#HPIFacility#FZZ941-D (use: official))

-------

| | |
| :--- | :--- |
| Status: | Inactive |
| Alias: | * Disestablished Dental
* Dental Clinic with Dist Date
 |
| Type: | Community Dental |
| Address: | Building name for eSAM address 1112139, 133 Molesworth Street, Thorndon 6011, Wellington(work) (NZ Suburb: Thorndon) |
| Contact Detail | ph: 021 789878(Work) |
| Managed By: | [Org Disestablishment Date](Organization-GZZ908-B.md) |
|  | 2016-06-06 --> 2019-09-09 |
| [District Health Board linked to a NZ Healthcare Service, Location or Patient](https://fhir.org.nz/ig/base/StructureDefinition-dhb.html) | Capital and Coast District Health Board |



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "FZZ941-D",
  "meta" : {
    "versionId" : "8954",
    "lastUpdated" : "2022-04-05T15:04:26.000+12:00",
    "profile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPILocation"]
  },
  "extension" : [{
    "url" : "http://hl7.org.nz/fhir/StructureDefinition/established",
    "valuePeriod" : {
      "start" : "2016-06-06",
      "end" : "2019-09-09"
    }
  },
  {
    "url" : "http://hl7.org.nz/fhir/StructureDefinition/dhb",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "https://standards.digital.health.nz/ns/dhb-code",
        "version" : "1.0.0",
        "code" : "G00036-D",
        "display" : "Capital and Coast District Health Board"
      }],
      "text" : "Capital and Coast District Health Board"
    }
  }],
  "identifier" : [{
    "use" : "official",
    "system" : "https://standards.digital.health.nz/ns/hpi-facility-id",
    "value" : "FZZ941-D",
    "assigner" : {
      "reference" : "Organization/G00001-G"
    }
  }],
  "status" : "inactive",
  "name" : "Dental Clinic with Dist Date",
  "alias" : ["Disestablished Dental", "Dental Clinic with Dist Date"],
  "_alias" : [{
    "extension" : [{
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/alias-type",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://standards.digital.health.nz/ns/alias-type-code",
          "version" : "1.0.0",
          "code" : "aka",
          "display" : "Aka"
        }],
        "text" : "Aka"
      }
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/alias-type",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://standards.digital.health.nz/ns/alias-type-code",
          "version" : "1.0.0",
          "code" : "current",
          "display" : "Current unverified or unofficial name"
        }],
        "text" : "Current unverified or unofficial name"
      }
    }]
  }],
  "type" : [{
    "coding" : [{
      "system" : "https://standards.digital.health.nz/ns/location-type-code",
      "version" : "1.0",
      "code" : "dental",
      "display" : "Community Dental"
    }]
  }],
  "telecom" : [{
    "system" : "phone",
    "value" : "021 789878",
    "use" : "work",
    "rank" : 1,
    "period" : {
      "start" : "2016-06-06"
    }
  }],
  "address" : {
    "id" : "1112139",
    "extension" : [{
      "extension" : [{
        "url" : "latitude",
        "valueDecimal" : -41.272975
      },
      {
        "url" : "longitude",
        "valueDecimal" : 174.777729
      }],
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/nz-geocode"
    },
    {
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/suburb",
      "valueString" : "Thorndon"
    },
    {
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/building-name",
      "valueString" : "Building name for eSAM address 1112139"
    },
    {
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/domicile-code",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://standards.digital.health.nz/ns/domicile-code",
          "version" : "3.0",
          "code" : "2077",
          "display" : "Thorndon - Tinakori Road"
        }],
        "text" : "Thorndon - Tinakori Road"
      }
    }],
    "use" : "work",
    "type" : "physical",
    "text" : "Building name for eSAM address 1112139, 133 Molesworth Street, Thorndon 6011, Wellington",
    "line" : ["133 Molesworth Street"],
    "city" : "Wellington",
    "postalCode" : "6011"
  },
  "managingOrganization" : {
    "reference" : "Organization/GZZ908-B",
    "display" : "Org Disestablishment Date"
  }
}

```
