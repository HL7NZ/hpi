# API - New Zealand HPI Implementation Guide v1.4.11

* [**Table of Contents**](toc.md)
* **API**

## API

This is the computable resource that describes the RESTful endpoint

### REST APIs

#### Resource Level Interactions

##### Practitioner

Practitioner query

**Interactions**

* Name: read
  * Verb: GET
  * URL: [base]/Practitioner[cpn]
  * Documentation: Retrieves a Practitioner resource by Id
  * Scope: system/Practitioner.r
* Name: search-type
  * Verb: GET
  * URL: [base]/Practitioner
  * Documentation: Queries against the Practitioner using name and other search parameters. Will return a Bundle (even if there are no matching resources)
  * Scope: system/Practitioner.s
* Name: create
  * Verb: POST'
  * URL: [base]/Practitioner
  * Documentation: Creates a new Practitioner record
  * Scope: system/Practitioner.c

* Name: update-core
  * Definition: [ https://hpi-ig.hip.digital.health.nz/OperationDefinition/practitioner-update-core ](OperationDefinition-Practitioner-update-core.md)
  * Verb: POST
  * URL: [base]/Practitioner[cpn]
  * Documentation: An operation that updates a health providers demographic details
  * Scope: system/Practitioner.u
* Name: update-educational-qualification
  * Definition: [ https://hpi-ig.hip.digital.health.nz/OperationDefinition/practitioner-update-educational-qualification ](OperationDefinition-Practitioner-update-educational-qualification.md)
  * Verb: POST
  * URL: [base]/Practitioner/$update-educational-qualification
  * Documentation: Updates a practitioner's educational qualifications by add
  * Scope: amend or remove actions
* Name: update-registration
  * Definition: [ https://hpi-ig.hip.digital.health.nz/OperationDefinition/practitioner-update-registration ](OperationDefinition-Practitioner-update-registration.md)
  * Verb: POST
  * URL: [base]/Practitioner/$update-registration
  * Documentation: Updates a practitioner's registration status
  * Scope: APC

**Search Parameters**

* Name: identifier
  * Type: [token](http://hl7.org/fhir/search.html#token)
  * Documentation: For searching a Practitioner resource using their council/board registration number
* Name: name
  * Type: [string](http://hl7.org/fhir/search.html#string)
  * Documentation: Should contain the person’s full name, include all given names and family name.
* Name: gender
  * Type: [token](http://hl7.org/fhir/search.html#token)
  * Documentation: Use with name and birthdate. Search by gender alone is not allowed.
* Name: birthdate
  * Type: [date](http://hl7.org/fhir/search.html#date)
  * Documentation: Use with name and gender. Search by birthdate alone is not allowed.

##### PractitionerRole

PractitionerRole query

**Interactions**

* Name: read
  * Verb: GET
  * URL: [base]/PractitionerRole[id]
  * Documentation: Used to retrieve a PractitionerRole resource by Id
  * Scope: system/PractitionerRole.r
* Name: search-type
  * Verb: GET
  * URL: [base]/PractitionerRole
  * Documentation: Queries against PractitionerRole using hpi-person-id and other parameters. Will return a Bundle (even if there are no matching resources)
  * Scope: system/PractitionerRole.s
* Name: create
  * Verb: POST
  * URL: [base]/PractitionerRole
  * Documentation: Create a new PractitionerRole
  * Scope: system/PractitionerRole.c
* Name: update
  * Verb: PUT
  * URL: [base]/PractitionerRole[id]
  * Documentation: Update contact details and end date on an existing PractitionerRole record
  * Scope: system/PractitionerRole.u

**Search Parameters**

* Name: practitioner
  * Type: [reference](http://hl7.org/fhir/search.html#reference)
  * Documentation: Given an hpi-person-id, returns the PractitionerRole records associated with that id
* Name: organization
  * Type: [reference](http://hl7.org/fhir/search.html#reference)
  * Documentation: Not yet enabled. Given an hpi-organization-id, returns the PractitionerRole records associated with that id
* Name: location
  * Type: [token](http://hl7.org/fhir/search.html#token)
  * Documentation: Given an hpi-facility-id, returns the PractitionerRole records associated with that id
* Name: role
  * Type: [token](http://hl7.org/fhir/search.html#token)
  * Documentation: Returns PractitionerRole records based on role code
* Name: active
  * Type: [token](http://hl7.org/fhir/search.html#token)
  * Documentation: To enable exclusion of inactive PractitionerRole records

**Search includes**

* Name: practitioner
* Name: organization
* Name: location

**These are the _include parameters that are supported on searches**

##### Organization

Organization query

**Interactions**

* Name: read
  * Verb: GET
  * URL: [base]/Organization/[hpi-org-id]
  * Documentation: Used to retrieve an Organization resource by Id
  * Scope: system/Organization.r
* Name: search-type
  * Verb: GET
  * URL: [base]/Organization
  * Documentation: Queries against the Organization using name or other parameters. Will return a Bundle (even if there are no matching resources)
  * Scope: system/Organization.s

**Search Parameters**

* Name: active
  * Type: [token](http://hl7.org/fhir/search.html#token)
  * Documentation: To enable exclusion of inactive organizations
* Name: name
  * Type: [string](http://hl7.org/fhir/search.html#string)
  * Documentation: For searching using the organisation’s name or an alias name
* Name: identifier
  * Type: [token](http://hl7.org/fhir/search.html#token)
  * Documentation: For searching using an organisation’s New Zealand Business Number (NZBN) or their legacy NZHIS agency code.
* Name: type
  * Type: [token](http://hl7.org/fhir/search.html#token)
  * Documentation: For searching using an organisation's type E.g. DHB, RA, Educational institution
* Name: partOf
  * Type: [reference](http://hl7.org/fhir/search.html#reference)
  * Documentation: For retrieving organizations that are 'part of' another.

##### Location

Location query

**Interactions**

* Name: read
  * Verb: GET
  * URL: [base]/Location/[hpi-facid]
  * Documentation: Used to retrieve an Location resource by Id
  * Scope: system/Location.r
* Name: search-type
  * Verb: GET
  * URL: [base]/Location
  * Documentation: Queries against the Location using name or other parameters. Will return a Bundle (even if there are no matching resources)
  * Scope: system/Location.s

**Search Parameters**

* Name: identifier
  * Type: [token](http://hl7.org/fhir/search.html#token)
  * Documentation: For searching using an organization’s legacy NZHIS facility code.
* Name: name
  * Type: [string](http://hl7.org/fhir/search.html#string)
  * Documentation: For searching using the Locations name or alias name
* Name: type
  * Type: [token](http://hl7.org/fhir/search.html#token)
  * Documentation: Retrieve Locations of the given type
* Name: address
  * Type: [string](http://hl7.org/fhir/search.html#string)
  * Documentation: Retrieve the Locations by address
* Name: organization
  * Type: [reference](http://hl7.org/fhir/search.html#reference)
  * Documentation: Retrieve Locations with the given ManagingOrganization
* Name: dhb
  * Type: [token](http://hl7.org/fhir/search.html#token)
  * Documentation: Searching for Locations that are in a DHBs catchment area.
* Name: status
  * Type: [token](http://hl7.org/fhir/search.html#token)
  * Documentation: Not yet enabled. To enable exclusion of inactive locations
* Name: messaging-address
  * Type: [string](http://hl7.org/fhir/search.html#string)
  * Documentation: Search by EDI address

