# Resource New Zealand HPI Implementation Guide



## Resource Content

```json
{
  "resourceType" : "ImplementationGuide",
  "id" : "hl7.org.nz.fhir.ig.hpi",
  "language" : "en",
  "url" : "http://hl7.org.nz/fhir/ig/hpi/ImplementationGuide/hl7.org.nz.fhir.ig.hpi",
  "version" : "1.6.0",
  "name" : "NewZealandHPIIG",
  "title" : "New Zealand HPI Implementation Guide",
  "status" : "active",
  "date" : "2023-09-03",
  "publisher" : "Te Whatu Ora",
  "contact" : [{
    "name" : "Te Whatu Ora",
    "telecom" : [{
      "system" : "email",
      "value" : "mailto:integration@health.govt.nz"
    }]
  }],
  "description" : "The HPI facade",
  "packageId" : "hl7.org.nz.fhir.ig.hpi",
  "license" : "CC0-1.0",
  "fhirVersion" : ["4.0.1"],
  "dependsOn" : [{
    "id" : "hl7tx",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on HL7 Terminology"
    }],
    "uri" : "http://terminology.hl7.org/ImplementationGuide/hl7.terminology",
    "packageId" : "hl7.terminology.r4",
    "version" : "7.5.0"
  },
  {
    "id" : "hl7ext",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on the HL7 Extension Pack"
    }],
    "uri" : "http://hl7.org/fhir/extensions/ImplementationGuide/hl7.fhir.uv.extensions",
    "packageId" : "hl7.fhir.uv.extensions.r4",
    "version" : "5.4.0"
  },
  {
    "id" : "hl7_org_nz_fhir_ig_hip_core",
    "uri" : "https://common-ig.hip.digital.health.nz/site",
    "packageId" : "hl7.org.nz.fhir.ig.hip-core",
    "version" : "1.9.5"
  },
  {
    "id" : "fhir_org_nz_ig_base",
    "uri" : "https://fhir.org.nz/ig/base/",
    "packageId" : "fhir.org.nz.ig.base",
    "version" : "2.0.0"
  }],
  "definition" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-internal-dependency",
      "valueCode" : "hl7.fhir.uv.tools.r4#1.3.0"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2020+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "Release"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "show-inherited-invariants"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org.nz/fhir/ig/hpi/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "i18n-default-lang"
      },
      {
        "url" : "value",
        "valueString" : "en"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    }],
    "resource" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-HpiLocation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/HpiLocation"
      },
      "name" : "HPI Location",
      "description" : "A physical location from which health goods and/or services are provided.  They are also referred to as an HPI Facility.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-HpiOrganization.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/HpiOrganization"
      },
      "name" : "HPI Organization",
      "description" : "An entity that provides services of interest to, or is involved in, the business of health care service provision.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-HPIPractitioner.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/HPIPractitioner"
      },
      "name" : "HPI Practitioner",
      "description" : "The practitioner exposed by the HPI. This is the person who delivers healthcare or healthcare related services.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-HPIPractitionerRole.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/HPIPractitionerRole"
      },
      "name" : "HPI Practitioner role",
      "description" : "The practitioner role exposed by the HPI. Used to connect Practitioners with Organizations and Locations, indicating the role they have. A single Practitioner can have roles with multiple organizations.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-esam-id.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/esam-id"
      },
      "name" : "Esam_id",
      "description" : "The id from eSam",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-apc-history.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/apc-history"
      },
      "name" : "APC History",
      "description" : "A period covered by an annual practicing certificate (APC) for a practitioner's registration.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Practitioner"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Practitioner-90ZZLP.html"
      }],
      "reference" : {
        "reference" : "Practitioner/90ZZLP"
      },
      "name" : "90ZZLP",
      "description" : "Example HPI Practitioner with No Registration 'NR' with confidentiality R",
      "exampleCanonical" : "http://hl7.org.nz/fhir/StructureDefinition/HPIPractitioner"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Practitioner"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Practitioner-91ZABY.html"
      }],
      "reference" : {
        "reference" : "Practitioner/91ZABY"
      },
      "name" : "91ZABY",
      "description" : "Example HPI Practitioner with one registration",
      "exampleCanonical" : "http://hl7.org.nz/fhir/StructureDefinition/HPIPractitioner"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Practitioner"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Practitioner-92ZZRE.html"
      }],
      "reference" : {
        "reference" : "Practitioner/92ZZRE"
      },
      "name" : "92ZZRE",
      "description" : "Example HPI Practitioner with No Registration 'NR'",
      "exampleCanonical" : "http://hl7.org.nz/fhir/StructureDefinition/HPIPractitioner"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Practitioner"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Practitioner-98ZZQJ.html"
      }],
      "reference" : {
        "reference" : "Practitioner/98ZZQJ"
      },
      "name" : "98ZZQJ",
      "description" : "Example HPI Practitioner with two registrations",
      "exampleCanonical" : "http://hl7.org.nz/fhir/StructureDefinition/HPIPractitioner"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Practitioner"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Practitioner-99ZZZS.html"
      }],
      "reference" : {
        "reference" : "Practitioner/99ZZZS"
      },
      "name" : "99ZZZS",
      "description" : "Example HPI Practitioner used by PractitionerRole",
      "exampleCanonical" : "http://hl7.org.nz/fhir/StructureDefinition/HPIPractitioner"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Location"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Location-FZZ941-D.html"
      }],
      "reference" : {
        "reference" : "Location/FZZ941-D"
      },
      "name" : "FZZ941-D",
      "description" : "Example HPI Location Inactive (disestablished)",
      "exampleCanonical" : "http://hl7.org.nz/fhir/StructureDefinition/HPILocation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Location"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Location-FZZ958-K.html"
      }],
      "reference" : {
        "reference" : "Location/FZZ958-K"
      },
      "name" : "FZZ958-K",
      "description" : "Example HPI Location with Managing Org",
      "exampleCanonical" : "http://hl7.org.nz/fhir/StructureDefinition/HPILocation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Location"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Location-FZZ999-B.html"
      }],
      "reference" : {
        "reference" : "Location/FZZ999-B"
      },
      "name" : "FZZ999-B",
      "description" : "Example HPI Location with messaging address",
      "exampleCanonical" : "http://hl7.org.nz/fhir/StructureDefinition/HPILocation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-G00000-E.html"
      }],
      "reference" : {
        "reference" : "Organization/G00000-E"
      },
      "name" : "G00000-E",
      "description" : "Example HPI Organization",
      "exampleCanonical" : "http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-G00001-G.html"
      }],
      "reference" : {
        "reference" : "Organization/G00001-G"
      },
      "name" : "G00001-G",
      "description" : "Example HPI root Organization",
      "exampleCanonical" : "http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-G00008-K.html"
      }],
      "reference" : {
        "reference" : "Organization/G00008-K"
      },
      "name" : "G00008-K",
      "description" : "Example HPI Organization",
      "exampleCanonical" : "http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-G00009-A.html"
      }],
      "reference" : {
        "reference" : "Organization/G00009-A"
      },
      "name" : "G00009-A",
      "description" : "Example HPI Organization",
      "exampleCanonical" : "http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-GZZ836-C.html"
      }],
      "reference" : {
        "reference" : "Organization/GZZ836-C"
      },
      "name" : "GZZ836-C",
      "description" : "Example HPI Organization",
      "exampleCanonical" : "http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-GZZ908-B.html"
      }],
      "reference" : {
        "reference" : "Organization/GZZ908-B"
      },
      "name" : "GZZ908-B",
      "description" : "Example HPI Organization",
      "exampleCanonical" : "http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-GZZ956-B.html"
      }],
      "reference" : {
        "reference" : "Organization/GZZ956-B"
      },
      "name" : "GZZ956-B",
      "description" : "Example HPI Organization",
      "exampleCanonical" : "http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-GZZ991-D.html"
      }],
      "reference" : {
        "reference" : "Organization/GZZ991-D"
      },
      "name" : "GZZ991-D",
      "description" : "Example HPI Organization 'partof'",
      "exampleCanonical" : "http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-GZZ998-G.html"
      }],
      "reference" : {
        "reference" : "Organization/GZZ998-G"
      },
      "name" : "GZZ998-G",
      "description" : "Example HPI Organization for PractitionerRole references",
      "exampleCanonical" : "http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-GZZ999-J.html"
      }],
      "reference" : {
        "reference" : "Organization/GZZ999-J"
      },
      "name" : "GZZ999-J",
      "description" : "Example HPI Organization",
      "exampleCanonical" : "http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-HpiCapabilityStatement.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/HpiCapabilityStatement"
      },
      "name" : "CapabilityStatement",
      "description" : "Represents API exposed by HPI",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-MBIE.html"
      }],
      "reference" : {
        "reference" : "Organization/MBIE"
      },
      "name" : "MBIE",
      "description" : "Example MBIE Organization",
      "exampleCanonical" : "http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "OperationDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "OperationDefinition-Practitioner-update-core.html"
      }],
      "reference" : {
        "reference" : "OperationDefinition/Practitioner-update-core"
      },
      "name" : "Practitioner-update-core",
      "description" : "A custom operation which updates a health provider's name, birthdate and death-date.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "OperationDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "OperationDefinition-Practitioner-update-personal-details.html"
      }],
      "reference" : {
        "reference" : "OperationDefinition/Practitioner-update-personal-details"
      },
      "name" : "Practitioner-update-personal-details",
      "description" : "Updates a health provider's gender, ethnicity and communication languages.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "PractitionerRole"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "PractitionerRole-R00000012-G.html"
      }],
      "reference" : {
        "reference" : "PractitionerRole/R00000012-G"
      },
      "name" : "R00000012-G",
      "description" : "Example HPI PractitionerRole Medical Receptionist",
      "exampleCanonical" : "http://hl7.org.nz/fhir/StructureDefinition/HPIPractitionerRole"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "PractitionerRole"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "PractitionerRole-R00000015-C.html"
      }],
      "reference" : {
        "reference" : "PractitionerRole/R00000015-C"
      },
      "name" : "R00000015-C",
      "description" : "Example HPI PractitionerRole with confidentiality R",
      "exampleCanonical" : "http://hl7.org.nz/fhir/StructureDefinition/HPIPractitionerRole"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "PractitionerRole"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "PractitionerRole-R00000029-P.html"
      }],
      "reference" : {
        "reference" : "PractitionerRole/R00000029-P"
      },
      "name" : "R00000029-P",
      "description" : "Example HPI PractitionerRole with messagin address",
      "exampleCanonical" : "http://hl7.org.nz/fhir/StructureDefinition/HPIPractitionerRole"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Person"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Person-testall.html"
      }],
      "reference" : {
        "reference" : "Person/testall"
      },
      "name" : "testall",
      "description" : "Example person used by PractitionerRole creator extension",
      "exampleBoolean" : true
    }],
    "page" : {
      "nameUrl" : "toc.html",
      "title" : "Table of Contents",
      "generation" : "html",
      "page" : [{
        "nameUrl" : "index.html",
        "title" : "Home",
        "generation" : "markdown"
      },
      {
        "nameUrl" : "API.html",
        "title" : "API",
        "generation" : "html"
      },
      {
        "nameUrl" : "businessView.html",
        "title" : "Business View",
        "generation" : "markdown"
      },
      {
        "nameUrl" : "capabilityStatement.html",
        "title" : "Capability Statement",
        "generation" : "html"
      },
      {
        "nameUrl" : "ComplianceTestingImportantInformation.html",
        "title" : "Compliance Testing Important Information",
        "generation" : "markdown"
      },
      {
        "nameUrl" : "createPracRole.html",
        "title" : "Create Prac Role",
        "generation" : "markdown"
      },
      {
        "nameUrl" : "createPracRoleExample.html",
        "title" : "Create Prac Role Example",
        "generation" : "markdown"
      },
      {
        "nameUrl" : "createPractitioner.html",
        "title" : "Create Practitioner",
        "generation" : "markdown"
      },
      {
        "nameUrl" : "extensions.html",
        "title" : "Extensions",
        "generation" : "html"
      },
      {
        "nameUrl" : "FacilityComplianceTesting.html",
        "title" : "Facility Compliance Testing",
        "generation" : "markdown"
      },
      {
        "nameUrl" : "faq.html",
        "title" : "Faq",
        "generation" : "markdown"
      },
      {
        "nameUrl" : "general.html",
        "title" : "General",
        "generation" : "markdown"
      },
      {
        "nameUrl" : "getFacility.html",
        "title" : "Get Facility",
        "generation" : "markdown"
      },
      {
        "nameUrl" : "getOrganisation.html",
        "title" : "Get Organisation",
        "generation" : "markdown"
      },
      {
        "nameUrl" : "getPracRole.html",
        "title" : "Get Prac Role",
        "generation" : "markdown"
      },
      {
        "nameUrl" : "getPractitioner.html",
        "title" : "Get Practitioner",
        "generation" : "markdown"
      },
      {
        "nameUrl" : "glossary.html",
        "title" : "Glossary",
        "generation" : "markdown"
      },
      {
        "nameUrl" : "Guidance.html",
        "title" : "Guidance",
        "generation" : "markdown"
      },
      {
        "nameUrl" : "namingSystems.html",
        "title" : "Naming Systems",
        "generation" : "markdown"
      },
      {
        "nameUrl" : "Onboarding.html",
        "title" : "Onboarding",
        "generation" : "markdown"
      },
      {
        "nameUrl" : "OrganisationComplianceTesting.html",
        "title" : "Organisation Compliance Testing",
        "generation" : "markdown"
      },
      {
        "nameUrl" : "PractitionerComplianceTesting.html",
        "title" : "Practitioner Compliance Testing",
        "generation" : "markdown"
      },
      {
        "nameUrl" : "PractitionerRoleComplianceTesting.html",
        "title" : "Practitioner Role Compliance Testing",
        "generation" : "markdown"
      },
      {
        "nameUrl" : "profiles.html",
        "title" : "Profiles",
        "generation" : "html"
      },
      {
        "nameUrl" : "putPractitionerRoleExample.html",
        "title" : "Put Practitioner Role Example",
        "generation" : "markdown"
      },
      {
        "nameUrl" : "searchFacility.html",
        "title" : "Search Facility",
        "generation" : "markdown"
      },
      {
        "nameUrl" : "searchOrganisation.html",
        "title" : "Search Organisation",
        "generation" : "markdown"
      },
      {
        "nameUrl" : "searchPracRole.html",
        "title" : "Search Prac Role",
        "generation" : "markdown"
      },
      {
        "nameUrl" : "searchPractitioner.html",
        "title" : "Search Practitioner",
        "generation" : "markdown"
      },
      {
        "nameUrl" : "terminology.html",
        "title" : "Terminology",
        "generation" : "markdown"
      },
      {
        "nameUrl" : "TermsOfUse.html",
        "title" : "Terms Of Use",
        "generation" : "markdown"
      },
      {
        "nameUrl" : "updatePracRole.html",
        "title" : "Update Prac Role",
        "generation" : "markdown"
      },
      {
        "nameUrl" : "updatePractitioner.html",
        "title" : "Update Practitioner",
        "generation" : "markdown"
      },
      {
        "nameUrl" : "usecasesDEP.html",
        "title" : "Usecases DEP",
        "generation" : "markdown"
      }]
    },
    "parameter" : [{
      "code" : "path-resource",
      "value" : "input/capabilities"
    },
    {
      "code" : "path-resource",
      "value" : "input/examples"
    },
    {
      "code" : "path-resource",
      "value" : "input/extensions"
    },
    {
      "code" : "path-resource",
      "value" : "input/models"
    },
    {
      "code" : "path-resource",
      "value" : "input/operations"
    },
    {
      "code" : "path-resource",
      "value" : "input/profiles"
    },
    {
      "code" : "path-resource",
      "value" : "input/resources"
    },
    {
      "code" : "path-resource",
      "value" : "input/vocabulary"
    },
    {
      "code" : "path-resource",
      "value" : "input/maps"
    },
    {
      "code" : "path-resource",
      "value" : "input/testing"
    },
    {
      "code" : "path-resource",
      "value" : "input/history"
    },
    {
      "code" : "path-resource",
      "value" : "fsh-generated/resources"
    },
    {
      "code" : "path-pages",
      "value" : "template/config"
    },
    {
      "code" : "path-pages",
      "value" : "input/images"
    },
    {
      "code" : "path-tx-cache",
      "value" : "input-cache/txcache"
    }]
  }
}

```
