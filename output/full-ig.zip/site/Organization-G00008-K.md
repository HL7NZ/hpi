# G00008-K - New Zealand HPI Implementation Guide v1.4.11

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **G00008-K**

## Example Organization: G00008-K

Profile: [HPI Organization](StructureDefinition-HpiOrganization.md)

Reference Organization G00008-K (https://standards.digital.health.nz/ns/hpi-organisation-id#HPIOrganization#G00008-K (use: official))

-------

| | |
| :--- | :--- |
| Active: | true |



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "G00008-K",
  "meta" : {
    "profile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization"]
  },
  "identifier" : [{
    "use" : "official",
    "system" : "https://standards.digital.health.nz/ns/hpi-organisation-id",
    "value" : "G00008-K"
  }],
  "active" : true,
  "name" : "Reference Organization G00008-K"
}

```
