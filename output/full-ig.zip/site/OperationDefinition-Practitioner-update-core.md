# Practitioner-update-core - New Zealand HPI Implementation Guide v1.4.11

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Practitioner-update-core**

## OperationDefinition: Practitioner-update-core 

| | |
| :--- | :--- |
| *Official URL*:https://hpi-ig.hip.digital.health.nz/OperationDefinition/practitioner-update-core | *Version*:1.4.11 |
| Draft as of 2023-06-12 | *Computable Name*:Update Core  |

 
Updates a health provider's name, birthdate, death-date 



## Resource Content

```json
{
  "resourceType" : "OperationDefinition",
  "id" : "Practitioner-update-core",
  "url" : "https://hpi-ig.hip.digital.health.nz/OperationDefinition/practitioner-update-core",
  "version" : "1.4.11",
  "name" : "Update Core ",
  "title" : "Updates a health provider's name, birthdate and death-date.",
  "status" : "draft",
  "kind" : "operation",
  "experimental" : false,
  "date" : "2023-06-12T12:47:40+10:00",
  "publisher" : "Te Whatu Ora",
  "contact" : [{
    "name" : "Te Whatu Ora",
    "telecom" : [{
      "system" : "email",
      "value" : "mailto:integration@health.govt.nz"
    }]
  }],
  "description" : "Updates a health provider's name, birthdate, death-date",
  "affectsState" : true,
  "code" : "practitioner-update-core",
  "comment" : "The cpn is validated, the versionId is validated. If all request parameters are valid If all request parameters are valid, then the parameter is replaced on the record",
  "resource" : ["Practitioner"],
  "system" : false,
  "type" : false,
  "instance" : true,
  "parameter" : [{
    "name" : "cpn",
    "use" : "in",
    "min" : 1,
    "max" : "1",
    "documentation" : "The hpi-person-id (cpn)",
    "type" : "string"
  },
  {
    "name" : "version-id",
    "use" : "in",
    "min" : 1,
    "max" : "1",
    "documentation" : "The current Practitioner record version number",
    "type" : "string"
  },
  {
    "name" : "ra-identifier",
    "use" : "in",
    "min" : 1,
    "max" : "1",
    "documentation" : "The RA identifier",
    "type" : "string"
  },
  {
    "name" : "name",
    "use" : "in",
    "min" : 0,
    "max" : "1",
    "documentation" : "An update replaces the full set of name attributes (use, prefix, given, family)",
    "type" : "string"
  },
  {
    "name" : "death-date",
    "use" : "in",
    "min" : 0,
    "max" : "1",
    "documentation" : "The Provider's date of death, can only be set by an admin user",
    "type" : "string"
  },
  {
    "name" : "birth-date",
    "use" : "in",
    "min" : 0,
    "max" : "1",
    "documentation" : "The Provider's birthdate, can only be set by an admin user",
    "type" : "string"
  },
  {
    "name" : "Practitioner",
    "use" : "out",
    "min" : 0,
    "max" : "1",
    "documentation" : "The updated Practitioner resource",
    "type" : "Practitioner"
  },
  {
    "name" : "failure",
    "use" : "out",
    "min" : 0,
    "max" : "1",
    "documentation" : "Error response",
    "type" : "OperationOutcome"
  }]
}

```
