# G00009-A - New Zealand HPI Implementation Guide v1.4.10

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **G00009-A**

## Example Organization: G00009-A

Profile: [HPI Organization](StructureDefinition-HpiOrganization.md)

Reference Organization G00009-A (https://standards.digital.health.nz/ns/hpi-organisation-id#HPIOrganization#G00009-A (use: official))

-------

| | |
| :--- | :--- |
| Active: | true |



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "G00009-A",
  "meta" : {
    "profile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization"]
  },
  "identifier" : [{
    "use" : "official",
    "system" : "https://standards.digital.health.nz/ns/hpi-organisation-id",
    "value" : "G00009-A"
  }],
  "active" : true,
  "name" : "Reference Organization G00009-A"
}

```
