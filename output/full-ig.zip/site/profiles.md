# Profiles - New Zealand HPI Implementation Guide v1.5.0

* [**Table of Contents**](toc.md)
* **Profiles**

## Profiles

**Profiles defined in this guide**

* Id: [HpiLocation](StructureDefinition-HpiLocation.md)
  * Url: http://hl7.org.nz/fhir/StructureDefinition/HPILocation
  * Description: A physical location from which health goods and/or services are provided. They are also referred to as an HPI Facility.
* Id: [HpiOrganization](StructureDefinition-HpiOrganization.md)
  * Url: http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization
  * Description: An entity that provides services of interest to, or is involved in, the business of health care service provision.
* Id: [HPIPractitioner](StructureDefinition-HPIPractitioner.md)
  * Url: http://hl7.org.nz/fhir/StructureDefinition/HPIPractitioner
  * Description: The practitioner exposed by the HPI. This is the person who delivers healthcare or healthcare related services.
* Id: [HPIPractitionerRole](StructureDefinition-HPIPractitionerRole.md)
  * Url: http://hl7.org.nz/fhir/StructureDefinition/HPIPractitionerRole
  * Description: The practitioner role exposed by the HPI. Used to connect Practitioners with Organizations and Locations, indicating the role they have. A single Practitioner can have roles with multiple organizations.

